import apisauce from 'apisauce';
import humps from 'humps';

export const getToken = () => localStorage.getItem('@ead/jwt');
export const setToken = data => localStorage.setItem('@ead/jwt', data);
export const removeToken = () => localStorage.removeItem('@ead/jwt');

const api = apisauce.create({
  baseURL: process.env.REACT_APP_API_URL,
  timeout: 100000,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.addRequestTransform(request => {
  if (!(request.data instanceof FormData)) {
    request.data = humps.decamelizeKeys(request.data, (key, convert) => {
      if (key === 'viewBox') {
        return key;
      }
      return convert(key);
    });
  }
  request.headers.Authorization = `Bearer ${getToken()}`;
});

api.addResponseTransform(response => {
  response.pagination = response.data?.meta?.pagination;
  response.data = humps.camelizeKeys(response.data?.data || response.data);

  if (response.status === 401 && !window.location.href.includes('signin')) {
    window.location.replace('/signin?noAuth');
  }

  if (!response.ok) {
    response.data = response.data?.error;
  }
});

export default api;
