import React from 'react';
import { PersistGate } from 'redux-persist/integration/react';
import { Provider } from 'react-redux';
import { ToastContainer, Slide } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '@uppy/core/dist/style.css';
import '@uppy/dashboard/dist/style.css';
import '@uppy/drag-drop/dist/style.css';
import '@uppy/webcam/dist/style.css';
import { Router } from 'react-router-dom';

import { store, persistor } from './Modules';
import history from './Config/History';
import Routes from './Routes';
import { GlobalStyle } from './Themes';

export default function App() {
  return (
    <Provider store={store}>
      <PersistGate persistor={persistor}>
        <Router history={history}>
          <GlobalStyle />
          <ToastContainer autoClose={1500} transition={Slide} hideProgressBar />
          <Routes />
        </Router>
      </PersistGate>
    </Provider>
  );
}
