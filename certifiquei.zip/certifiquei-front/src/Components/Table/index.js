import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
  Table,
  TableBody,
  TableHead,
  TableRow,
  Grid,
  TableCell,
  TableContainer,
  CircularProgress,
  Paper,
  IconButton,
  Typography,
} from '@material-ui/core';
import { MoreHorizOutlined } from '@material-ui/icons';

import Head from './Head';
import Column from './Column';
import Pagination from '../Pagination';
import Popover from '../Popover';
import PopoverButton from '../PopoverButton';

import { Card } from './styles';

export const DynamicTable = ({
  loading,
  data,
  childrenDataKey,
  columns,
  childrenColumns,
  meta,
  setMeta,
  noPagination,
}) => {
  const [state, setState] = useState({
    anchorEl: null,
    currentRow: null,
    currentColumn: null,
  });

  const handleClick = (e, item, column) => {
    setState({ ...state, anchorEl: e.currentTarget, currentRow: item, currentColumn: column });
  };

  const handleClose = () => {
    setState({ ...state, anchorEl: null, currentRow: null, currentColumn: null });
  };

  const Actions = ({ item, column }) => (
    <TableCell>
      <IconButton aria-describedby={item.id} onClick={e => handleClick(e, item, column)}>
        <MoreHorizOutlined />
      </IconButton>
    </TableCell>
  );

  return (
    <Grid item xs={12}>
      <Card variant="outlined">
        {loading && (
          <Grid container justify="center" className="Padding-3">
            <CircularProgress />
          </Grid>
        )}
        {!loading && !!data.length && (
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  {columns.map(item =>
                    item.name === 'actions' ? <TableCell /> : <Head title={item.label} />,
                  )}
                </TableRow>
              </TableHead>
              <TableBody>
                {data.map(item => (
                  <>
                    <TableRow key={item.id}>
                      {columns.map(column =>
                        column.name === 'actions' ? (
                          <Actions item={item} column={column} />
                        ) : (
                          <Column item={item} column={column} />
                        ),
                      )}
                    </TableRow>

                    {!!childrenDataKey && item[childrenDataKey]?.length && (
                      <>
                        <TableContainer component={Paper} className="Inner-Table">
                          <Typography variant="subtitle1" className="Margin-t-1 Margin-b-1">
                            <b>Alternativas de {item.title}</b>
                          </Typography>
                          <Table>
                            <TableHead>
                              <TableRow>
                                {childrenColumns.map(inner => (
                                  <Head title={inner.label} />
                                ))}
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {item[childrenDataKey].map(inner => (
                                <TableRow key={inner.id}>
                                  {childrenColumns.map(column => (
                                    <Column item={inner} column={column} />
                                  ))}
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      </>
                    )}
                  </>
                ))}
              </TableBody>
            </Table>

            {!noPagination && (
              <Pagination
                current={data.length}
                total={meta.total}
                prev={() =>
                  setMeta({
                    ...meta,
                    page: meta.page > 1 ? meta.page - 1 : meta.page,
                  })
                }
                next={() =>
                  setMeta({
                    ...meta,
                    page: meta.page < meta.pageCount ? meta.page + 1 : meta.page,
                  })
                }
              />
            )}
          </TableContainer>
        )}

        {!loading && !data.length && (
          <Grid container justify="center" alignItems="center" className="Padding-3">
            <Typography variant="body1">Nenhum resultado encontrado.</Typography>
          </Grid>
        )}

        <Popover
          id={state.currentRow?.id}
          open={!!state.anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'right',
          }}
          anchorPosition={{ bottom: 200, right: 400 }}
          small
        >
          {state.currentColumn?.data?.map(item => (
            <PopoverButton
              onClick={() => {
                item.onClick(state.currentRow);
                setState({ ...state, anchorEl: null, currentRow: null, currentColumn: null });
              }}
            >
              {item.label}
            </PopoverButton>
          ))}
        </Popover>
      </Card>
    </Grid>
  );
};

DynamicTable.propTypes = {
  loading: PropTypes.bool,
  data: PropTypes.arrayOf(PropTypes.object).isRequired,
  columns: PropTypes.arrayOf(PropTypes.object).isRequired,
  setMeta: PropTypes.func.isRequired,
  noPagination: PropTypes.bool,
};

DynamicTable.defaultProps = {
  loading: false,
  noPagination: false,
};

export default DynamicTable;
