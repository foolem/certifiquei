import React from 'react';

import PropTypes from 'prop-types';
import { TableCell } from '@material-ui/core';

const Head = ({ title }) => {
  return <TableCell>{title}</TableCell>;
};

Head.propTypes = {
  title: PropTypes.string.isRequired,
};

export default Head;
