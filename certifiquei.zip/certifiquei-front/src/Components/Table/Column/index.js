import React from 'react';

import Grid from '@material-ui/core/Grid';

import PropTypes from 'prop-types';
import { TableCell } from '@material-ui/core';

const Column = ({ item, column }) => {
  const formattedTitle = () => {
    if (column.formatLabel) {
      return column.formatLabel(item);
    }

    return item[column.name];
  };

  const Content = () => (
    <>
      {column.icon && (
        <Grid container alignItems="center">
          {column.icon(item)}
          {formattedTitle()}
        </Grid>
      )}
      {!column.icon && formattedTitle()}
    </>
  );

  return (
    <TableCell className={column.className ? column.className(item) : ''}>
      <Content />
    </TableCell>
  );
};

Column.propTypes = {
  item: PropTypes.shape({}).isRequired,
  column: PropTypes.shape({}).isRequired,
};

export default Column;
