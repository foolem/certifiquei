import styled from 'styled-components';
import { Card as MuiCard } from '@material-ui/core';

export const Card = styled(MuiCard)`
  border-radius: 5px !important;
  background-color: #ffffff;
  box-shadow: 0 2px 14px 0 rgba(0, 0, 0, 0.08);
  padding: 1em;
`;
