import React from 'react';

import Nav from '../Nav';

import { Wrapper, Container, Content } from './styles';

const Body = ({ padding, children }) => {
  return (
    <Wrapper>
      <Nav />
      <Container padding={padding}>
        <Content>{children}</Content>
      </Container>
    </Wrapper>
  );
};

export default Body;
