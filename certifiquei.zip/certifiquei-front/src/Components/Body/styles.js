import styled from 'styled-components';
import { Metrics } from '../../Themes';

export const Wrapper = styled.div`
  display: flex;
`;

export const Container = styled.div`
  display: flex;
  justify-content: center;
  margin: 0;
  width: 100%;
  padding: 1em 1em 1em 19em;
  ${props => (props.padding ? `padding: ${props.padding}` : '')};
  height: 100%;
  padding-bottom: ${Metrics.defaults.margin};
  background-color: #f7f7fa;
  min-height: 100vh;
  height: 100%;

  @media (max-width: 900px) {
    padding: 5em 1em;
  }
`;

export const Content = styled.div`
  width: 100%;
  max-width: ${Metrics.body.maxWidth};
  padding: 0 1%;
`;
