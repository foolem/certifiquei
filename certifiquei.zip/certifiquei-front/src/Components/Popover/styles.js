import styled from 'styled-components';
import { Paper } from '@material-ui/core';
import { Metrics } from '../../Themes';

export const Component = styled(Paper)`
  padding: ${props => (!!props.small ? '0' : Metrics.defaults.padding)};
  width: ${props =>
    !!props.small ? Metrics.popover.widthLittle : Metrics.popover.width};
`;
