import React from 'react';
import { Popover as PopoverMaterial } from '@material-ui/core';
import { Component } from './styles';

export default function Popover(props) {
  return (
    <PopoverMaterial {...props}>
      <Component small={props.small}>{props.children}</Component>
    </PopoverMaterial>
  );
}
