import React from 'react';
import { FormGroup, InputLabel } from '@material-ui/core';
import PropTypes from 'prop-types';

import SunEditor from '../SunEditor';

export default function TextArea({ label, height, value, onChange, className }) {
  return (
    <FormGroup container spacing={3} className={className}>
      <InputLabel>{label}</InputLabel>
      <SunEditor
        placeholder="Escreva a descrição da aula"
        heightEditor={height}
        showToolbar
        mode="classic"
        initialValue={value}
        onChange={e => onChange(e)}
      />
    </FormGroup>
  );
}

TextArea.propTypes = {
  label: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  InputProps: PropTypes.shape({}),
  value: PropTypes.string,
  className: PropTypes.string,
  height: PropTypes.number,
};

TextArea.defaultProps = {
  className: '',
  value: '',
  InputProps: null,
  height: 400,
};
