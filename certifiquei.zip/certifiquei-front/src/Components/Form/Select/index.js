import React from 'react';
import { FormGroup, InputLabel, MenuItem, Select as MuiSelect } from '@material-ui/core';
import PropTypes from 'prop-types';

export default function Select({
  label,
  value,
  multiple,
  options,
  onChange,
  renderValue,
  disabled,
  className,
}) {
  return (
    <FormGroup container spacing={3} className={className}>
      <InputLabel>{label}</InputLabel>
      <MuiSelect
        variant="outlined"
        fullWidth
        fullHeight
        multiple={multiple}
        value={value}
        onChange={onChange}
        renderValue={renderValue}
        disabled={disabled}
      >
        {options.map(item => (
          <MenuItem key={item.value} value={item.value}>
            {item.label}
          </MenuItem>
        ))}
      </MuiSelect>
    </FormGroup>
  );
}

Select.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  multiple: PropTypes.bool.isRequired,
  renderValue: PropTypes.func,
  className: PropTypes.string,
  disabled: PropTypes.bool,
};

Select.defaultProps = {
  className: '',
  renderValue: null,
  disabled: false,
};
