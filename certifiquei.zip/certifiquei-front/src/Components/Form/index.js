import React from 'react';

import { Container } from './style';

export default function Form({ children, className }) {
  return (
    <Container container spacing={3} className={className}>
      {children}
    </Container>
  );
}
