import React from 'react';
import { FormGroup, InputLabel, TextField } from '@material-ui/core';
import PropTypes from 'prop-types';

export default function Input({
  label,
  placeholder,
  value,
  onChange,
  type,
  InputProps,
  multiline,
  disabled,
  className,
  error,
}) {
  return (
    <FormGroup container spacing={3} className={className}>
      <InputLabel>{label}</InputLabel>
      <TextField
        variant="outlined"
        fullWidth
        fullHeight
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        InputProps={InputProps}
        type={type}
        disabled={disabled}
        multiline={multiline}
        error={error}
      />
    </FormGroup>
  );
}

Input.propTypes = {
  label: PropTypes.string.isRequired,
  placeholder: PropTypes.string,
  value: PropTypes.string.isRequired,
  type: PropTypes.string,
  onChange: PropTypes.func.isRequired,
  InputProps: PropTypes.shape({}),
  className: PropTypes.string,
  multiline: PropTypes.bool,
  disabled: PropTypes.bool,
  error: PropTypes.bool,
};

Input.defaultProps = {
  placeholder: '',
  className: '',
  InputProps: null,
  type: 'text',
  multiline: false,
  disabled: false,
  error: false,
};
