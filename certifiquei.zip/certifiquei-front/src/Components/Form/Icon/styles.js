import styled from 'styled-components';
import { Colors } from '../../../Themes';

export const IconContainer = styled.div`
  width: 80%;
  height: 1.4em;
  border: 1px solid ${Colors.navGray};
  border-radius: 5px;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  display: flex;
  align-items: center;
  padding: 1em;
  color: ${({ color }) => color} !important;
`;

export const ColorContainer = styled.div`
  width: 100%;
  border: 1px solid ${Colors.navGray};
  border-radius: 5px;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  border-left: 0;
  padding: 1em;
  display: flex;
  justify-content: center;
  align-items: center;
  img {
    width: 1.4em;
    height: 1.4em;
  }
`;
