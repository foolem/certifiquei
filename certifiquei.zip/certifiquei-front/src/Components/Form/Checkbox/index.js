import React from 'react';
import { FormControlLabel, FormGroup, Checkbox as MuiCheckbox } from '@material-ui/core';
import PropTypes from 'prop-types';

export default function Checkbox({ label, value, onChange, className }) {
  return (
    <FormGroup container spacing={3} className={className}>
      <FormControlLabel
        control={<MuiCheckbox checked={value} onChange={onChange} color="primary" />}
        label={label}
      />
    </FormGroup>
  );
}

Checkbox.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  className: PropTypes.string,
};

Checkbox.defaultProps = {
  className: '',
};
