import styled from 'styled-components';
import { Grid } from '@material-ui/core';

export const Container = styled(Grid)`
  margin: 30px 0 0 0;
  display: flex;
  justify-content: center;
  border-radius: 5px;
  background-color: #ffffff;
  box-shadow: 0 2px 14px 0 rgba(0, 0, 0, 0.08);
  padding: 2em 3em;
  overflow: auto;
  overflow-x: hidden;

  @media (max-width: 768px) {
    padding: 2em;
  }
`;
