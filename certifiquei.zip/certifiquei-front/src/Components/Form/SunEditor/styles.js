import styled, { css } from 'styled-components';

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  ${s =>
    s.error
      ? css`
          border: 1px solid red;
          border-radius: 6px;
          .sun-editor {
            border: none;
          }
        `
      : ''};
  &.sun-editor-editable {
    padding: 0;
  }
  .sun-editor,
  .sun-editor .se-wrapper {
    border-radius: 6px;
  }
  .sun-editor .se-resizing-bar {
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
  }
  .sun-editor .se-toolbar {
    outline: none;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
  }
`;
