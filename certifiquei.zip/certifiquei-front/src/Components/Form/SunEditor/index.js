/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import SunEditor from 'suneditor-react';
import PropTypes from 'prop-types';
import SUN_EDITOR from 'suneditor/src/lang';
import 'suneditor/dist/css/suneditor.min.css';
import { Container } from './styles';

function SunEditorComponent({ initialValue, heightEditor, errors, mode, showToolbar, ...rest }) {
  return (
    <>
      <Container error={!!errors}>
        <SunEditor
          {...rest}
          setContents={initialValue}
          autoFocus={false}
          showToolbar={showToolbar}
          setOptions={{
            mode,
            height: heightEditor,
            lang: SUN_EDITOR.pt_br,
            buttonList: [
              [
                'undo',
                'redo',
                'font',
                'fontSize',
                'formatBlock',
                'paragraphStyle',
                'bold',
                'underline',
                'italic',
                'strike',
                'subscript',
                'superscript',
                'fontColor',
                'hiliteColor',
                'textStyle',
                'removeFormat',
                'outdent',
                'indent',
                'align',
                'horizontalRule',
                'list',
                'lineHeight',
                'table',
                'link',
                'image',
                'video',
                'fullScreen',
                'showBlocks',
                'codeView',
                'print',
              ],
            ],
          }}
        />
      </Container>
      <div style={{ color: '#ff0000', fontSize: '0.9rem' }}>{errors && errors.message}</div>
    </>
  );
}

SunEditorComponent.propTypes = {
  initialValue: PropTypes.string,
  heightEditor: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  errors: PropTypes.oneOfType([PropTypes.object, PropTypes.bool]),
  mode: PropTypes.string,
  showToolbar: PropTypes.bool,
};

SunEditorComponent.defaultProps = {
  initialValue: '',
  heightEditor: 200,
  errors: false,
  mode: 'inline',
  showToolbar: false,
};

export default SunEditorComponent;
