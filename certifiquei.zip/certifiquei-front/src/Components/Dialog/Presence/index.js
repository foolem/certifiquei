import React, { useEffect } from 'react';

import { useSelector, useDispatch } from 'react-redux';
import {
  Grid,
  Typography,
  IconButton,
  Dialog,
  DialogContent,
  DialogActions,
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import QrReader from 'react-qr-reader';
import { toast } from 'react-toastify';

import ActivityActions, { ActivitySelectors } from '../../../Modules/Activity';
import UserActions, { UserSelectors } from '../../../Modules/User';

import Btn from '../../Btn';
import { Padding } from '../styles';
import { Metrics, Colors } from '../../../Themes';

export default () => {
  const dispatch = useDispatch();

  const presence = useSelector(state => ActivitySelectors.getPresence(state));
  const user = useSelector(state => UserSelectors.getUser(state));
  const staff = user.staffs?.map(item => item.eventId === presence.data?.eventId);

  useEffect(() => {
    dispatch(UserActions.validateTokenRequest());
  }, [dispatch]);

  const toggleNav = () => dispatch(ActivityActions.togglePresenceNav());

  const handleError = () => {
    toast.error('Ops, ocorreu um erro ao ler o QR Code');
  };

  const handleScan = data => {
    if (!data) return;

    dispatch(
      ActivityActions.createPresenceRequest(presence.data.id, {
        userId: data,
        staffId: staff?.id,
      }),
    );
  };

  return (
    <Dialog scroll="body" onClose={toggleNav} open={presence.open}>
      <IconButton
        onClick={toggleNav}
        style={{
          position: 'absolute',
          right: Metrics.defaults.marginLittle,
          top: Metrics.defaults.marginLittle,
        }}
      >
        <CloseIcon style={{ fill: Colors.primaryBlue }} />
      </IconButton>

      <DialogContent style={{ overflow: 'hidden' }}>
        <Grid container alignItems="center" direction="column">
          <Typography variant="subtitle1">
            <b>Capturar presenças da atividade: {presence.data?.title}</b>
          </Typography>
          <Typography variant="body1" align="center">
            Leia o QR Code do estudante para contabilizar a presença
          </Typography>

          <QrReader
            delay={1000}
            onError={handleError}
            onScan={handleScan}
            style={{ width: '100%' }}
            className="Margin-t-2 Margin-b-2"
          />
        </Grid>
      </DialogContent>
      <DialogActions
        style={{
          padding: Metrics.dialog.actions.padding,
          marginTop: Metrics.defaults.marginBigger,
          justifyContent: 'center',
        }}
      >
        <Padding style={{ width: '70%', padding: 0 }}>
          <Grid container spacing={3} justify="center">
            <Grid item md={6}>
              <Btn onClick={toggleNav} secondary fullWidth fullHeight>
                Voltar
              </Btn>
            </Grid>
          </Grid>
        </Padding>
      </DialogActions>
    </Dialog>
  );
};
