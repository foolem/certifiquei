import styled from 'styled-components';
import Grid from '@material-ui/core/Grid';
import { Colors } from '../../../Themes';

export const Item = styled(Grid)`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  border: 1px solid ${props => (!!props.active ? Colors.primaryBlue : Colors.strongerGray)};
  background-color: ${Colors.lightGray};
  position: relative;
  padding: 1em !important;
  margin-right: 1em !important;
  margin-bottom: 1em !important;

  &:hover {
    border: 1px solid ${Colors.primaryBlue};
    cursor: pointer;
  }
`;
