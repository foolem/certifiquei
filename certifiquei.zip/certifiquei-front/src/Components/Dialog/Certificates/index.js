import React, { useState, useEffect } from 'react';

import {
  Grid,
  Typography,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@material-ui/core';

import CloseIcon from '@material-ui/icons/Close';
import Btn from '../../Btn';
import CertificateFrame from '../../Certificate/CertificateFrame';

import { Item } from './styles';
import { Metrics, Colors } from '../../../Themes';

export default ({ templates, certificates, open, setOpen, backText, action, actionText }) => {
  const [isTemplate, setIsTemplate] = useState(false);
  const [data, setData] = useState(certificates);
  const [selected, setSelected] = useState({});
  const isDisabled = !selected.id;

  useEffect(() => {
    if (isTemplate) {
      setData(templates);
    } else {
      setData(certificates);
    }
  }, [isTemplate, templates, certificates]);

  return (
    <Dialog fullWidth maxWidth="md" scroll="body" onClose={() => setOpen(false)} open={open}>
      <DialogTitle>
        Escolha seu certificado
        <Grid container spacing={4}>
          <Grid item xs={6} sm={5} md={4} className="Margin-t-1 Margin-b-1">
            <Btn
              onClick={() => setIsTemplate(false)}
              fullHeight
              secondary={isTemplate}
              className="Margin-r-1"
            >
              Seus certificados
            </Btn>
          </Grid>
          <Grid item xs={6} sm={7} md={8} className="Margin-t-1 Margin-b-1">
            <Btn onClick={() => setIsTemplate(true)} fullHeight secondary={!isTemplate}>
              Galeria
            </Btn>
          </Grid>
        </Grid>
      </DialogTitle>

      <IconButton
        onClick={() => setOpen(false)}
        style={{
          position: 'absolute',
          right: Metrics.defaults.marginLittle,
          top: Metrics.defaults.marginLittle,
        }}
      >
        <CloseIcon style={{ fill: Colors.primaryBlue }} />
      </IconButton>

      <DialogContent style={{ overflow: 'hidden' }}>
        <Grid container wrap="wrap" alignItems="center">
          {data.map((item, i) => (
            <Item item key={i} active={item.id === selected.id} onClick={() => setSelected(item)}>
              <CertificateFrame
                certificate={item.metadata.fields}
                certificateImage={item.metadata.background}
                preview
              />
              <Typography variant="caption">{item.name}</Typography>
            </Item>
          ))}
        </Grid>
      </DialogContent>
      <DialogActions className="Padding-1 Margin-t-2 Justify-end">
        <Btn onClick={() => setOpen(false)} fullHeight secondary>
          {backText}
        </Btn>
        <Btn
          onClick={() => action(selected, isTemplate)}
          variant="contained"
          fullHeight
          yellow
          disabled={isDisabled}
        >
          {actionText}
        </Btn>
      </DialogActions>
    </Dialog>
  );
};
