import React from 'react';

import {
  Grid,
  Typography,
  IconButton,
  Dialog,
  DialogContent,
  DialogActions,
} from '@material-ui/core';

import CloseIcon from '@material-ui/icons/Close';
import Btn from '../../Btn';
import { Padding } from '../styles';
import { Metrics, Colors } from '../../../Themes';

export default ({
  open,
  setOpen,
  title,
  text,
  backAction,
  action,
  backText,
  actionText,
  loading,
}) => {
  return (
    <Dialog scroll="body" onClose={() => setOpen(false)} open={open}>
      <IconButton
        onClick={() => setOpen(false)}
        style={{
          position: 'absolute',
          right: Metrics.defaults.marginLittle,
          top: Metrics.defaults.marginLittle,
        }}
      >
        <CloseIcon style={{ fill: Colors.primaryBlue }} />
      </IconButton>

      <DialogContent style={{ overflow: 'hidden' }}>
        <Grid container alignItems="center" direction="column">
          <Typography variant="subtitle1">
            <b>{title}</b>
          </Typography>
          <Padding style={{ width: '70%' }}>
            <Typography variant="body1" align="center">
              {text}
            </Typography>
          </Padding>
        </Grid>
      </DialogContent>
      <DialogActions
        style={{
          padding: Metrics.dialog.actions.padding,
          marginTop: Metrics.defaults.marginBigger,
          justifyContent: 'center',
        }}
      >
        <Padding style={{ width: '70%', padding: 0 }}>
          <Grid container spacing={3} justify="center">
            <Grid item md={6}>
              <Btn onClick={backAction} secondary fullWidth fullHeight>
                {backText}
              </Btn>
            </Grid>
            <Grid item md={6}>
              <Btn
                onClick={action}
                variant="contained"
                fullWidth
                fullHeight
                yellow
                disabled={loading}
                loading={loading}
              >
                {actionText}
              </Btn>
            </Grid>
          </Grid>
        </Padding>
      </DialogActions>
    </Dialog>
  );
};
