import styled from 'styled-components';
import { Metrics } from '../../Themes';

export const Padding = styled.div`
  padding: ${Metrics.defaults.padding};
`;
