import React from 'react';
import PropTypes from 'prop-types';

import { Grid, Link, Typography } from '@material-ui/core';

import Button from '../../Btn';

const Header = ({ title, description, href, actionText }) => {
  return (
    <Grid container justify="space-between">
      <Grid item>
        <Typography variant="h4">
          <b>{title}</b>
        </Typography>
        {description && <Typography variant="body1">{description}</Typography>}
      </Grid>
      {actionText && (
        <Grid item>
          <Link href={href} underline="none">
            <Button fullheight>{actionText}</Button>
          </Link>
        </Grid>
      )}
    </Grid>
  );
};

Header.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string,
  href: PropTypes.string.isRequired,
  actionText: PropTypes.string.isRequired,
};

Header.defaultProps = {
  description: '',
};

export default Header;
