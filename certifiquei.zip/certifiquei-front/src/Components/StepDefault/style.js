import styled from 'styled-components';
import { Stepper as CutomStep } from '@material-ui/core';

export const Stepper = styled(CutomStep)`
  .MuiStep-root {
    padding: 0;

    .MuiStepLabel-root {
      flex-direction: column-reverse;

      .MuiStepLabel-iconContainer {
        .MuiSvgIcon-root {
          z-index: 1;
          &.MuiStepIcon-completed {
            width: 16px;
          }

          text {
            display: none;
          }
          circle {
            cx: 12;
            cy: 12;
            r: 6;
            stroke-width: 2;
            stroke: #c4c9d7;
            fill: #c4c9d7;
          }
          &.MuiStepIcon-active {
            circle {
              stroke: #3f62a4;
              fill: white;
            }
          }
        }
      }

      .MuiStepLabel-labelContainer {
        .MuiTypography-root {
          color: #48484c;
          font-family: Roboto;
          font-size: 14px;
          font-weight: bold;
          margin: -40px 0 0 0;
        }
      }
    }

    .MuiStepConnector-root {
      &.Mui-disabled {
        .MuiStepConnector-line {
          border-color: #c4c9d7;
        }
      }

      .MuiStepConnector-line {
        border-color: #3f62a4;
        border-top-width: 2px;
      }
    }
  }
`;
