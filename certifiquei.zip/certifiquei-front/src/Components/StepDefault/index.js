import React from 'react';
import { Grid, Step, StepLabel } from '@material-ui/core';
import PropTypes from 'prop-types';
import { Stepper } from './style';

export default function StepDefault({ stepTitles, activeStep }) {
  return (
    <Grid container spacing={3} className="Margin-t-2 step-header">
      <Grid item md={12} xs={12} sm={12} lg={12} xl={12}>
        <Stepper activeStep={activeStep} alternativeLabel>
          {stepTitles.map((label, index) => (
            <Step key={label}>
              <StepLabel>{`${index + 1}. ${label}`}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </Grid>
    </Grid>
  );
}

StepDefault.propTypes = {
  stepTitles: PropTypes.arrayOf(PropTypes.string).isRequired,
  activeStep: PropTypes.number.isRequired,
};
