import styled from 'styled-components';

export const Frame = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 40px;
  background-color: ${props => (props.visualizador ? 'transparent' : '#fff')};
  border: ${props => (props.visualizador ? 'none' : '1px solid #e9e9e9')};

  ${props => !props.allowEdit && 'pointer-events: none;'}
  ${({ preview }) => preview && 'width: 15em; height: 10em;'}
  ${({ preview }) => preview && 'padding: 0px;'}

  .markdown {
    border-bottom: 2px solid black;
  }
  .markup {
    border-top: 2px solid black;
  }

  .image {
    position: relative;

    background-image: ${props => `url(${props.src})`};
    width: ${({ preview }) => (preview ? '100%' : '845px')};
    height: ${({ preview }) => (preview ? '100%' : '595px')};

    background-position: center center;
    background-repeat: no-repeat;
    background-size: contain;

    .elements {
      position: absolute;
      ${({ preview }) => preview && 'transform: scale(0.27);'}
    }
  }

  .box {
    .handle {
      text-align: end;
      cursor: -webkit-grab;
      position: absolute;
      top: -25px;
      right: 0;
    }
  }
  .react-draggable {
    &:hover {
      border: ${props => (!props.allowEdit ? 'none' : '1px solid  #c1c1c1')};
    }
    svg {
      color: #c1c1c1;
    }

    &:hover {
      z-index: 10;
    }
  }
  .react-draggable-dragging {
    .handle {
      cursor: -webkit-grabbing;
    }
  }
`;

export const Divider = styled.div`
  width: 100%;
  height: 2px;
  background-color: #1f1f1f;
`;

export const Sign = styled.div`
  width: 100%;
  img {
    width: 100%;
    height: 100%;
  }
`;
