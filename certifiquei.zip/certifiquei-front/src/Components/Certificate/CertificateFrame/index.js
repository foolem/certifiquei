import React from 'react';
import PropTypes from 'prop-types';

import Divider from '@material-ui/core/Divider';
import Grid from '@material-ui/core/Grid';
import CircularProgress from '@material-ui/core/CircularProgress';

import Drag from '../../Drag';
import QuillEditor from '../../QuillEditor';
import NoDrag from '../../Drag/NoDrag';

import { Frame, Sign } from './styles';

const CertificateFrame = ({
  allowEdit,
  targetRef,
  certificate,
  certificateImage,
  handlePosition,
  sendDragWidth,
  handleText,
  loading,
  preview,
}) => {
  const render = () =>
    certificate
      .filter(item => item.open)
      .map(item => {
        return (
          <Drag
            key={item.id}
            data={item}
            handlePosition={position => {
              handlePosition(item, position);
            }}
            sendDragWidth={sendDragWidth}
          >
            {item.img && (
              <Sign>
                <img src={item.img} alt="" />
              </Sign>
            )}

            {!item.img && (
              <>
                <QuillEditor
                  theme="bubble"
                  value={item.value}
                  className={item.className}
                  id={item.id}
                  field="value"
                  onChange={handleText}
                  readOnly={!allowEdit}
                />
                {item.divider && (
                  <NoDrag
                    key={item.divider.id}
                    id={item.divider.id}
                    x={item.divider.position.x}
                    y={item.divider.position.y}
                    style={item.divider.styles}
                    open={item.divider.open}
                  >
                    <Divider />
                  </NoDrag>
                )}
              </>
            )}
          </Drag>
        );
      });

  return (
    <Frame src={certificateImage} allowEdit={allowEdit} preview={preview}>
      {!!certificate && (
        <div className="image" ref={targetRef}>
          {preview ? <div className="elements">{render()}</div> : render()}
        </div>
      )}

      {loading && (
        <Grid container justify="center" className="Padding-3">
          <CircularProgress />
        </Grid>
      )}
    </Frame>
  );
};

CertificateFrame.propTypes = {
  loading: PropTypes.bool,
  allowEdit: PropTypes.bool,
  targetRef: PropTypes.func,
  certificate: PropTypes.array.isRequired,
  certificateImage: PropTypes.string.isRequired,
  handlePosition: PropTypes.func,
  sendDragWidth: PropTypes.func,
  handleText: PropTypes.func,
};

CertificateFrame.defaultProps = {
  loading: false,
  allowEdit: false,
  targetRef: () => {},
  handlePosition: () => {},
  sendDragWidth: () => {},
  handleText: () => {},
};

export default CertificateFrame;
