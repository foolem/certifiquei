import styled from 'styled-components';
import { Colors, Metrics } from '../../../Themes';

export const CollapseTitle = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-left: ${Metrics.defaults.padding};
  p {
    color: ${Colors.blue} !important;
    font-weight: bold;
  }
`;

export const ImagePlaceholder = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 8em;
  background-color: ${Colors.lightGray};
  border: 1px solid ${Colors.borderGray};
  ${({ background }) =>
    !!background &&
    `background-image: url('${background}'); background-size: cover;`}
`;
