import React, { useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Grid, Collapse, Typography, Divider, IconButton, Card, Link } from '@material-ui/core';
import ExpandMore from '@material-ui/icons/ExpandMore';
import ExpandLess from '@material-ui/icons/ExpandLess';

import CertificateActions, { CertificateSelectors } from '../../../../Modules/Certificate';
import { Metrics } from '../../../../Themes';
import { CollapseTitle, ImagePlaceholder } from '../styles';

const toBase64 = file =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = error => reject(error);
  });

export default function Customize(props) {
  const backgroundRef = useRef();
  const signOneRef = useRef();
  const signTwoRef = useRef();

  const dispatch = useDispatch();
  const certificate = useSelector(state => CertificateSelectors.getNewCertificate(state));

  const { background } = certificate;
  const signOne = certificate.fields.find(item => item.id === 10)?.img;
  const signTwo = certificate.fields.find(item => item.id === 11)?.img;

  const setBackground = async files => {
    const file = files[0];
    const base64Image = await toBase64(file);
    dispatch(CertificateActions.setBackground(base64Image));
  };

  const setSign = async (id, files) => {
    const file = files[0];
    const base64Image = await toBase64(file);
    dispatch(CertificateActions.setSign(id, base64Image));
  };

  return (
    <Grid item xs={12}>
      <Card variant="outlined">
        <CollapseTitle>
          <Typography variant="body1">
            <b>Personalização</b>
          </Typography>
          <IconButton onClick={() => props.setCollapse(!props.collapse)}>
            {!props.collapse ? <ExpandMore color="primary" /> : <ExpandLess color="primary" />}
          </IconButton>
        </CollapseTitle>
        <Collapse in={props.collapse} style={{ padding: '0 ' + Metrics.defaults.padding }}>
          <Divider />

          <Typography variant="body1" style={{ marginTop: Metrics.defaults.margin }}>
            <b>Imagem de fundo</b>
          </Typography>

          <Grid container spacing={3}>
            <Grid item md={6}>
              <ImagePlaceholder background={background}>
                <Link onClick={() => backgroundRef.current.click()}>Escolha a imagem</Link>
              </ImagePlaceholder>
              <input
                className="Hidden"
                ref={backgroundRef}
                type="file"
                accept="image/*"
                onChange={e => setBackground(e.target.files)}
              />
            </Grid>
            <Grid item md={6}>
              <Typography variant="body1" style={{ marginTop: Metrics.defaults.margin }}>
                Caso queira customizar o background, insira uma imagem com tamanho mínimo de 845x595
                nos formatos PNG ou JPEG.
              </Typography>
            </Grid>
          </Grid>

          <Typography variant="body1" style={{ marginTop: Metrics.defaults.margin }}>
            <b>Assinatura responsável principal</b>
          </Typography>

          <Grid container spacing={3}>
            <Grid item md={6}>
              <ImagePlaceholder background={signOne}>
                <Link onClick={() => signOneRef.current.click()}>Escolha a imagem</Link>
              </ImagePlaceholder>
              <input
                className="Hidden"
                ref={signOneRef}
                type="file"
                accept="image/*"
                onChange={e => setSign(10, e.target.files)}
              />
            </Grid>
            <Grid item md={6}>
              <Typography variant="body1" style={{ marginTop: Metrics.defaults.margin }}>
                Para colocar uma assinatura digital escolha o arquivo PNG ou JPEG.
              </Typography>
            </Grid>
          </Grid>

          <Typography variant="body1" style={{ marginTop: Metrics.defaults.margin }}>
            <b>Assinatura responsável secundário</b>
          </Typography>

          <Grid container spacing={3}>
            <Grid item md={6}>
              <ImagePlaceholder background={signTwo}>
                <Link onClick={() => signTwoRef.current.click()}>Escolha a imagem</Link>
              </ImagePlaceholder>
              <input
                className="Hidden"
                ref={signTwoRef}
                type="file"
                accept="image/*"
                onChange={e => setSign(11, e.target.files)}
              />
            </Grid>
            <Grid item md={6}>
              <Typography variant="body1" style={{ marginTop: Metrics.defaults.margin }}>
                Para colocar uma assinatura digital escolha o arquivo PNG ou JPEG.
              </Typography>
            </Grid>
          </Grid>
        </Collapse>
      </Card>
    </Grid>
  );
}
