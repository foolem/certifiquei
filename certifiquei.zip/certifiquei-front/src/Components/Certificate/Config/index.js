/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Grid, Link, FormGroup, TextField } from '@material-ui/core';

import Users from './Users';
import Info from './Info';
import Customize from './Customize';
import Popover from '../../Popover';

import { Metrics } from '../../../Themes';

const Config = ({
  anchorEl,
  toggleConfig,
  name,
  setName,
  resetConfig,
  isAdmin,
  allUsers,
  selectedUsers,
  setSelectedUsers,
}) => {
  const [collapse1, setCollapse1] = useState(false);
  const [collapse2, setCollapse2] = useState(false);
  const [collapse3, setCollapse3] = useState(false);
  const btn = document.querySelector('[aria-describedby="config"]');
  const scrollHeight = `${window.innerHeight - 50 - (btn ? btn.offsetHeight : 0)}px`;

  return (
    <Popover
      id="config"
      open={!!anchorEl}
      anchorEl={anchorEl}
      onClose={toggleConfig}
      style={{ maxHeight: scrollHeight }}
      className="Padding-3"
    >
      <Grid container spacing={3} direction="column">
        <Grid item xs={12}>
          <FormGroup>
            <TextField
              variant="outlined"
              label="Nome do certificado"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              fullWidth
            />
          </FormGroup>
        </Grid>

        {isAdmin && (
          <Users
            collapse={collapse1}
            setCollapse={setCollapse1}
            allUsers={allUsers}
            selectedUsers={selectedUsers}
            setSelectedUsers={setSelectedUsers}
          />
        )}
        <Info collapse={collapse2} setCollapse={setCollapse2} />
        <Customize collapse={collapse3} setCollapse={setCollapse3} />
      </Grid>

      <Grid container justify="flex-end" style={{ marginTop: Metrics.defaults.margin }}>
        <Grid item md={6}>
          <Link onClick={resetConfig} color="error">
            Resetar configurações
          </Link>
        </Grid>
        <Grid item md={6} style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <Link onClick={toggleConfig}>Aplicar</Link>
        </Grid>
      </Grid>
    </Popover>
  );
};

Config.propTypes = {
  anchorEl: PropTypes.element.isRequired,
  toggleConfig: PropTypes.func.isRequired,
  name: PropTypes.string.isRequired,
  setName: PropTypes.func.isRequired,
  resetConfig: PropTypes.func.isRequired,
  isAdmin: PropTypes.bool,
  allUsers: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string,
      firstName: PropTypes.string,
      lastName: PropTypes.string,
      email: PropTypes.string,
    }),
  ),
  selectedUsers: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string,
      firstName: PropTypes.string,
      lastName: PropTypes.string,
      email: PropTypes.string,
    }),
  ),
  setSelectedUsers: PropTypes.func,
};

Config.defaultProps = {
  isAdmin: false,
  selectedUsers: [],
  setSelectedUsers: null,
  allUsers: [],
};

export default Config;
