/* eslint-disable react/prop-types */
import React from 'react';

import {
  Grid,
  Collapse,
  Typography,
  Divider,
  IconButton,
  Card,
  Select,
  MenuItem,
  ListItemText,
  Checkbox,
} from '@material-ui/core';
import ExpandMore from '@material-ui/icons/ExpandMore';
import ExpandLess from '@material-ui/icons/ExpandLess';

import { Metrics } from '../../../../Themes';
import { CollapseTitle } from '../styles';

export default ({ collapse, setCollapse, allUsers, selectedUsers, setSelectedUsers }) => {
  return (
    <Grid item xs={12}>
      <Card variant="outlined">
        <CollapseTitle>
          <Typography variant="body1">
            <b>Usuários</b>
          </Typography>
          <IconButton onClick={() => setCollapse(!collapse)}>
            {!collapse ? <ExpandMore color="primary" /> : <ExpandLess color="primary" />}
          </IconButton>
        </CollapseTitle>
        <Collapse in={collapse} style={{ padding: `0 ${Metrics.defaults.padding}` }}>
          <Typography variant="body1" className="Margin-b-1">
            O template estará disponível para os seguintes usuários:
          </Typography>
          <Select
            multiple
            variant="outlined"
            value={selectedUsers}
            onChange={e => setSelectedUsers(e.target.value)}
            renderValue={selected =>
              selected.map(item => allUsers.find(inner => inner.id === item).firstName).join(', ')
            }
            fullWidth
          >
            {allUsers.map(item => (
              <MenuItem key={item.id} value={item.id}>
                <Checkbox checked={selectedUsers.includes(item.id)} />
                <ListItemText primary={`${item.firstName} ${item.lastName} - ${item.email}`} />
              </MenuItem>
            ))}
          </Select>
          <Typography variant="body1" className="Margin-t-1 Margin-b-1">
            Caso não escolha nenhum usuário, estará disponível para todos
          </Typography>
        </Collapse>
      </Card>
    </Grid>
  );
};
