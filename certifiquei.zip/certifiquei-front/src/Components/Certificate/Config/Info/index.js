import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import {
  Grid,
  Collapse,
  Typography,
  Divider,
  IconButton,
  Checkbox,
  FormGroup,
  FormControlLabel,
  Card,
} from '@material-ui/core';
import ExpandMore from '@material-ui/icons/ExpandMore';
import ExpandLess from '@material-ui/icons/ExpandLess';

import CertificateActions, { CertificateSelectors } from '../../../../Modules/Certificate';

import { Metrics } from '../../../../Themes';
import { CollapseTitle } from '../styles';

export default ({ collapse, setCollapse }) => {
  const dispatch = useDispatch();
  const certificate = useSelector(state => CertificateSelectors.getNewCertificate(state));

  const enableComponent = id => {
    dispatch(CertificateActions.enableComponent(id));
  };
  const enableDivider = id => {
    dispatch(CertificateActions.enableDivider(id));
  };
  const hasId = id => certificate.fields.find(item => item.id === id)?.open;
  const hasDividerId = id => !!certificate.fields.find(item => item.id === id)?.divider;

  return (
    <Grid item xs={12}>
      <Card variant="outlined">
        <CollapseTitle>
          <Typography variant="body1">
            <b>Informações</b>
          </Typography>
          <IconButton onClick={() => setCollapse(!collapse)}>
            {!collapse ? <ExpandMore color="primary" /> : <ExpandLess color="primary" />}
          </IconButton>
        </CollapseTitle>
        <Collapse in={collapse} style={{ padding: '0 ' + Metrics.defaults.padding }}>
          <Divider />
          <FormGroup row>
            <FormControlLabel
              control={
                <Checkbox color="primary" checked={hasId(0)} onChange={() => enableComponent(0)} />
              }
              label="Título do certificado"
            />
            <FormControlLabel
              control={
                <Checkbox color="primary" checked={hasId(1)} onChange={() => enableComponent(1)} />
              }
              label="Nome do curso"
            />
          </FormGroup>

          <FormGroup row>
            <FormControlLabel
              control={
                <Checkbox color="primary" checked={hasId(3)} onChange={() => enableComponent(3)} />
              }
              label="Texto"
            />

            <FormControlLabel
              control={
                <Checkbox color="primary" checked={hasId(4)} onChange={() => enableComponent(4)} />
              }
              label="Data de emissão"
            />
          </FormGroup>

          <Typography variant="body1" style={{ marginTop: Metrics.defaults.margin }}>
            <b>Aluno</b>
          </Typography>

          <FormGroup row>
            <FormControlLabel
              control={
                <Checkbox color="primary" checked={hasId(2)} onChange={() => enableComponent(2)} />
              }
              label="Nome do aluno"
            />
            <FormControlLabel
              control={
                <Checkbox
                  color="primary"
                  checked={hasDividerId(2)}
                  onChange={() => enableDivider(2)}
                />
              }
              label="Linha de separação"
            />
          </FormGroup>

          <Typography variant="body1" style={{ marginTop: Metrics.defaults.margin }}>
            <b>Responsável principal</b>
          </Typography>

          <FormGroup row>
            <FormControlLabel
              control={
                <Checkbox color="primary" checked={hasId(5)} onChange={() => enableComponent(5)} />
              }
              label="Nome do responsável"
            />
            <FormControlLabel
              control={
                <Checkbox
                  color="primary"
                  checked={hasDividerId(5)}
                  onChange={() => enableDivider(5)}
                />
              }
              label="Linha de separação"
            />
            <FormControlLabel
              control={
                <Checkbox
                  color="primary"
                  checked={hasId(10)}
                  onChange={() => enableComponent(10)}
                />
              }
              label="Espaço para assinatura"
            />
          </FormGroup>

          <Typography variant="body1" style={{ marginTop: Metrics.defaults.margin }}>
            <b>Responsável secundário</b>
          </Typography>

          <FormGroup row>
            <FormControlLabel
              control={
                <Checkbox color="primary" checked={hasId(6)} onChange={() => enableComponent(6)} />
              }
              label="Nome do responsável"
            />
            <FormControlLabel
              control={
                <Checkbox
                  color="primary"
                  checked={hasDividerId(6)}
                  onChange={() => enableDivider(6)}
                />
              }
              label="Linha de separação"
            />
            <FormControlLabel
              control={
                <Checkbox
                  color="primary"
                  checked={hasId(11)}
                  onChange={() => enableComponent(11)}
                />
              }
              label="Espaço para assinatura"
            />
          </FormGroup>
        </Collapse>
      </Card>
    </Grid>
  );
};
