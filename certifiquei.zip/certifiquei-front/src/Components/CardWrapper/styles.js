import styled from 'styled-components';
import { Colors } from '../../Themes';

export const Component = styled.div`
  display: flex;
  flex-direction: column;
  .MuiPaper-outlined {
    border-bottom: none;
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  tbody tr:nth-child(odd) {
    background-color: ${Colors.white} !important;
  }

  .MuiTableCell-root {
    color: ${Colors.text} !important;
  }

  .MuiTableBody-root {
    .MuiTableCell-body {
      border-bottom: 1px solid ${Colors.strongerGray} !important;
    }
    .MuiTableRow-root:last-child {
      .MuiTableCell-body {
        border-bottom: 0 !important;
      }
    }
  }
`;
