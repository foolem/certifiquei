import React from 'react';
import { Component } from './styles';

export default function CardWrapper(props) {
  return <Component>{props.children}</Component>;
}
