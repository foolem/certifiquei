import React, { useState } from 'react';
import PropTypes from 'prop-types';

import { IconButton } from '@material-ui/core';
import SearchIcon from '@material-ui/icons/SearchRounded';

import { Adornment, Container, Field } from './styles';

const Search = ({ label, onSubmit }) => {
  const [state, setState] = useState('');

  const handleChange = event => {
    setState(event.target.value);
  };

  return (
    <Container
      onSubmit={e => {
        e.preventDefault();
        onSubmit(state);
      }}
    >
      <Field
        fullWidth
        label={label}
        type="text"
        variant="filled"
        onChange={handleChange}
        onBlur={() => {}}
        value={state}
        InputProps={{
          endAdornment: (
            <Adornment position="end">
              <IconButton edge="end" onClick={() => onSubmit(state)}>
                <SearchIcon color="primary" />
              </IconButton>
            </Adornment>
          ),
        }}
      />
    </Container>
  );
};

Search.propTypes = {
  label: PropTypes.string,
  onSubmit: PropTypes.func.isRequired,
};

Search.defaultProps = {
  label: '',
};

export default Search;
