import { IconButton, InputAdornment, TextField } from '@material-ui/core';
import styled from 'styled-components';

export const Container = styled.form`
  display: flex;
  width: 100%;
  align-items: center;

  .MuiFormLabel-root {
    top: 5%;
    &.Mui-focused,
    &.MuiFormLabel-filled {
      display: none;
    }
  }

  .MuiInputBase-root {
    input {
      padding: 18px;
    }
  }

  .MuiFilledInput-underline:after {
    background-color: transparent;
  }
  .MuiFilledInput-underline.Mui-error:after {
    background-color: transparent;
  }
  .MuiFilledInput-underline:hover:before {
    border: transparent;
  }
  .MuiFilledInput-underline:after {
    border-bottom: transparent;
  }
  .MuiFormLabel-root {
    color: #7f838e;
  }
  .MuiFormHelperText-root {
    color: ${props => (props.error ? '#f44336' : '#c4c9d7')};
  }
  .MuiFilledInput-root {
    background-color: #fff;
    border: ${props => (props.error ? '1px solid #f44336' : '1px solid #eef0f4')};
    border-radius: 6px;
  }
  .MuiFilledInput-root.Mui-focused {
    background-color: #fff;
    border: 1px solid #486aab;
  }
  .MuiFilledInput-underline:before {
    border-bottom: transparent;
  }
  .MuiFilledInput-root:hover {
    background-color: #fff;
    border: 1px solid #486aab;
  }
  .MuiFilledInput-root:focus {
    background-color: #fff;
    border: 1px solid #486aab;
  }
  .MuiInputBase-input {
    &:-webkit-autofill {
      transition-delay: 9999s;
    }
  }
  img {
    cursor: pointer;
    width: 15px;
    height: 18px;
  }
`;

export const Field = styled(TextField)``;

export const Adornment = styled(InputAdornment)``;

export const Icon = styled(IconButton)`
  svg {
    color: #265ca5;
  }
`;
