import styled from 'styled-components';
import Popover from '@material-ui/core/Popover';

export const Modal = styled(Popover)`
  .gray-color {
    color: #a4abb7;
  }
  &.MuiPopover-root {
    background: #00000025;

    .line {
      width: 100%;
      height: 1px;
      background-color: #eff1f5;
      margin: 15px 0;
    }

    .MuiPopover-paper {
      overflow: hidden;
      width: 100%;
      max-width: 700px;
      box-shadow: none;
      background: #fff0;

      .container {
        margin: 20px;
        min-height: 60px;
        /* max-height: 465px; */
        max-height: 70vh;
        overflow-y: auto;
        background-color: #ffffff;
        box-shadow: 0 2px 14px 0 rgba(0, 0, 0, 0.08);
        padding: 35px;

        ::before {
          content: '';
          position: absolute;
          top: 10px;
          right: 65px;
          height: 20px;
          width: 20px;
          background: #fff;
          transform: rotate(44deg);
          box-shadow: -3px -3px 6px -2px rgba(0, 0, 0, 0.14);
        }

        .row {
          display: flex;
          margin: 0 0 15px 0;

          .label {
            margin: 0;
            width: 100%;
            max-width: 90px;
            display: flex;
            align-items: center;

            font-size: 14px;
            font-weight: bold;
          }

          .field {
            max-width: 300px;
            width: 100%;
            display: flex;

            .MuiAutocomplete-root {
              .MuiInputBase-root {
                padding: 6px;
                padding-right: 65px;
              }
            }

            .date {
              border: 1px solid #eef0f5;
              input {
                width: 60%;
                font-size: 13px;
              }
            }
            .until {
              margin: 18px 15px;
            }
          }
        }

        .dynamic {
          display: flex;
          flex-direction: column;
          max-height: 315px;
          overflow: auto;
        }

        .fixed {
          display: flex;
          flex-direction: column;
          padding: 20px 0 0 0;
          margin: 10px 0 0 0;

          .actions {
            justify-content: space-between;
            margin: 15px 0 0 0;
            p {
              font-size: 14px;
              margin: 0;
              cursor: pointer;

              :hover {
                text-decoration: underline;
              }
            }

            .clear {
              p {
                color: #d18181;
              }
            }

            .apply-cancel {
              display: flex;

              p {
                color: #828691;
                margin: 0 24px 0 0;

                :not(:first-child) {
                  margin: 0;
                  color: #466aad;
                  font-weight: bold;
                }
              }
            }
          }
        }
      }
    }
  }
`;

export const ActionText = styled.p`
  cursor: pointer;
  color: #466aad;

  font-size: 12px;
  font-weight: bold;
  text-align: center;
  text-decoration: underline;

  &:hover {
    color: #000000;
  }
`;
