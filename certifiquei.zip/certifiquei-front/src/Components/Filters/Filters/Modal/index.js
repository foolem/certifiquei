import React from 'react';
import PropTypes from 'prop-types';
import { TextField, InputLabel, MenuItem, Select, Typography, Grid } from '@material-ui/core';

import { Modal, ActionText } from './style';

export default function ModalActions({
  open,
  data,
  filters,
  onChange,
  handleClose,
  anchorEl,
  clearFilter,
  cancelFilter,
  applyFilter,
  anchorOrigin,
  transformOrigin,
}) {
  const handleChange = (value, name) => {
    const newData = { ...data };
    newData[name] = value;

    onChange(newData);
  };

  const RenderFilter = ({ type, name }) => {
    switch (type) {
      case 'select':
        return (
          <SelectFilter
            data={data[name]}
            filter={filters[name]}
            onChange={value => handleChange(value, name)}
          />
        );
      case 'dateRange':
        return (
          <DateRangeFilter
            data={data[name]}
            filter={filters[name]}
            onChange={value => handleChange(value, name)}
          />
        );
      default:
        return <></>;
    }
  };

  return (
    <Modal
      open={open}
      anchorEl={anchorEl}
      onClose={handleClose}
      anchorOrigin={anchorOrigin}
      transformOrigin={transformOrigin}
    >
      <div className="container">
        {Object.values(filters).map(item => (
          <RenderFilter key={item.name} type={item.type} name={item.name} />
        ))}

        <Fixed clearFilter={clearFilter} cancelFilter={cancelFilter} applyFilter={applyFilter} />
      </div>
    </Modal>
  );
}

const SelectFilter = ({ data, filter, onChange }) => {
  const handleChange = value => {
    onChange(value);
  };

  return (
    <>
      <InputLabel>{filter.label}</InputLabel>
      <Select
        variant="outlined"
        fullWidth
        fullHeight
        multiple
        value={data}
        onChange={e => handleChange(e.target.value)}
        className="Margin-b-1"
      >
        {filter.options.map(item => (
          <MenuItem key={item.value} value={item.value}>
            {item.label}
          </MenuItem>
        ))}
      </Select>
    </>
  );
};

const DateRangeFilter = ({ data, filter, onChange }) => {
  const handleChange = (value, type) => {
    const newData = { ...data };
    newData[type] = value;
    onChange(newData);
  };

  return (
    <>
      <InputLabel>{filter.label}</InputLabel>
      <Grid container alignItems="center" className="Margin-b-1">
        <Grid item xs={5}>
          <TextField
            variant="outlined"
            fullWidth
            fullHeight
            type="date"
            value={data.start}
            onChange={e => handleChange(e.target.value, 'start')}
          />
        </Grid>
        <Grid container justify="center" alignItems="center" item xs={2}>
          <Typography>até</Typography>
        </Grid>
        <Grid item xs={5}>
          <TextField
            variant="outlined"
            fullWidth
            fullHeight
            type="date"
            value={data.end}
            onChange={e => handleChange(e.target.value, 'end')}
          />
        </Grid>
      </Grid>
    </>
  );
};

const Fixed = ({ cancelFilter, applyFilter }) => {
  return (
    <div className="fixed">
      <div className="row actions">
        <div className="apply-cancel">
          <ActionText onClick={cancelFilter}>Cancelar</ActionText>
          <ActionText onClick={applyFilter}>Aplicar</ActionText>
        </div>
      </div>
    </div>
  );
};

Fixed.propTypes = {
  cancelFilter: PropTypes.func.isRequired,
  applyFilter: PropTypes.func.isRequired,
};

ModalActions.propTypes = {
  open: PropTypes.bool,
  handleClose: PropTypes.func,
  anchorEl: PropTypes.shape({
    component: PropTypes.instanceOf(React.Component),
  }).isRequired,
  clearFilter: PropTypes.func.isRequired,
  cancelFilter: PropTypes.func.isRequired,
  applyFilter: PropTypes.func.isRequired,
};

ModalActions.defaultProps = {
  open: false,
  handleClose: null,
};
