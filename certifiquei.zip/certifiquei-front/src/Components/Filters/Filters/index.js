import React, { useEffect, useState } from 'react';

import SearchIcon from '@material-ui/icons/SearchRounded';

import Modal from './Modal';
import Button from '../../Btn';

const Filters = ({ data, filters, onChange }) => {
  const [state, setState] = useState(data);
  const [anchorEl, setAnchorEl] = useState(null);

  useEffect(() => {
    setState(data);
  }, [data]);

  const handleChange = meta => {
    setState(meta);
  };

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const clearFilter = () => setState(data);

  const cancelFilter = () => handleClose();

  const applyFilter = () => onChange(state);

  return (
    <>
      <Button
        secondary
        fullHeight
        endIcon={<SearchIcon color="primary" />}
        onClick={e => handleClick(e)}
      >
        Filtros
      </Button>

      <Modal
        open={!!anchorEl}
        anchorEl={anchorEl}
        handleClose={handleClose}
        data={state}
        filters={filters}
        onChange={handleChange}
        clearFilter={() => {
          clearFilter();
        }}
        cancelFilter={cancelFilter}
        applyFilter={() => {
          applyFilter();
          cancelFilter();
        }}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      />
    </>
  );
};

Filters.propTypes = {};

Filters.defaultProps = {};

export default Filters;
