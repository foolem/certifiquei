import styled from 'styled-components';
import { Metrics, Colors } from '../../Themes';

export const Component = styled.div`
  position: relative;
  padding: ${Metrics.defaults.padding};
  width: 100%;
  color: ${Colors.text};
  background-color: ${Colors.white};

  &:hover {
    cursor: pointer;
    color: ${Colors.blue};
    font-weight: bold;
    background-color: ${Colors.lightGray};
  }
`;
