import React from 'react';
import { Component } from './styles';

export default function PopoverButton(props) {
  return <Component {...props}>{props.children}</Component>;
}
