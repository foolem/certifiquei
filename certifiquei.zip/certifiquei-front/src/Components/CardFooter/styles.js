import styled from 'styled-components';
import { Colors } from '../../Themes';

export const Component = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: ${Colors.lightGray};
  padding: 1em;
  border-bottom: 1px solid ${Colors.borderGray};
  border-left: 1px solid ${Colors.borderGray};
  border-right: 1px solid ${Colors.borderGray};
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
`;
