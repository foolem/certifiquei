import React from 'react';
import { Component } from './styles';

export default function CardFooter(props) {
  return <Component style={props.style}>{props.children}</Component>;
}
