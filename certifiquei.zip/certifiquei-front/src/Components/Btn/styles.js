import styled from 'styled-components';
import { Button } from '@material-ui/core';
import { Colors, Metrics } from '../../Themes';

export const Component = styled(Button)`
  height: ${props => (!!props.fullHeight ? '100%' : 'fit-content')};
  padding: ${props =>
    !!props.paddingLittle ? Metrics.button.paddingLittle : Metrics.button.padding};
  text-transform: none !important;
  color: ${props => (props.secondary ? Colors.primaryTextBlue : Colors.white)} !important;
  font-weight: bold !important;
  background-color: ${props => (props.secondary ? Colors.white : Colors.primaryBlue)} !important;
  box-shadow: 0 2px 14px 0 rgba(0, 0, 0, 0.13) !important;
  ${({ disabled }) => !!disabled && `opacity: 0.5;`}
`;
