import React from 'react';
import CircularProgress from '@material-ui/core/CircularProgress';

import { Component } from './styles';

export default function Btn(props) {
  return (
    <Component
      {...props}
      endIcon={
        props.loading ? <CircularProgress size={20} className="color-black" /> : props.endIcon
      }
    >
      {props.children}
    </Component>
  ); 
}
