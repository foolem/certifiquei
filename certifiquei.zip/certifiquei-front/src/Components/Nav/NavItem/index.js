import React, { useState } from 'react';
import {
  Link,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Collapse,
  IconButton,
} from '@material-ui/core';

import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ExpandLessIcon from '@material-ui/icons/ExpandLess';

import { ListItemTitle, Container } from '../styles';

export default ({ data, userType }) => {
  const isActive = !!data.activePage && window.location.pathname.includes(data.activePage);
  const [collapse, setCollapse] = useState(isActive);

  const navSubmenus = data.submenus;

  const collapseOrRedirect = () => {
    if (navSubmenus) {
      return setCollapse(!collapse);
    }
    return window.location.replace(`${data.route}`);
  };

  const Component = () => (
    <ListItem selected={isActive}>
      <div className="container-row">
        <ListItemIcon>
          <img src={data.icon} alt="" />
        </ListItemIcon>
        <ListItemTitle className="title-text" onClick={() => collapseOrRedirect()}>
          <ListItemText primary={data.name} />
          {navSubmenus ? (
            !collapse ? (
              <IconButton>
                <ExpandMoreIcon />
              </IconButton>
            ) : (
              <IconButton>
                <ExpandLessIcon />
              </IconButton>
            )
          ) : null}
        </ListItemTitle>
      </div>
      {navSubmenus ? (
        <Container>
          <Collapse in={collapse} className="Collapse">
            <List component="div" className="Nested">
              {navSubmenus.map(menu => (
                <Link href={menu.route} className="No-decoration">
                  <ListItem>
                    <ListItemText primary={menu.name} className={menu.subroute && 'Subroute'} />
                  </ListItem>
                </Link>
              ))}
            </List>
          </Collapse>
        </Container>
      ) : null}
    </ListItem>
  );

  if (userType === 'manager' || !data.managerRoute) {
    return <Component />;
  }

  return <></>;
};
