import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { List, IconButton, Typography } from '@material-ui/core';

import LogoutIcon from '@material-ui/icons/ExitToApp';
import Menu from '@material-ui/icons/Menu';
import Close from '@material-ui/icons/Close';

import UserActions, { UserSelectors } from '../../Modules/User';

import { Body, MobileNav, Nav, Logout, Div, Heading } from './styles';
import NavItem from './NavItem';
import menuArray from './data';

export default () => {
  const [open, setOpen] = useState(false);

  const dispatch = useDispatch();
  const user = useSelector(state => UserSelectors.getUser(state));

  const logout = () => {
    dispatch(UserActions.logoutRequest());
  };

  const Navitems = menuArray.map(data => <NavItem data={data} userType={user.userType} />);

  return (
    <>
      <MobileNav>
        <IconButton onClick={() => setOpen(!open)}>{open ? <Close /> : <Menu />}</IconButton>
      </MobileNav>

      <Body open={open}>
        <Nav>
          <List>
            <Heading>
              <Typography variant="subtitle1">{`Olá ${user.firstName}`}</Typography>
            </Heading>

            <>{Navitems}</>
          </List>
          <Div>
            <Logout onClick={() => logout()} className="Margin-b-3">
              <Link className="No-decoration">
                <LogoutIcon />
                Sair
              </Link>
            </Logout>
          </Div>
        </Nav>
      </Body>
    </>
  );
};
