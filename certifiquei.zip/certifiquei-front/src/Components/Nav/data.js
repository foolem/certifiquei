import { Images } from '../../Themes';

export default [
  {
    name: 'Seu Painel',
    activePage: '',
    managerRoute: false,
    icon: Images.icons.home,
    route: '/',
  },
  {
    name: 'Organização',
    activePage: 'organizing',
    managerRoute: true,
    submenus: [
      {
        route: '/organizing/events',
        name: 'Eventos',
      },
      {
        route: '/organizing/activities',
        name: 'Atividades',
        subroute: true,
      },
      {
        route: '/organizing/students',
        name: 'Participantes',
        subroute: true,
      },
      {
        route: '/organizing/certificates',
        name: 'Certificados',
      },
    ],
    icon: Images.icons.organizing,
  },

  {
    name: 'Conta',
    activePage: 'settings',
    managerRoute: false,
    icon: Images.icons.settings,
    route: '/settings',
  },
];
