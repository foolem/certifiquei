import styled from 'styled-components';
import { Colors, Metrics, Fonts } from '../../Themes';

export const Nav = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 100%;
  height: 100%;

  .MuiListItem-root {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    align-items: flex-start;
    justify-content: center;
    margin-top: ${Metrics.defaults.marginTop};
    padding: 0;

    span {
      color: ${Colors.gray};
    }
    .MuiTypography-body1 {
      font-size: ${Fonts.drawerText};
    }
    .MuiListItemIcon-root {
      height: 50px;
      display: inline-flex;
      align-self: flex-start;
      img {
        width: 20px;
      }
    }

    // Navigation - Hover
    &:hover {
      .title-text {
        span {
          color: ${Colors.white};

          svg {
            fill: white;
          }
        }
      }
      cursor: pointer;
      background-color: ${Colors.lightBlue};

      .container-row {
        background: linear-gradient(180deg, #3f2f5b 0%, #3f2f6f 100%) !important;

        .title {
          color: ${Colors.white}!important;
          font-weight: bold;
        }

        .MuiListItemIcon-root {
          filter: invert(80) sepia() opacity() blur() brightness(100) contrast() grayscale()
            hue-rotate();
        }
      }
    }
  }

  // Navigation - Selected
  .Mui-selected {
    .title-text {
      span {
        color: ${Colors.white};
      }
    }
    cursor: pointer;
    background-color: ${Colors.lightBlue}!important;

    .container-row {
      background: linear-gradient(180deg, #3f2f5b 0%, #3f2f6f 100%) !important;

      .title {
        color: ${Colors.white}!important;
        font-weight: bold;
      }

      .MuiListItemIcon-root {
        filter: invert(80) sepia() opacity() blur() brightness(100) contrast() grayscale()
          hue-rotate();
      }
    }
  }

  .container-row {
    display: flex;
    border-radius: 0 8px 10px 0 !important;
    flex-direction: row;
    height: 50px;
    width: 100%;
    padding-left: 3em;
    padding-right: 1em;

    .MuiListItemText-primary {
      font-weight: bold !important;
    }

    &:hover {
      cursor: pointer;
      background: linear-gradient(180deg, #3f2f5b 0%, #3f2f6f 100%) !important;
      span {
        color: ${Colors.white} !important;
        font-weight: bold !important;
      }
      .MuiListItemIcon-root {
        filter: invert(80) sepia() opacity() blur() brightness(100) contrast() grayscale()
          hue-rotate();
      }
    }
  }

  // Navigation - Collapse body
  .Nested {
    width: 100%;
    padding: 8px 0;

    span {
      color: ${Colors.blue} !important;
    }

    .MuiListItem-root {
      padding: 4px 0;

      .MuiListItemText-root {
        font-size: 1.2em !important;
      }

      &:hover {
        cursor: pointer;
        span {
          color: ${Colors.primaryBlue} !important;
          font-weight: bold;
        }
      }
    }
  }
`;

export const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  width: 100%;
`;

export const ListItemTitle = styled.div`
  width: 100%;
  display: inline-flex;
  justify-content: space-between;
  align-items: center;
  svg {
    fill: ${Colors.primaryBlue};
  }
  .MuiIconButton-root {
    padding: 5px !important;
  }
`;

export const Logout = styled.div`
  a {
    display: flex;
    align-items: center;
    font-weight: bold !important;
    margin-top: ${Metrics.defaults.margin};
    svg {
      margin-right: ${Metrics.defaults.marginLittle};
      color: ${Colors.primaryBlue}!important;
    }import metrics from '../../Themes/Metrics';

  }
`;

export const Heading = styled.div`
  padding-left: 3em;
  margin-bottom: 40px;

  .Logo {
    width: 72px;
    height: 72px;
    border: 2px solid #ffffff;
    margin-right: auto;
    margin-bottom: ${Metrics.defaults.margin};
    border-radius: 50%;
    box-shadow: 0 2px 20px 0 rgba(107, 104, 104, 0.15);
    object-fit: contain;
  }

  .heading-title {
    color: ${Colors.primaryTextBlack};
    font-size: ${Fonts.subtitle};
    font-weight: bold;
    letter-spacing: 0;
    line-height: 19px;
  }
`;

export const Div = styled.div`
  padding-left: ${Metrics.defaults.paddingBiggest};
  padding-bottom: ${Metrics.defaults.padding};
  align-self: flex-start;
  display: flex;
  flex-direction: column;
  align-items: flex-start;

  a {
    font-size: ${Fonts.link};
  }

  a,
  svg {
    color: ${Colors.navGray};
  }

  a:first-child {
    margin-bottom: ${Metrics.defaults.margin};
    padding-top: ${Metrics.defaults.margin};
  }
`;

// Navigation Body
export const Body = styled.div`
  position: fixed;
  left: 0;
  top: 0;
  display: flex;
  width: 18em;
  height: 100%;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  background-color: white;
  box-shadow: 0 2px 20px 0 rgba(131, 140, 152, 0.16);
  padding-top: ${Metrics.drawer.paddingTop};
  opacity: 1;
  z-index: 10;
  overflow-y: auto;

  transition: all 300ms ease-in-out;

  @media (max-width: 900px) {
    opacity: ${({ open }) => (open ? 1 : 0)};
    width: ${({ open }) => (open ? '100%' : 0)};
    height: 100%;

    pointer-events: ${({ open }) => (open ? 'all' : 'none')};
    z-index: ${({ open }) => (open ? '10' : '-10')};
    padding-top: 5em;
  }
`;

// Mobile
export const MobileNav = styled.div`
  position: fixed;
  left: 0;
  top: 0;
  padding: 0.5em 1em;
  align-self: flex-start;
  background-color: white;
  width: 100%;
  border-bottom: 1px solid ${Colors.borderGray};
  z-index: 999;
  box-shadow: 0 2px 20px 0 rgba(131, 140, 152, 0.16);

  @media (max-width: 900px) {
    display: block;
  }
  @media (min-width: 900px) {
    display: none;
  }
`;
