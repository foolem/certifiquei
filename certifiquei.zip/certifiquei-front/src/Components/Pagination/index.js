import React from 'react';
import PropTypes from 'prop-types';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeftOutlined';
import ChevronRightIcon from '@material-ui/icons/ChevronRightOutlined';

import Btn from '../Btn';
import Colors from '../../Themes/Colors';

const PER_PAGE = 25;

const Pagination = ({ current, total, next, prev }) => {
  return (
    <Grid container xs={12} md={12} justify="flex-end" alignItems="center" className="Margin-t-1">
      <Typography variant="caption" className="Margin-r-1">
        Exibindo: {current} de {total} resultados
      </Typography>

      <Btn
        variant="outlined"
        paddingLittle
        disabled={total <= PER_PAGE}
        onClick={() => {
          prev();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        secondary
      >
        <ChevronLeftIcon color={Colors.blue} size={20} />
      </Btn>
      <Btn
        variant="outlined"
        paddingLittle
        disabled={total <= PER_PAGE}
        onClick={() => {
          next();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        secondary
      >
        <ChevronRightIcon color={Colors.blue} size={20} />
      </Btn>
    </Grid>
  );
};

Pagination.propTypes = {
  current: PropTypes.number.isRequired,
  total: PropTypes.number.isRequired,
  prev: PropTypes.func.isRequired,
  next: PropTypes.func.isRequired,
};

export default Pagination;
