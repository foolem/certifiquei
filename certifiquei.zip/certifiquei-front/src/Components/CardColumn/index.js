import React from 'react';

import { Typography } from '@material-ui/core';

import CardWrapper from '../CardWrapper';
import CardFooter from '../CardFooter';
import { ColumnTitle } from './styles';

export default function CardColumn({ data }) {
  return (
    <CardWrapper>
      <ColumnTitle>
        <Typography variant="body1">
          <b>{data.name}</b>
        </Typography>
      </ColumnTitle>
      <CardFooter
        style={{
          alignItems: 'flex-start',
          flexDirection: 'column',
        }}
      >
        {data.data.map((item, i) => (
          <Typography key={i} variant="caption">
            {item}
          </Typography>
        ))}
      </CardFooter>
    </CardWrapper>
  );
}
