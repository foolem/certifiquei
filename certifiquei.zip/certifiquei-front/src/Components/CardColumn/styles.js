import styled from 'styled-components';
import { Metrics, Colors } from '../../Themes';

export const ColumnTitle = styled.div`
  display: flex;
  justify-content: flex-start;
  align-items: center;
  background-color: ${Colors.strongerGray};
  padding: ${Metrics.defaults.padding};
  border-left: 1px solid ${Colors.borderGray};
  border-right: 1px solid ${Colors.borderGray};
`;
