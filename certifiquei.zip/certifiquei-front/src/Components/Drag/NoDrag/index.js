import React, { useState, useEffect } from 'react';
import Draggable from 'react-draggable';

const NoDrag = ({ style, ...props }) => {
  const [state, setState] = useState({
    activeDrags: 0,
    deltaPosition: {
      x: 0,
      y: 0,
    },
    controlledPosition: {
      x: 0,
      y: 0,
    },
  });

  useEffect(() => {
    setState({
      controlledPosition: {
        x: props.x,
        y: props.y,
      },
    });
  }, [props.x, props.y]);

  const onStart = () => {
    setState({ ...state, activeDrags: ++state.activeDrags });
  };

  const onStop = () => {
    setState({ ...state, activeDrags: --state.activeDrags });
    props.handlePosition(state.controlledPosition);
  };

  const onControlledDrag = (e, position) => {
    const { x, y } = position;
    setState({ ...state, controlledPosition: { x, y } });
  };

  const onControlledDragStop = (e, position) => {
    onControlledDrag(e, position);
    onStop();
  };

  const dragHandlers = { onStart: onStart, onStop: onStop };
  const { children } = props;
  return (
    props.open && (
      <Draggable
        bounds="parent"
        {...dragHandlers}
        grid={[10, 10]}
        onStart={() => false}
        // onDrag={handleDrag}
        // onDrag={onControlledDrag}
        position={state.controlledPosition}
      >
        <div className="box no-cursor" style={style}>
          {children}
        </div>
      </Draggable>
    )
  );
};

export default NoDrag;
