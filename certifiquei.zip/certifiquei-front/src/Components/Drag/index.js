import React, { useState, useEffect, useLayoutEffect, createRef } from 'react';
import Draggable from 'react-draggable';
import OpenWithIcon from '@material-ui/icons/OpenWith';

const Drag = ({ data, handlePosition, sendDragWidth, children }) => {
  const targetRef = createRef();
  const [dimensions, setDimensions] = useState({});

  useLayoutEffect(() => {
    setDimensions(targetRef.current.getBoundingClientRect().width);
  }, [targetRef]);

  useEffect(() => {
    if (dimensions > 0) {
      sendDragWidth(dimensions, data.id);
    }
  }, [dimensions, data.id]);

  const [state, setState] = useState({
    activeDrags: 0,
    deltaPosition: {
      x: 0,
      y: 0,
    },
    controlledPosition: {
      x: 0,
      y: 0,
    },
  });

  useEffect(() => {
    setState({
      controlledPosition: {
        x: data.position.x,
        y: data.position.y,
      },
    });
  }, [data.position.x, data.position.y]);

  const onStart = () => {
    setState({ ...state, activeDrags: ++state.activeDrags });
  };

  const onStop = () => {
    setState({ ...state, activeDrags: --state.activeDrags });
    handlePosition(state.controlledPosition);
  };

  const onControlledDrag = (_e, position) => {
    const { x, y } = position;
    setState({ ...state, controlledPosition: { x, y } });
  };

  const dragHandlers = { onStart: onStart, onStop: onStop };

  return (
    <Draggable
      bounds="parent"
      {...dragHandlers}
      grid={[10, 10]}
      handle=".handle"
      onDrag={onControlledDrag}
      position={state.controlledPosition}
    >
      <div ref={targetRef} className="box no-cursor" style={data.styles}>
        <div className="handle">
          <OpenWithIcon fontSize="small"></OpenWithIcon>
        </div>
        {children}
      </div>
    </Draggable>
  );
};

export default Drag;
