import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Grid, Typography, InputLabel, Link, TextField } from '@material-ui/core';
import CircularProgress from '@material-ui/core/CircularProgress';

import CertificateActions, { CertificateSelectors } from '../../Modules/Certificate';

import Btn from '../../Components/Btn';
import { Banner, Body, Form } from './styles';

export default () => {
  const resource = window.location.href.split('resource=')[1];
  const dispatch = useDispatch();
  const fetching = useSelector(state => CertificateSelectors.getLoading(state));
  const validCertificate = useSelector(state => CertificateSelectors.getValidCertificate(state));
  const [state, setState] = useState({
    resource: '',
    kind: 'internal',
  });

  useEffect(() => {
    if (resource) {
      setState({ ...state, resource });
    }
  }, [resource]);

  const handleValidate = () => {
    dispatch(CertificateActions.validateCertificateRequest(state));
  };

  return (
    <Body>
      <Grid container spacing={3} className="Padding-3">
        <Grid item xs={12}>
          <Typography variant="h5" className="Margin-b-1">
            Verifique a autenticidade de certificados de forma simples e rápida.
          </Typography>

          <Form>
            <Grid container spacing={3} alignItems="flex-end" className="Margin-t-1">
              <Grid item xs={12} md={8}>
                <InputLabel>Código</InputLabel>
                <TextField
                  fullWidth
                  variant="outlined"
                  placeholder="Digite o código do certificado"
                  value={state.resource}
                  onChange={e => setState({ ...state, resource: e.target.value })}
                />
              </Grid>

              <Grid item xs={12} md={4}>
                <Btn
                  variant="contained"
                  green
                  fullWidth
                  fullHeight
                  type="submit"
                  onClick={e => {
                    e.preventDefault();
                    handleValidate();
                  }}
                  endIcon={fetching && <CircularProgress className="size-1em" />}
                >
                  Validar
                </Btn>
              </Grid>
            </Grid>
          </Form>

          {validCertificate && (
            <Grid container direction="column" className="Margin-t-3">
              <Typography variant="subtitle2">
                <b>Este certificado é válido!</b>
              </Typography>
              <Typography variant="body1">
                Participante: {validCertificate.user.firstName}
              </Typography>
              <Typography variant="body1">Evento: {validCertificate.event.title}</Typography>
              <Link
                href={validCertificate.resourceUrl}
                target="_blank"
                rel="noopener"
                className="Margin-t-1 No-decoration"
              >
                <Btn variant="contained" green fullHeight>
                  Baixar certificado
                </Btn>
              </Link>
            </Grid>
          )}
        </Grid>
      </Grid>
    </Body>
  );
};
