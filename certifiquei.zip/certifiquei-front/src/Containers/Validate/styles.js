import styled from 'styled-components';
import { Grid } from '@material-ui/core';
import { Metrics, Colors } from '../../Themes';

export const Body = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  padding: ${Metrics.defaults.paddingBigger};
`;

export const Banner = styled(Grid)`
  position: relative;
  text-align: left;

  .MuiTypography-root {
    color: ${Colors.blue} !important;
  }

  @media (max-width: 900px) {
    img {
      display: none;
    }
  }

  .Shape {
    width: 30em;
    height: 50em;
    position: fixed;
    bottom: 0em;
    left: 1em;
    z-index: -1;
  }

  .Draw-1 {
    width: 30em;
    height: 20em;
    position: fixed;
    bottom: 2em;
    z-index: 1;
  }

  .Draw-2 {
    width: 15em;
    height: 15em;
    position: fixed;
    bottom: 14em;
    left: 6em;
    z-index: -1;
  }

  .Draw-3 {
    width: 10em;
    height: 10em;
    position: fixed;
    bottom: 14em;
    left: 1em;
    z-index: -1;
  }
`;

export const Form = styled.form``;
