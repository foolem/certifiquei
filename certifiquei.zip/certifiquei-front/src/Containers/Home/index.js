import React, { useEffect } from 'react';
import { Typography, Grid, Link } from '@material-ui/core';
import GetApp from '@material-ui/icons/GetApp';
import EventIcon from '@material-ui/icons/Event';

import { useDispatch, useSelector } from 'react-redux';

import Search from '../../Components/Filters/Search';
import Filters from '../../Components/Filters/Filters';
import Table from '../../Components/Table';
import Body from '../../Components/Body';
import Button from '../../Components/Btn';
import Form from '../../Components/Form';
import PresenceDialog from '../../Components/Dialog/Presence';
import CertificateFrame from '../../Components/Certificate/CertificateFrame';

import ActivityActions, { ActivitySelectors } from '../../Modules/Activity';
import EventActions, { EventSelectors } from '../../Modules/Event';
import StudentCertificateActions, {
  StudentCertificateSelectors,
} from '../../Modules/StudentCertificate';
import { UserSelectors } from '../../Modules/User';

import { activityIndexColumns } from '../../Helpers/Columns/Activity';
import { studentCertificateIndexColumns } from '../../Helpers/Columns/StudentCertificate';

import Images from '../../Themes/Images';

import { Card } from './styles';
import { IconContainer } from '../Student/Certificates/Index/styles';

export default function Home() {
  const dispatch = useDispatch();

  const user = useSelector(state => UserSelectors.getUser(state));
  const events = useSelector(state => EventSelectors.getAllEvents(state));
  const activities = useSelector(state => ActivitySelectors.getActivities(state));
  const loading = useSelector(state => ActivitySelectors.getLoading(state));
  const loadingCertificates = useSelector(state => StudentCertificateSelectors.getLoading(state));
  const meta = useSelector(state => ActivitySelectors.getMeta(state));
  const certificatesMeta = useSelector(state => StudentCertificateSelectors.getMeta(state));
  const certificates = useSelector(state =>
    StudentCertificateSelectors.getStudentCertificates(state),
  );

  const latestCertificate = certificates[0];

  useEffect(() => {
    dispatch(StudentCertificateActions.studentCertificatesRequest());
    dispatch(EventActions.allEventsRequest());
  }, [dispatch]);

  useEffect(() => {
    dispatch(ActivityActions.activitiesRequest());
  }, [dispatch, meta.title_i_cont, meta.event_id_in]);

  useEffect(() => {
    dispatch(StudentCertificateActions.studentCertificatesRequest());
  }, [dispatch, certificatesMeta]);

  const setMeta = data => {
    dispatch(ActivityActions.setMeta({ ...meta, ...data }));
  };

  const setCertificatesMeta = data => {
    dispatch(StudentCertificateActions.setMeta({ ...certificatesMeta, ...data }));
  };

  const remove = data => {
    dispatch(ActivityActions.removeActivityRequest(data.id));
  };

  const initPresence = data => {
    dispatch(ActivityActions.togglePresenceNav(data));
  };

  const columns = activityIndexColumns(remove, initPresence, true);
  const certificateColumns = studentCertificateIndexColumns(remove, initPresence, true);

  return (
    <Body>
      <Grid container spacing={3}>
        {user.userType === 'manager' && (
          <Form className="Margin-3">
            <Grid item xs={6} md={2} sm={4}>
              <Link href="organizing/events">
                <Card container justify="center" alignItems="center" direction="column">
                  <Grid>
                    <img src={Images.icons.school} alt="" className="Margin-b-1" />
                  </Grid>
                  <Typography variant="body1">Eventos</Typography>
                </Card>
              </Link>
            </Grid>

            <Grid item xs={6} md={2} sm={4}>
              <Link href="organizing/students">
                <Card container justify="center" alignItems="center" direction="column">
                  <Grid>
                    <img src={Images.icons.resume} alt="" className="Margin-b-1" />
                  </Grid>
                  <Typography variant="body1">Participantes</Typography>
                </Card>
              </Link>
            </Grid>

            <Grid item xs={6} md={2} sm={4}>
              <Link href="organizing/certificates">
                <Card container justify="center" alignItems="center" direction="column">
                  <Grid>
                    <img src={Images.icons.certificate} alt="" className="Margin-b-1" />
                  </Grid>
                  <Typography variant="body1">Certificados</Typography>
                </Card>
              </Link>
            </Grid>
          </Form>
        )}

        {user.userType === 'regular' && (
          <Form className="Margin-3">
            <Grid container justify="center" alignItems="center" direction="column">
              <img src={user.qrcode} alt="" className="qr-code" />
              <Grid container justify="center" alignItems="center" direction="column">
                <Typography variant="subtitle1">Este é seu QR Code</Typography>
                <Typography variant="body1">
                  Você pode utilizá-lo para contabilizar presenças nos eventos que estiver
                  participado.
                </Typography>
              </Grid>
            </Grid>
          </Form>
        )}

        {user.userType === 'regular' && user.staff && (
          <Form className="Margin-3">
            <Grid container spacing={3}>
              <Typography variant="h6">Atividades</Typography>

              <Grid container spacing={3}>
                <Grid item xs={12} md={6} className="Margin-t-3 Margin-b-3">
                  <Search
                    label="Procure por nome"
                    onSubmit={data => setMeta({ title_i_cont: data })}
                  />
                </Grid>
                <Grid item xs={12} md={6} className="Margin-t-3 Margin-b-3">
                  <Filters
                    data={meta}
                    filters={{
                      event_id_in: {
                        name: 'event_id_in',
                        type: 'select',
                        label: 'Eventos',
                        options: events.map(item => ({ value: item.id, label: item.title })),
                      },
                    }}
                    onChange={e => setMeta(e)}
                  />
                </Grid>
              </Grid>
            </Grid>

            <Grid item xs={12}>
              <Table
                data={activities}
                columns={columns}
                loading={loading}
                meta={meta}
                setMeta={setMeta}
              />
            </Grid>
          </Form>
        )}

        {user.userType === 'regular' && user.student && !loading && (
          <Form className="Margin-3">
            {latestCertificate && (
              <Grid container direction="column">
                <Typography variant="h6">Certificados disponíveis</Typography>

                <Grid container className="Padding-3 Margin-t-1">
                  <Grid container direction="row">
                    <Grid item md={8}>
                      <Typography variant="subtitle1">{latestCertificate.event.title}</Typography>
                      <Grid container direction="row" spacing={3} className="Margin-t-1">
                        <Grid item md={5}>
                          <IconContainer>
                            <EventIcon fontSize="small" />
                            <Typography variant="body2">
                              <b>Data de início: </b>
                              {latestCertificate.event.startDate}
                            </Typography>
                          </IconContainer>
                        </Grid>

                        <Grid item md={7}>
                          <IconContainer>
                            <EventIcon fontSize="small" />
                            <Typography variant="body2">
                              <b>Data de término: </b> {latestCertificate.event.endDate}
                            </Typography>
                          </IconContainer>
                        </Grid>
                      </Grid>

                      <Link
                        href={latestCertificate.resourceUrl}
                        target="_blank"
                        rel="noopener noref"
                      >
                        <Button
                          className="Margin-t-2"
                          variant="contained"
                          green
                          startIcon={<GetApp />}
                        >
                          Baixar agora
                        </Button>
                      </Link>
                    </Grid>

                    <Grid item md={4}>
                      <Card variant="outlined" style={{ width: '15em', filter: 'blur(3px)' }}>
                        <CertificateFrame
                          certificate={latestCertificate.event.certificate.metadata.fields}
                          certificateImage={latestCertificate.event.certificate.metadata.background}
                          preview
                        />
                      </Card>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            )}

            <Grid container>
              <Table
                data={certificates}
                columns={certificateColumns}
                loading={loadingCertificates}
                meta={certificatesMeta}
                setMeta={setCertificatesMeta}
              />
            </Grid>
          </Form>
        )}
      </Grid>

      <PresenceDialog />
    </Body>
  );
}
