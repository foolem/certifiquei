import styled from 'styled-components';
import Grid from '@material-ui/core/Grid';
import { Colors } from '../../Themes';

export const Card = styled(Grid)`
  background-color: ${Colors.primaryBlue} !important;
  color: ${Colors.white} !important;
  border-radius: 10px !important;
  padding: 3em 1em !important;

  img {
    height: 3em;
    object-fit: cover;
  }

  h4 {
    font-weight: bold;
  }

  &:hover {
    cursor: pointer;
  }
`;

export const Theme = styled(Grid)`
  background-color: ${Colors.white} !important;
`;

export const IconContainer = styled.div`
  display: flex;
  align-items: center;

  svg {
    fill: ${Colors.blue};
    margin-right: 1em;
  }
`;
