import styled from 'styled-components';
import { Grid } from '@material-ui/core';
import { Metrics, Colors } from '../../../Themes';

export const Banner = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  padding: ${Metrics.defaults.paddingBigger};
  position: relative;
  overflow: hidden;
  background-color: ${Colors.lightGray};
  border-radius: 6px;
  margin-bottom: ${Metrics.defaults.marginBigger};
  h6,
  span,
  button {
    z-index: 3;
  }

  h6 {
    font-weight: bold !important;
    color: ${Colors.blue} !important;
    line-height: 1.2em;
  }
  button {
    margin-top: ${Metrics.defaults.marginBigger};
  }

  .Draw1 {
    width: 13em;
    height: 10em;
    position: absolute;
    bottom: -0.5em;
    left: 0em;
    z-index: 2;
  }

  .Draw2 {
    width: 13em;
    height: 10em;
    position: absolute;
    bottom: -0.5em;
    right: 2em;
    z-index: 2;
  }

  .Shape {
    width: 20em;
    height: 10em;
    position: absolute;
    top: -1em;
    right: -2em;
    z-index: 0;
  }
`;

export const Item = styled(Grid)`
  height: 15em;
  padding: ${Metrics.defaults.padding};
  background-color: ${Colors.lightGray};
  display: flex;
  flex: 1;

  &:first-child {
    margin-right: ${Metrics.defaults.margin};
  }
  &:last-child {
    margin-left: ${Metrics.defaults.margin};
  }
`;
