import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

import { Grid, Typography, Link, Popover } from '@material-ui/core';

import ArrowRightIcon from '@material-ui/icons/ArrowRightAlt';

import Body from '../../../Components/Body';
import Btn from '../../../Components/Btn';
import PopoverButton from '../../../Components/PopoverButton';
import CertificateFrame from '../../../Components/Certificate/CertificateFrame';

import CertificateActions, { CertificateSelectors } from '../../../Modules/Certificate';

import { Banner } from './styles';

export default () => {
  const dispatch = useDispatch();
  const certificates = useSelector(state => CertificateSelectors.getCertificates(state));
  const [anchorEl, setAnchorEl] = useState(null);
  const [currentRow, setCurrentRow] = useState(null);

  useEffect(() => {
    dispatch(CertificateActions.certificatesRequest());
  }, []);

  const handleClose = () => {
    setCurrentRow(null);
    setAnchorEl(null);
  };

  return (
    <Body>
      <Grid container direction="column">
        <Typography variant="h6">Certificados</Typography>

        <Banner>
          <Typography variant="subtitle1">
            Crie e distribua certificados
            <br />
            de forma simples e rápida.
          </Typography>
          <Typography variant="caption">Veja todas as opções disponíveis</Typography>
          <Link href="/organizing/certificates/new" underline="none">
            <Btn variant="contained" green>
              Criar agora
            </Btn>
          </Link>
        </Banner>

        {!!certificates.length && (
          <>
            <Typography variant="h6" className="Margin-b-1">
              Sua Galeria
            </Typography>
            <Grid container wrap="wrap" spacing={3}>
              {certificates.slice(0, 3).map(item => (
                <Grid item>
                  <CertificateFrame
                    certificate={item?.metadata.fields}
                    certificateImage={item?.metadata.background}
                    preview
                  />
                  <Typography variant="subtitle1">{item.name}</Typography>
                </Grid>
              ))}
            </Grid>
            <Grid container justify="flex-end">
              <Btn
                secondary
                endIcon={<ArrowRightIcon />}
                onClick={() => window.location.replace('/organizing/certificates/gallery')}
              >
                Visualizar todos
              </Btn>
            </Grid>
          </>
        )}

        <Popover
          id={currentRow}
          open={!!anchorEl}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
          small
        >
          <PopoverButton>Editar</PopoverButton>
          <PopoverButton>Duplicar</PopoverButton>
          <PopoverButton>Visualizar</PopoverButton>
          <PopoverButton>Deletar</PopoverButton>
        </Popover>
      </Grid>
    </Body>
  );
};
