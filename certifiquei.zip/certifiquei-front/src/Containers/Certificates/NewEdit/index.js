import React, { useState, useEffect, useRef, useLayoutEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useParams } from 'react-router-dom';

import { Grid, Typography } from '@material-ui/core';
import Settings from '@material-ui/icons/Settings';

import Body from '../../../Components/Body';
import Btn from '../../../Components/Btn';
import CertificateFrame from '../../../Components/Certificate/CertificateFrame';
import Config from '../../../Components/Certificate/Config';

import CertificateActions, { CertificateSelectors } from '../../../Modules/Certificate';

export default () => {
  const { templateId } = useParams();
  const dispatch = useDispatch();

  const certificate = useSelector(state => CertificateSelectors.getNewCertificate(state));
  const loading = useSelector(state => CertificateSelectors.getLoading(state));
  const saving = useSelector(state => CertificateSelectors.getSaving(state));

  const certificateImage = certificate?.background;

  const targetRef = useRef();
  const [dimensions, setDimensions] = useState({});
  const [name, setName] = useState('Meu certificado');
  const [anchorEl, setAnchorEl] = useState(null);

  useLayoutEffect(() => {
    if (targetRef.current) setDimensions(targetRef.current.getBoundingClientRect().width);
  }, [targetRef]);

  useEffect(() => {
    if (targetRef.current && dimensions > 0) dispatch(CertificateActions.sendBackWidth(dimensions));
  }, [dispatch, dimensions, targetRef]);

  useEffect(() => {
    dispatch(CertificateActions.templateRequest(templateId));
  }, [dispatch, templateId]);

  const handleText = (event, field, id, text) => {
    dispatch(CertificateActions.changeText(event, field, id, text));
  };

  const toggleConfig = event => {
    setAnchorEl(!!anchorEl ? null : event.currentTarget);
  };

  const resetConfig = () => {
    dispatch(CertificateActions.templateRequest(templateId));
  };

  const handleSave = () => {
    const payload = {
      title: name,
      certificateTemplateId: templateId,
      metadata: certificate,
    };
    dispatch(CertificateActions.createCertificateRequest(payload));
  };

  return (
    <Body>
      <Grid
        container
        wrap="wrap"
        alignItems="center"
        justify="space-between"
        className="Margin-b-1"
      >
        <Btn
          variant="outlined"
          fullHeight
          endIcon={<Settings />}
          aria-describedby="config"
          onClick={toggleConfig}
        >
          Configurações
        </Btn>

        <Btn variant="contained" yellow fullHeight onClick={handleSave} loading={saving}>
          Salvar certificado
        </Btn>
      </Grid>

      <CertificateFrame
        allowEdit
        loading={loading}
        targetRef={targetRef}
        certificate={certificate?.fields}
        certificateImage={certificateImage}
        handlePosition={(item, position) =>
          dispatch(CertificateActions.changePosition(item.id, position))
        }
        handleText={handleText}
        sendDragWidth={(dimensions, id) =>
          dispatch(CertificateActions.sendDragWidth(dimensions, id))
        }
      />

      <Grid container className="Margin-t-1">
        <Typography variant="h6" className="Margin-b-1">
          Legendas disponíveis:
        </Typography>

        <Grid item container spacing={3}>
          <Grid item xs={12}>
            <Typography variant="body1">
              <b>[NOME_DO_ALUNO]:</b> Nome do estudante que está recebendo o certificado.
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="body1">
              <b>[GRR_DO_ALUNO]:</b> CPF do aluno que está recebendo o certificado.
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="body1">
              <b>[NOME_DO_EVENTO]:</b> Nome da evento que está emitindo o certificado.
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="body1">
              <b>[DATA_DE_EMISSAO]:</b> Data de emissão do certificado atual.
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="body1">
              <b>[TOTAL_DE_HORAS]:</b> Total de horas formativas do participante.
            </Typography>
          </Grid>
        </Grid>
      </Grid>

      {!loading && (
        <Config
          anchorEl={anchorEl}
          toggleConfig={toggleConfig}
          resetConfig={resetConfig}
          name={name}
          setName={setName}
        />
      )}
    </Body>
  );
};
