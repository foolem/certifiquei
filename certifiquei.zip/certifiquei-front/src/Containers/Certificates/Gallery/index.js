import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

import { Grid, Typography } from '@material-ui/core';

import MoreHorizRounded from '@material-ui/icons/MoreHorizRounded';

import Body from '../../../Components/Body';
import NoticeDialog from '../../../Components/Dialog/Notice';
import CertificateFrame from '../../../Components/Certificate/CertificateFrame';

import CertificateActions, { CertificateSelectors } from '../../../Modules/Certificate';

import { Item } from './styles';
import Popover from '../../../Components/Popover';
import PopoverButton from '../../../Components/PopoverButton';

export default () => {
  const dispatch = useDispatch();

  const [anchorEl, setAnchorEl] = useState(null);
  const [currentRow, setCurrentRow] = useState({});
  const [deleteOpen, setDeleteOpen] = useState(false);

  const certificates = useSelector(state => CertificateSelectors.getCertificates(state));
  const loading = useSelector(state => CertificateSelectors.getLoading(state));

  useEffect(() => {
    dispatch(CertificateActions.certificatesRequest());
  }, [dispatch]);

  const handleClick = (event, id) => {
    setCurrentRow(id);
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setCurrentRow(null);
    setAnchorEl(null);
  };

  const handleEdit = () => {
    window.location.replace(`/organizing/certificates/${currentRow}/edit`);
  };

  const handleDuplicate = () => {
    dispatch(CertificateActions.duplicateCertificateRequest(currentRow));
    handleClose();
  };

  const handleRemove = () => {
    dispatch(CertificateActions.removeCertificateRequest(currentRow));
    handleClose();
    setTimeout(() => {
      setDeleteOpen(false);
    }, 500);
  };

  return (
    <Body>
      <Grid container direction="column">
        <Typography variant="h6">Sua galeria</Typography>

        <Grid container wrap="wrap" alignItems="center" className="Margin-t-3">
          {certificates.map(item => (
            <Item key={item.id} item md={3} sm={12}>
              <CertificateFrame
                certificate={item.metadata.fields}
                certificateImage={item.metadata.background}
                preview
              />

              <Grid
                className="Actions"
                onClick={e => handleClick(e, item.id)}
                aria-describedby={item.id}
              >
                <MoreHorizRounded />
              </Grid>

              <Typography variant="body1" className="Margin-t-1">
                {item.name}
              </Typography>
            </Item>
          ))}
        </Grid>
      </Grid>

      <Popover
        id={currentRow}
        open={!!anchorEl}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        small
      >
        <PopoverButton onClick={handleEdit}>Editar</PopoverButton>
        <PopoverButton onClick={handleDuplicate}>Duplicar</PopoverButton>
        <PopoverButton onClick={() => setDeleteOpen(true)}>Deletar</PopoverButton>
      </Popover>

      <NoticeDialog
        open={deleteOpen}
        setOpen={setDeleteOpen}
        action={handleRemove}
        loading={loading}
        backAction={() => setDeleteOpen(null)}
        backText="Cancelar"
        actionText="Excluir"
        title="Excluir certificado"
        text="Tem certeza que deseja excluir o certificado? Essa ação não poderá ser desfeita."
      />
    </Body>
  );
};
