import styled from 'styled-components';
import { Grid } from '@material-ui/core';
import { Metrics, Colors } from '../../../Themes';

export const Item = styled(Grid)`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  border: 1px solid ${Colors.strongerGray};
  background-color: ${Colors.lightGray};
  position: relative;
  padding: 1em;
  margin: 2em !important;
  transition: 300ms all ease-in-out;

  &:hover {
    border: 1px solid ${Colors.primaryBlue};
    cursor: pointer;

    .Actions {
      opacity: 1;
    }
  }

  .Actions {
    opacity: 0;
    position: absolute;
    top: -1.75em;
    right: -1px;
    transition: 300ms all ease-in-out;

    background-color: ${Colors.primaryBlue};
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    padding: 0 1em;

    svg {
      fill: ${Colors.white};
    }
  }
`;

export const Action = styled.div`
  display: none;
  position: absolute;
  bottom: 0;
  justify-content: center;
  align-items: center;
  width: 100%;
  padding: ${Metrics.defaults.padding} 0;
  background-color: ${Colors.primaryBlue};
  opacity: 0.8;
  a {
    color: ${Colors.white} !important;
  }
`;
