import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';

import { Grid, Typography } from '@material-ui/core';

import Body from '../../../Components/Body';
import Btn from '../../../Components/Btn';
import CertificateFrame from '../../../Components/Certificate/CertificateFrame';

import CertificateActions, { CertificateSelectors } from '../../../Modules/Certificate';

import { Item } from './styles';
import { Metrics } from '../../../Themes';

export default () => {
  const [selected, setSelected] = useState(null);
  const dispatch = useDispatch();
  const templates = useSelector(state => CertificateSelectors.getTemplates(state));
  const isDisabled = !selected;

  useEffect(() => {
    dispatch(CertificateActions.templatesRequest());
  }, []);

  return (
    <Body>
      <Grid container direction="column">
        <Typography variant="h6">Escolha seu modelo de certificado</Typography>

        <Grid
          container
          spacing={3}
          wrap="wrap"
          justify="space-between"
          alignItems="center"
          className="Margin-t-3 Margin-b-1"
        >
          {templates.map(item => (
            <Item
              key={item.id}
              item
              active={selected?.id === item.id}
              onClick={() => setSelected(item)}
              className="Margin-1"
            >
              <CertificateFrame
                certificate={item?.metadata.fields}
                certificateImage={item?.metadata.background}
                preview
              />
            </Item>
          ))}
        </Grid>

        <Grid container justify="flex-end" alignItems="center">
          <Btn
            secondary
            fullHeight
            style={{ marginRight: Metrics.defaults.margin }}
            onClick={() => window.location.replace('/organizing/certificates')}
          >
            Cancelar
          </Btn>
          <Btn
            variant="contained"
            yellow
            fullHeight
            disabled={isDisabled}
            href={`/organizing/certificates/new/edit/${selected?.id}`}
          >
            Continuar
          </Btn>
        </Grid>
      </Grid>
    </Body>
  );
};
