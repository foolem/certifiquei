import styled from 'styled-components';
import { Grid } from '@material-ui/core';
import { Colors } from '../../../Themes';

export const Item = styled(Grid)`
  display: flex;
  justify-content: center;
  align-items: center;
  border: 1px solid ${({ active }) => (active ? Colors.primaryBlue : Colors.strongerGray)};
  background-color: ${Colors.lightGray};

  &:hover {
    border: 1px solid ${Colors.primaryBlue};
    cursor: pointer;
  }
`;
