import styled from 'styled-components';
import { Metrics, Colors } from '../../../../Themes';

export const Banner = styled.div`
  display: flex;
  justify-content: flex-start;
  align-items: flex-start;
  flex-direction: column;
  padding: ${Metrics.defaults.paddingBigger};
  position: relative;
  overflow: hidden;
  background-color: ${Colors.lightGray};
  border-radius: 6px;
  margin-bottom: ${Metrics.defaults.marginBigger};
  h6,
  span,
  button {
    z-index: 3;
  }

  h6 {
    font-weight: bold !important;
    color: ${Colors.blue} !important;
    line-height: 1.2em;
  }
  button {
    margin-top: ${Metrics.defaults.marginBigger};
  }
`;

export const IconContainer = styled.div`
  display: flex;
  align-items: center;

  svg {
    fill: ${Colors.blue};
    margin-right: ${Metrics.defaults.marginLittle};
  }
`;
