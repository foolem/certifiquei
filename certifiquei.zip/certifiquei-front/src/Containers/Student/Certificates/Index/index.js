import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import format from 'date-fns/format';

import {
  Grid,
  Card,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Link,
  CircularProgress,
} from '@material-ui/core';

import MoreHorizIcon from '@material-ui/icons/MoreHoriz';
import GetApp from '@material-ui/icons/GetApp';
import EventIcon from '@material-ui/icons/Event';
import StudentCertificateActions, {
  StudentCertificateSelectors,
} from '../../../../Modules/StudentCertificate';

import Body from '../../../../Components/Body';
import Header from '../../../../Components/Headers/Index';
import Popover from '../../../../Components/Popover';
import PopoverButton from '../../../../Components/PopoverButton';
import CertificateFrame from '../../../../Components/Certificate/CertificateFrame';
import Btn from '../../../../Components/Btn';
import { Banner, IconContainer } from './styles';

export default () => {
  const dispatch = useDispatch();
  const [anchorEl, setAnchorEl] = useState(null);
  const [currentRow, setCurrentRow] = useState(null);
  const certificates = useSelector(state => StudentCertificateSelectors.getCertificates(state));
  const loading = useSelector(state => StudentCertificateSelectors.getLoading(state));

  const latestCertificate = certificates[0];

  useEffect(() => {
    dispatch(StudentCertificateActions.studentCertificatesRequest());
  }, []);

  const handleClick = (event, id) => {
    setCurrentRow(id);
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setCurrentRow(null);
    setAnchorEl(null);
  };

  return (
    <Body>
      <Header />
      {!loading && (
        <Grid container direction="column">
          {latestCertificate && (
            <Grid container direction="column">
              <Typography variant="h6">Novo certificado disponível</Typography>

              <Banner className="Padding-3 Margin-t-1">
                <Grid container direction="row">
                  <Grid item md={8}>
                    <Typography variant="subtitle1">{latestCertificate.event.name}</Typography>
                    <Grid container direction="row" spacing={3} className="Margin-t-1">
                      <Grid item md={5}>
                        <IconContainer>
                          <EventIcon fontSize="small" />
                          <Typography variant="body2">
                            <b>Data de início: </b>
                            {latestCertificate.event.startDate}
                          </Typography>
                        </IconContainer>
                      </Grid>

                      <Grid item md={7}>
                        <IconContainer>
                          <EventIcon fontSize="small" />
                          <Typography variant="body2">
                            <b>Data de término: </b> {latestCertificate.event.endDate}
                          </Typography>
                        </IconContainer>
                      </Grid>
                    </Grid>

                    <Link href={latestCertificate.resourceUrl} target="_blank" rel="noopener noref">
                      <Btn variant="contained" green startIcon={<GetApp />}>
                        Baixar agora
                      </Btn>
                    </Link>
                  </Grid>

                  <Grid item md={4}>
                    <Card variant="outlined" style={{ width: '15em', filter: 'blur(3px)' }}>
                      <CertificateFrame
                        certificate={latestCertificate.event.certificate.metadata.fields}
                        certificateImage={latestCertificate.event.certificate.metadata.background}
                        preview
                      />
                    </Card>
                  </Grid>
                </Grid>
              </Banner>
            </Grid>
          )}

          <Typography variant="h6">Seus certificados</Typography>

          <TableContainer
            style={{
              border: 0,
            }}
            className="Margin-b-1"
          >
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Nome do evento</TableCell>
                  <TableCell>Expiração</TableCell>
                  <TableCell />
                </TableRow>
              </TableHead>
              <TableBody>
                {certificates.map(item => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <strong>{item.event.name}</strong>
                    </TableCell>
                    <TableCell>
                      {format(new Date(item.event.certificateExpiresAt), 'dd/MM/yyyy - HH:mm')}
                    </TableCell>
                    <TableCell>
                      <IconButton onClick={e => handleClick(e, item)} aria-describedby="1">
                        <MoreHorizIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <Popover
            id={currentRow}
            open={!!anchorEl}
            anchorEl={anchorEl}
            onClose={handleClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'left',
            }}
            small
          >
            <Link href={currentRow?.resourceUrl} target="_blank" rel="noopener noref">
              <PopoverButton>Download</PopoverButton>
            </Link>
          </Popover>
        </Grid>
      )}

      {loading && (
        <Grid container justify="center">
          <CircularProgress size={50} />
        </Grid>
      )}
    </Body>
  );
};
