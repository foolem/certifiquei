import React, { useState } from 'react';
import {
  Grid,
  Card,
  Typography,
  Divider,
  Select,
  InputLabel,
  TextField,
  Link,
} from '@material-ui/core';

import MoreHorizIcon from '@material-ui/icons/MoreHoriz';
import GetApp from '@material-ui/icons/GetApp';
import EventIcon from '@material-ui/icons/Event';
import LanguageIcon from '@material-ui/icons/Language';

import Body from '../../../../Components/Body';
import Status from '../../../../Components/Status';
import Header from '../../../../Components/Header';
import Btn from '../../../../Components/Btn';
import { Banner } from './styles';
import { Colors, Metrics, Images } from '../../../../Themes';

export default function Show(props) {
  return (
    <Body>
      <Header />
      <Btn variant="outlined" className="Margin-b-1">
        Voltar
      </Btn>
      <Grid container direction="column" className="Margin-t-1">
        <Typography variant="h6">Certificado 1234 modelo</Typography>

        <Banner className="Padding-3 Margin-t-1">
          <Typography variant="subtitle1">Certificado</Typography>

          <Grid container justify="flex-end">
            <Btn variant="contained" yellow>
              Download em PDF
            </Btn>
          </Grid>
        </Banner>
        <Typography variant="body1">
          Está vendo um erro no certificado?{' '}
          <Link>Entre com contato com o organizador</Link>
        </Typography>
      </Grid>
    </Body>
  );
}
