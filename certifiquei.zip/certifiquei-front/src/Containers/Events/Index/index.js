import React, { useEffect } from 'react';
import { Grid } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import Header from '../../../Components/Headers/Index';
import Search from '../../../Components/Filters/Search';
import Filters from '../../../Components/Filters/Filters';
import Table from '../../../Components/Table';
import Body from '../../../Components/Body';

import EventActions, { EventSelectors } from '../../../Modules/Event';

import { eventIndexColumns } from '../../../Helpers/Columns/Event';

export default () => {
  const dispatch = useDispatch();
  const events = useSelector(state => EventSelectors.getEvents(state));
  const loading = useSelector(state => EventSelectors.getLoading(state));
  const meta = useSelector(state => EventSelectors.getMeta(state));

  useEffect(() => {
    dispatch(EventActions.eventsRequest());
  }, [dispatch, meta.title_i_cont, meta.status_in, meta.category_id_in, meta.level_id_in]);

  const setMeta = data => {
    dispatch(EventActions.setMeta({ ...meta, ...data }));
  };

  const remove = data => {
    dispatch(EventActions.removeEventRequest(data.id));
  };

  const columns = eventIndexColumns(remove);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Header title="Eventos" actionText="Novo evento" href="/organizing/events/new" />

        <Grid container spacing={3}>
          <Grid item xs={12} md={6} className="Margin-t-3 Margin-b-3">
            <Search label="Procure por nome" onSubmit={data => setMeta({ title_i_cont: data })} />
          </Grid>
          <Grid item xs={12} md={6} className="Margin-t-3 Margin-b-3">
            <Filters
              data={meta}
              filters={{
                status_in: {
                  name: 'status_in',
                  type: 'select',
                  label: 'Status',
                  options: [
                    { label: 'Rascunho', value: 'draft' },
                    { label: 'Ativo', value: 'active' },
                    { label: 'Finalizado', value: 'finished' },
                    { label: 'Distribuído', value: 'delivered' },
                  ],
                },
              }}
              onChange={e => setMeta(e)}
            />
          </Grid>
        </Grid>

        <Grid item xs={12}>
          <Table
            data={events}
            columns={columns}
            loading={loading}
            meta={meta}
            setMeta={setMeta}
            link={row => `organizing/events/${row.id}`}
          />
        </Grid>
      </Grid>
    </Body>
  );
};
