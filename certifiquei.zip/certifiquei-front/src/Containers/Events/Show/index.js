/* eslint-disable react/no-danger */
import React, { useEffect } from 'react';
import { CircularProgress, Grid } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';

import Header from '../../../Components/Headers/Index';
import Form from '../../../Components/Form';
import Body from '../../../Components/Body';
import Button from '../../../Components/Btn';
import General from './General';
import Activities from './Activities';
import Students from './Students';
import Staffs from './Staffs';

import EventActions, { EventSelectors } from '../../../Modules/Event';
import StudentActions, { StudentSelectors } from '../../../Modules/Student';
import StaffActions, { StaffSelectors } from '../../../Modules/Staff';
import ActivityActions, { ActivitySelectors } from '../../../Modules/Activity';

export default () => {
  const dispatch = useDispatch();
  const { id } = useParams();

  const event = useSelector(state => EventSelectors.getEvent(state));
  const loading = useSelector(state => EventSelectors.getLoading(state));
  const studentsMeta = useSelector(state => StudentSelectors.getMeta(state));
  const staffsMeta = useSelector(state => StaffSelectors.getMeta(state));
  const activitiesMeta = useSelector(state => ActivitySelectors.getMeta(state));

  useEffect(() => {
    dispatch(StudentActions.setMeta({ ...studentsMeta, event_id_in: [id] }));
    dispatch(StaffActions.setMeta({ ...staffsMeta, event_id_in: [id] }));
    dispatch(ActivityActions.setMeta({ ...activitiesMeta, event_id_in: [id] }));
  }, [dispatch, id]);

  useEffect(() => {
    dispatch(EventActions.eventRequest(id));
  }, [dispatch, id]);

  useEffect(() => {
    dispatch(StudentActions.studentsRequest());
  }, [dispatch, studentsMeta]);

  useEffect(() => {
    dispatch(StaffActions.staffsRequest());
  }, [dispatch, staffsMeta]);

  useEffect(() => {
    dispatch(ActivityActions.activitiesRequest());
  }, [dispatch, activitiesMeta]);

  const handleDistribute = () => {
    dispatch(EventActions.distributeRequest(id));
  };

  return (
    <Body>
      <Grid container className="Padding-1">
        <Header
          title={event.title}
          actionText="Editar"
          href={`/organizing/events/${event.id}/edit`}
        />

        {['finished', 'delivered'].includes(event.status) && (
          <Button onClick={handleDistribute} className="Margin-t-1">
            Distribuir certificados
          </Button>
        )}

        <Grid container className="Margin-t-3">
          <Form>
            {loading && (
              <Grid
                container
                justify="center"
                alignItems="center"
                className="Margin-t-3 Margin-b-3"
              >
                <CircularProgress size={40} />
              </Grid>
            )}

            {!loading && event.id && <General />}
          </Form>

          <Form className="Margin-t-3">{!loading && event.id && <Activities />}</Form>
          <Form className="Margin-t-3">{!loading && event.id && <Students />}</Form>
          <Form className="Margin-t-3">{!loading && event.id && <Staffs />}</Form>
        </Grid>
      </Grid>
    </Body>
  );
};
