/* eslint-disable react/no-danger */
import React from 'react';
import { Card, Divider, Grid, InputLabel, Typography } from '@material-ui/core';
import { useSelector } from 'react-redux';

import { EventSelectors } from '../../../../Modules/Event';

import { eventAccessType, eventStatus } from '../../../../Helpers/Strings';
import CertificateFrame from '../../../../Components/Certificate/CertificateFrame';

export default () => {
  const event = useSelector(state => EventSelectors.getEvent(state));

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} className="Margin-b-1">
        <Typography variant="h5">
          <b>Informações gerais</b>
        </Typography>
      </Grid>

      <Grid item md={6} xs={12}>
        <InputLabel>Título</InputLabel>
        <Typography variant="body1">{event.title}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Descrição</InputLabel>
        <Typography variant="body1">
          <div dangerouslySetInnerHTML={{ __html: event.description }} />
        </Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Status</InputLabel>
        <Typography variant="body1">{eventStatus[event.status]}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Datas</InputLabel>
        <Typography variant="body1">{`${event.startDate} - ${event.endDate}`}</Typography>
      </Grid>

      <Grid item xs={12}>
        <Divider />
      </Grid>

      <Grid item md={6} xs={12} className="Margin-b-1">
        <Typography variant="h5" className="Margin-b-1">
          <b>Certificação</b>
        </Typography>

        <Grid item md={6} xs={12}>
          <InputLabel>Modelo de certificado</InputLabel>
          {!!event.certificate && (
            <Card variant="outlined" style={{ width: '15em' }}>
              <CertificateFrame
                certificate={event.certificate.metadata.fields}
                certificateImage={event.certificate.metadata.background}
                preview
              />
            </Card>
          )}
        </Grid>
      </Grid>
    </Grid>
  );
};
