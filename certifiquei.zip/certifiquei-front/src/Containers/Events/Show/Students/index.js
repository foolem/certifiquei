/* eslint-disable react/no-danger */
import React from 'react';
import { Grid, Link, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import StudentActions, { StudentSelectors } from '../../../../Modules/Student';
import { EventSelectors } from '../../../../Modules/Event';

import Table from '../../../../Components/Table';
import Button from '../../../../Components/Btn';

import { studentIndexColumns } from '../../../../Helpers/Columns/Student';

export default () => {
  const dispatch = useDispatch();

  const event = useSelector(state => EventSelectors.getEvent(state));
  const meta = useSelector(state => StudentSelectors.getMeta(state));
  const students = useSelector(state => StudentSelectors.getStudents(state));
  const loading = useSelector(state => StudentSelectors.getLoading(state));

  const setMeta = data => {
    dispatch(StudentActions.setMeta({ ...meta, ...data }));
  };

  const remove = data => {
    dispatch(StudentActions.removeStudentRequest({ id: data.id, eventId: event.id }));
  };

  const columns = studentIndexColumns(remove);

  return (
    <Grid container spacing={3}>
      <Grid item container justify="space-between" xs={12} className="Margin-b-1">
        <Grid item>
          <Typography variant="h5">
            <b>Participantes</b>
          </Typography>
        </Grid>

        <Grid item>
          <Link
            target="_blank"
            rel="noopener noreferrer"
            href={`/events/${event.id}/signup`}
            underline="none"
          >
            <Button fullheight secondary>
              Link de cadastro
            </Button>
          </Link>
        </Grid>

        <Grid item>
          <Link href={`/organizing/students/new?event_id=${event.id}`} underline="none">
            <Button fullheight>Novo participante</Button>
          </Link>
        </Grid>
      </Grid>

      <Grid item xs={12}>
        <Table data={students} columns={columns} loading={loading} meta={meta} setMeta={setMeta} />
      </Grid>
    </Grid>
  );
};
