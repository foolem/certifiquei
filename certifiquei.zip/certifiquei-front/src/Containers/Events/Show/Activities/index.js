/* eslint-disable react/no-danger */
import React from 'react';
import { Grid, Link, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import ActivityActions, { ActivitySelectors } from '../../../../Modules/Activity';
import { EventSelectors } from '../../../../Modules/Event';

import Table from '../../../../Components/Table';
import Button from '../../../../Components/Btn';
import PresenceDialog from '../../../../Components/Dialog/Presence';

import { activityIndexColumns } from '../../../../Helpers/Columns/Activity';

export default () => {
  const dispatch = useDispatch();

  const meta = useSelector(state => ActivitySelectors.getMeta(state));
  const activities = useSelector(state => ActivitySelectors.getActivities(state));
  const loading = useSelector(state => ActivitySelectors.getLoading(state));
  const event = useSelector(state => EventSelectors.getEvent(state));

  const setMeta = data => {
    dispatch(ActivityActions.setMeta({ ...meta, ...data }));
  };

  const remove = data => {
    dispatch(ActivityActions.removeActivityRequest(data.id));
  };

  const initPresence = data => {
    dispatch(ActivityActions.togglePresenceNav(data));
  };

  const columns = activityIndexColumns(remove, initPresence);

  return (
    <Grid container spacing={3}>
      <Grid item container justify="space-between" xs={12} className="Margin-b-1">
        <Grid item>
          <Typography variant="h5">
            <b>Atividades</b>
          </Typography>
        </Grid>

        <Grid item>
          <Link href={`/organizing/activities/new?event_id=${event.id}`} underline="none">
            <Button fullheight>Nova atividade</Button>
          </Link>
        </Grid>
      </Grid>

      <Grid item xs={12}>
        <Table
          data={activities}
          columns={columns}
          loading={loading}
          meta={meta}
          setMeta={setMeta}
        />
      </Grid>

      <PresenceDialog />
    </Grid>
  );
};
