import React, { useEffect } from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';

import EventActions, { EventSelectors } from '../../../Modules/Event';
import CertificateActions from '../../../Modules/Certificate';

import Form from '../../../Components/Form';
import Button from '../../../Components/Btn';
import StepDefault from '../../../Components/StepDefault';
import Body from '../../../Components/Body';

import General from '../Form/General';
import Activities from '../Form/Activities';
import Certificate from '../Form/Certificate';
import Securities from '../Form/Securities';
import Published from '../Form/Published';

import generalSchema from '../Form/General/validation';
import activitiesSchema from '../Form/Activities/validation';
import certificateSchema from '../Form/Certificate/validation';
import securitiesSchema from '../Form/Securities/validation';

export default () => {
  const dispatch = useDispatch();
  const event = useSelector(state => EventSelectors.getNewEvent(state));
  const loading = useSelector(state => EventSelectors.getLoading(state));

  const { step } = event;
  const stepTitles = ['Geral', 'Atividades', 'Certificado', 'Segurança', 'Publicação'];
  const disabledBack = step === 0;
  const disabledNext = step === 4;
  const schemas = {
    0: generalSchema,
    1: activitiesSchema,
    2: certificateSchema,
    3: securitiesSchema,
  };

  const handlePrevStep = () => {
    const newStep = step - 1;

    dispatch(EventActions.setNewEvent({ ...event, step: newStep }));
  };

  const handleNextStep = async () => {
    const valid = schemas[step] ? await schemas[step].isValid(event) : true;

    if (!valid) {
      toast.error('Verifique os campos e tente novamente');
      return;
    }

    const newStep = step + 1;

    if (newStep === 4) {
      dispatch(EventActions.createEventRequest());
    } else {
      dispatch(EventActions.setNewEvent({ ...event, step: newStep }));
    }
  };

  useEffect(() => {
    dispatch(CertificateActions.certificatesRequest());
    dispatch(CertificateActions.templatesRequest());
  }, [dispatch]);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Grid item xs={12} className="Margin-t-3 Margin-b-3">
          <Typography variant="h4">
            <b>Novo evento</b>
          </Typography>
        </Grid>

        <Form>
          <StepDefault stepTitles={stepTitles} activeStep={event.step} />

          {step === 0 && <General />}
          {step === 1 && <Activities />}
          {step === 2 && <Certificate />}
          {step === 3 && <Securities />}
          {step === 4 && <Published />}

          <Grid container justify="flex-end" alignItems="center">
            <Button
              secondary
              disabled={disabledBack}
              className="Margin-r-2"
              onClick={handlePrevStep}
            >
              Voltar
            </Button>
            <Button disabled={disabledNext} onClick={handleNextStep} loading={loading}>
              Avançar
            </Button>
          </Grid>
        </Form>
      </Grid>
    </Body>
  );
};
