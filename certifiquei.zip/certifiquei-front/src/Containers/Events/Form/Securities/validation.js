import * as yup from 'yup';

const schema = yup.object().shape({
  securitiesAttributes: yup.array().min(1),
});

export default schema;
