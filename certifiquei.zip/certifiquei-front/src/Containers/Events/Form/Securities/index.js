import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import EventActions, { EventSelectors } from '../../../../Modules/Event';

import Select from '../../../../Components/Form/Select';

export default () => {
  const dispatch = useDispatch();
  const event = useSelector(state => EventSelectors.getNewEvent(state));

  const handleSetEvent = e => {
    const data = {
      ...event,
      securitiesAttributes: e.target.value,
    };

    dispatch(EventActions.setNewEvent(data));
  };

  return (
    <Grid container className="Padding-1">
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Segurança dos certificados</b>
        </Typography>
      </Grid>

      <Grid
        container
        alignItems="center"
        item
        xs={12}
        spacing={3}
        className="Margin-t-1 Margin-b-1"
      >
        <Grid item container spacing={3} xs={12} md={6}>
          <Grid item xs={12} className="Margin-t-1 Margin-b-1">
            <Select
              label="Selecione as seguranças"
              value={event.securitiesAttributes}
              options={[
                { label: 'Segurança Certifiquei', value: 'internal' },
                { label: 'Blockchain', value: 'blockchain' },
              ]}
              multiple
              onChange={handleSetEvent}
            />
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};
