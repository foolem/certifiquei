import * as yup from 'yup';

const schema = yup.object().shape({
  template: yup.object().required(),
});

export default schema;
