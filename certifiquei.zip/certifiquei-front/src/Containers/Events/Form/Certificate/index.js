import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Grid, Link, Typography, Card } from '@material-ui/core';

import EventActions, { EventSelectors } from '../../../../Modules/Event';
import { CertificateSelectors } from '../../../../Modules/Certificate';

import Checkbox from '../../../../Components/Form/Checkbox';
import Input from '../../../../Components/Form/Input';
import CertificateFrame from '../../../../Components/Certificate/CertificateFrame';
import CertificatesDialog from '../../../../Components/Dialog/Certificates';

import { CardCustom } from './styles';

export default () => {
  const dispatch = useDispatch();
  const [modalOpen, setModalOpen] = useState(false);
  const event = useSelector(state => EventSelectors.getNewEvent(state));
  const templates = useSelector(state => CertificateSelectors.getTemplates(state));
  const certificates = useSelector(state => CertificateSelectors.getCertificates(state));

  const handleSetEvent = data => {
    dispatch(EventActions.setNewEvent(data));
  };

  return (
    <Grid container className="Padding-1">
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Certificação</b>
        </Typography>
      </Grid>

      <Grid item xs={12} container spacing={3} className="Margin-b-1">
        <Grid item xs={12} md={4}>
          {event.template && (
            <Card variant="outlined" style={{ width: '15em' }}>
              <CertificateFrame
                certificate={event.template.metadata.fields}
                certificateImage={event.template.metadata.background}
                preview
              />
            </Card>
          )}
          {event.template && (
            <Grid className="Margin-t-1 Margin-b-1">
              <Link onClick={() => setModalOpen(true)}>Trocar modelo do certificado</Link>
            </Grid>
          )}
          {!event.template && (
            <CardCustom variant="outlined" onClick={() => setModalOpen(true)}>
              <Link>Escolha o modelo do certificado</Link>
            </CardCustom>
          )}
          {event.template && <Typography variant="caption">Nome: {event.template.name}</Typography>}
        </Grid>
      </Grid>

      <CertificatesDialog
        open={modalOpen}
        setOpen={setModalOpen}
        action={(data, isTemplate) => {
          handleSetEvent({
            ...event,
            certificateId: isTemplate ? null : data.id,
            certificateTemplateId: isTemplate ? data.id : null,
            template: {
              id: data.id,
              name: data.name,
              price: data.creditsAmount,
              metadata: data.metadata,
            },
          });
          setModalOpen(false);
        }}
        backAction={() => {}}
        backText="Cancelar"
        actionText="Escolher"
        templates={templates}
        certificates={certificates}
      />
    </Grid>
  );
};
