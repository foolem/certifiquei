import styled from 'styled-components';
import { Card } from '@material-ui/core';
import { Fonts, Colors } from '../../../../Themes';

export const CardCustom = styled(Card)`
  width: 100%;
  height: 10em;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  font-size: ${Fonts.link};
  background-color: ${Colors.lightGray} !important;
  border: 0 !important;
`;
