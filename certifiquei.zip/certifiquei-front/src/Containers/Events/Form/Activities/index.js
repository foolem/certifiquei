import React from 'react';
import { Divider, Link, Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import EventActions, { EventSelectors } from '../../../../Modules/Event';

import Input from '../../../../Components/Form/Input';
import { WorkloadMask } from '../../../../Helpers/Masks';

export default () => {
  const dispatch = useDispatch();
  const event = useSelector(state => EventSelectors.getNewEvent(state));

  const handleSetEvent = data => {
    dispatch(EventActions.setNewEvent(data));
  };

  const handleNewActivity = () => {
    handleSetEvent({
      ...event,
      activitiesAttributes: [
        ...event.activitiesAttributes,
        { title: '', description: '', workload: '01:00' },
      ],
    });
  };

  const handleRemoveActivity = index => {
    handleSetEvent({
      ...event,
      activitiesAttributes: event.activitiesAttributes.filter((_item, i) => index !== i),
    });
  };

  return (
    <Grid container className="Padding-1">
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Atividades</b>
        </Typography>
      </Grid>

      {event.activitiesAttributes.map((item, i) => (
        <Grid
          container
          alignItems="center"
          item
          xs={12}
          spacing={3}
          className="Margin-t-1 Margin-b-1"
        >
          <Grid item container spacing={3} xs={12} md={6}>
            <Grid item xs={12} className="Margin-t-1 Margin-b-1">
              <Input
                label="Título*"
                value={item.title}
                onChange={e =>
                  handleSetEvent({
                    ...event,
                    activitiesAttributes: event.activitiesAttributes.map((inner, j) =>
                      i === j ? { ...inner, title: e.target.value } : inner,
                    ),
                  })
                }
              />
            </Grid>
          </Grid>

          <Grid item xs={12} md={6} className="Margin-t-1 Margin-b-1">
            <Input
              label="Descrição"
              value={item.description}
              multiline
              onChange={e =>
                handleSetEvent({
                  ...event,
                  activitiesAttributes: event.activitiesAttributes.map((inner, j) =>
                    i === j ? { ...inner, description: e.target.value } : inner,
                  ),
                })
              }
            />
          </Grid>

          <Grid container item xs={12} md={6} spacing={3} className="Margin-t-1 Margin-b-1">
            <Grid item xs={12}>
              <Input
                label="Carga horária*"
                value={item.workload}
                onChange={e =>
                  handleSetEvent({
                    ...event,
                    activitiesAttributes: event.activitiesAttributes.map((inner, j) =>
                      i === j ? { ...inner, workload: e.target.value } : inner,
                    ),
                  })
                }
                InputProps={{ inputComponent: WorkloadMask }}
              />
              <Typography variant="caption">HH:MM</Typography>
            </Grid>
          </Grid>

          <Grid item container justify="flex-end" xs={12} md={6}>
            <Link onClick={() => handleRemoveActivity(i)}>Remover atividade</Link>
          </Grid>

          <Grid item xs={12}>
            <Divider />
          </Grid>
        </Grid>
      ))}

      <Grid
        container
        item
        xs={12}
        justify="center"
        alignItems="center"
        spacing={3}
        className="Margin-t-1 Margin-b-1"
      >
        <Link onClick={handleNewActivity}>Adicionar atividade</Link>
      </Grid>
    </Grid>
  );
};
