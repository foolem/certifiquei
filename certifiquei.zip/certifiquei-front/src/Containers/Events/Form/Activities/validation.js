import * as yup from 'yup';

const schema = yup.object().shape({
  activitiesAttributes: yup.array().min(1),
});

export default schema;
