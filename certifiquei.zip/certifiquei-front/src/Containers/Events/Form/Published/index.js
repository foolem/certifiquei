import React from 'react';
import { useSelector } from 'react-redux';

import { Grid, Link, Typography } from '@material-ui/core';

import { EventSelectors } from '../../../../Modules/Event';

export default () => {
  const event = useSelector(state => EventSelectors.getNewEvent(state));

  return (
    <Grid container className="Padding-1">
      <Grid item container justify="center" xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Evento publicado!</b>
        </Typography>
      </Grid>
      <Grid item container justify="center" xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="body1">
          Para adicionar estudantes e staffs{' '}
          <Link href={`/organizing/events/${event.id}`}>clique aqui</Link>
        </Typography>
      </Grid>
    </Grid>
  );
};
