import * as yup from 'yup';

const schema = yup.object().shape({
  associates: yup.array().length(1),
  cost: yup.array().length(1),
});

export default schema;
