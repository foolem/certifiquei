import * as yup from 'yup';

const schema = yup.object().shape({
  title: yup.string().required(),
  startsAt: yup.date().required(),
  endsAt: yup.date().required(),
});

export default schema;
