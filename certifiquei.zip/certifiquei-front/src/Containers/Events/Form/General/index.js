import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import EventActions, { EventSelectors } from '../../../../Modules/Event';

import Input from '../../../../Components/Form/Input';
import TextArea from '../../../../Components/Form/TextArea';
import Select from '../../../../Components/Form/Select';

export default () => {
  const dispatch = useDispatch();
  const event = useSelector(state => EventSelectors.getNewEvent(state));

  const handleSetEvent = data => {
    dispatch(EventActions.setNewEvent(data));
  };

  return (
    <Grid container className="Padding-1">
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Informações gerais</b>
        </Typography>
      </Grid>

      {window.location.href.includes('edit') && event.status !== 'delivered' && (
        <Grid item container spacing={3} xs={12}>
          <Grid item xs={12} md={6} className="Margin-t-1 Margin-b-1">
            <Select
              label="Status"
              value={event.status}
              onChange={e => handleSetEvent({ ...event, status: e.target.value })}
              options={[
                { label: 'Rascunho', value: 'draft' },
                { label: 'Ativo', value: 'active' },
                { label: 'Finalizado', value: 'finished' },
              ]}
            />
          </Grid>
        </Grid>
      )}

      <Grid item container spacing={3} xs={12}>
        <Grid item xs={12} md={6} className="Margin-t-1 Margin-b-1">
          <Input
            label="Título*"
            value={event.title}
            onChange={e => handleSetEvent({ ...event, title: e.target.value })}
          />
        </Grid>
      </Grid>

      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <TextArea
          label="Descrição"
          value={event.description}
          onChange={e => dispatch(EventActions.setNewEventDescription(e))}
          height={100}
        />
      </Grid>

      <Grid container item xs={12} spacing={3} className="Margin-t-1 Margin-b-1">
        <Grid item xs={12} md={4}>
          <Input
            label="Data de início*"
            type="date"
            value={event.startsAt}
            onChange={e => handleSetEvent({ ...event, startsAt: e.target.value })}
          />
        </Grid>
        <Grid item xs={12} md={4}>
          <Input
            label="Data de fim*"
            type="date"
            value={event.endsAt}
            onChange={e => handleSetEvent({ ...event, endsAt: e.target.value })}
          />
        </Grid>
      </Grid>
    </Grid>
  );
};
