import React, { useEffect } from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';

import StudentActions, { StudentSelectors } from '../../../Modules/Student';
import EventActions from '../../../Modules/Event';

import Form from '../../../Components/Form';
import Button from '../../../Components/Btn';
import StepDefault from '../../../Components/StepDefault';
import Body from '../../../Components/Body';

import General from '../Form/General';
import Published from '../Form/Published';

import generalSchema from '../Form/General/validation';

export default () => {
  const dispatch = useDispatch();
  const student = useSelector(state => StudentSelectors.getNewStudent(state));
  const loading = useSelector(state => StudentSelectors.getLoading(state));

  const eventId = window.location.href.split('event_id=')[1];

  const { step } = student;
  const stepTitles = ['Geral', 'Criação'];
  const disabledBack = step === 0;
  const disabledNext = step === 1;
  const schemas = {
    0: generalSchema,
  };

  const handlePrevStep = () => {
    const newStep = step - 1;

    dispatch(StudentActions.setNewStudent({ ...student, step: newStep }));
  };

  const handleNextStep = async () => {
    const valid = schemas[step] ? await schemas[step].isValid(student) : true;

    if (!valid) {
      toast.error('Verifique os campos e tente novamente');

      return;
    }

    const newStep = step + 1;

    if (newStep === 1) {
      dispatch(StudentActions.createStudentRequest());
    } else {
      dispatch(StudentActions.setNewStudent({ ...student, step: newStep }));
    }
  };

  useEffect(() => {
    dispatch(EventActions.allEventsRequest());
  }, [dispatch]);

  useEffect(() => {
    if (!!eventId) dispatch(StudentActions.setNewStudent({ ...student, eventId }));
  }, [dispatch, eventId]);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Grid item xs={12} className="Margin-t-3 Margin-b-3">
          <Typography variant="h4">
            <b>Novo participante</b>
          </Typography>
        </Grid>

        <Form>
          <StepDefault stepTitles={stepTitles} activeStep={student.step} />

          {step === 0 && <General />}
          {step === 1 && <Published />}

          <Grid container justify="flex-end" alignItems="center">
            <Button
              secondary
              disabled={disabledBack}
              className="Margin-r-2"
              onClick={handlePrevStep}
            >
              Voltar
            </Button>
            <Button disabled={disabledNext} onClick={handleNextStep} loading={loading}>
              Avançar
            </Button>
          </Grid>
        </Form>
      </Grid>
    </Body>
  );
};
