import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import StudentActions, { StudentSelectors } from '../../../../Modules/Student';
import { EventSelectors } from '../../../../Modules/Event';

import Input from '../../../../Components/Form/Input';
import Select from '../../../../Components/Form/Select';

import { DateMask, GRRMask } from '../../../../Helpers/Masks';

export default () => {
  const dispatch = useDispatch();
  const student = useSelector(state => StudentSelectors.getNewStudent(state));
  const events = useSelector(state => EventSelectors.getAllEvents(state));

  const handleSetStudent = data => {
    dispatch(StudentActions.setNewStudent(data));
  };

  return (
    <Grid container spacing={3} className="Padding-1">
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Informações gerais</b>
        </Typography>
      </Grid>

      {!window.location.href.includes('event_id') && (
        <Grid container item xs={12} md={6} spacing={3} className="Margin-t-1 Margin-b-1">
          <Grid item xs={12}>
            <Select
              label="Evento*"
              value={student.eventId}
              options={events.map(item => ({ value: item.id, label: item.title }))}
              onChange={e => handleSetStudent({ ...student, eventId: e.target.value })}
              disabled={window.location.href.includes('edit')}
            />
          </Grid>
        </Grid>
      )}

      <Grid container item xs={12} spacing={3}>
        <Grid item xs={12} md={6}>
          <Input
            label="Primeiro nome*"
            value={student.firstName}
            onChange={e => handleSetStudent({ ...student, firstName: e.target.value })}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <Input
            label="Sobrenome*"
            value={student.lastName}
            onChange={e => handleSetStudent({ ...student, lastName: e.target.value })}
          />
        </Grid>
      </Grid>

      <Grid container item xs={12} spacing={3}>
        <Grid item xs={12} md={6}>
          <Input
            label="Email*"
            value={student.email}
            onChange={e => handleSetStudent({ ...student, email: e.target.value })}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <Input
            label="GRR"
            value={student.grr}
            onChange={e => handleSetStudent({ ...student, grr: e.target.value })}
            InputProps={{
              inputComponent: GRRMask,
            }}
          />
        </Grid>
      </Grid>
    </Grid>
  );
};
