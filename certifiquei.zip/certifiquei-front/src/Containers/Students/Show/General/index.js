/* eslint-disable react/no-danger */
import React from 'react';
import { Grid, InputLabel, Typography } from '@material-ui/core';
import { useSelector } from 'react-redux';
import { format } from 'date-fns';

import { StudentSelectors } from '../../../../Modules/Student';

export default () => {
  const student = useSelector(state => StudentSelectors.getStudent(state));

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Informações gerais</b>
        </Typography>
      </Grid>

      <Grid item md={6} xs={12}>
        <InputLabel>Nome</InputLabel>
        <Typography variant="body1">{student.firstName}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Sobrenome</InputLabel>
        <Typography variant="body1">{student.lastName}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>E-mail</InputLabel>
        <Typography variant="body1">{student.email}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Evento</InputLabel>
        <Typography variant="body1">{student.eventName}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Membro desde</InputLabel>
        <Typography variant="body1">{format(new Date(student.createdAt), 'dd/MM/yyyy')}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Cadastro expira em</InputLabel>
        <Typography variant="body1">
          {!!student.expiresAt ? format(new Date(student.expiresAt), 'dd/MM/yyyy') : 'N/A'}
        </Typography>
      </Grid>

      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Progresso</b>
        </Typography>
      </Grid>

      <Grid item md={6} xs={12}>
        <InputLabel>Presenças contabilizadas</InputLabel>
        <Typography variant="body1">{student.presencesCount}</Typography>
      </Grid>
    </Grid>
  );
};
