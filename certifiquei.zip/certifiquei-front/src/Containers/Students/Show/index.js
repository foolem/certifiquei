/* eslint-disable react/no-danger */
import React, { useEffect } from 'react';
import { CircularProgress, Grid } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';

import Header from '../../../Components/Headers/Index';
import Form from '../../../Components/Form';
import Body from '../../../Components/Body';
import General from './General';

import StudentActions, { StudentSelectors } from '../../../Modules/Student';

export default () => {
  const dispatch = useDispatch();
  const { id } = useParams();

  const student = useSelector(state => StudentSelectors.getStudent(state));
  const loading = useSelector(state => StudentSelectors.getLoading(state));

  useEffect(() => {
    dispatch(StudentActions.studentRequest(id));
  }, [dispatch, id]);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Header
          title={student.title}
          actionText="Editar"
          href={`/organizing/students/${student.id}/edit`}
        />

        <Grid container className="Margin-t-3">
          <Form>
            {loading && (
              <Grid
                container
                justify="center"
                alignItems="center"
                className="Margin-t-3 Margin-b-3"
              >
                <CircularProgress size={40} />
              </Grid>
            )}

            {!loading && student.id && <General />}
          </Form>
        </Grid>
      </Grid>
    </Body>
  );
};
