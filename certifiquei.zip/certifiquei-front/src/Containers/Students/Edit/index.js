import React, { useEffect } from 'react';
import { CircularProgress, Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import StudentActions, { StudentSelectors } from '../../../Modules/Student';
import EventActions from '../../../Modules/Event';

import Form from '../../../Components/Form';
import Button from '../../../Components/Btn';
import StepDefault from '../../../Components/StepDefault';
import Body from '../../../Components/Body';

import General from '../Form/General';
import Published from '../Form/Published';

export default ({ match }) => {
  const dispatch = useDispatch();
  const student = useSelector(state => StudentSelectors.getStudent(state));
  const newStudent = useSelector(state => StudentSelectors.getNewStudent(state));
  const loading = useSelector(state => StudentSelectors.getLoading(state));

  const { step } = newStudent;
  const stepTitles = ['Geral', 'Publicação'];
  const disabledBack = step === 0;
  const disabledNext = step === 1;

  const handlePrevStep = () => {
    const newStep = step - 1;

    dispatch(StudentActions.setNewStudent({ ...newStudent, step: newStep }));
  };

  const handleNextStep = async () => {
    const newStep = step + 1;

    if (newStep === 1) {
      dispatch(StudentActions.editStudentRequest());
    } else {
      dispatch(StudentActions.setNewStudent({ ...newStudent, step: newStep }));
    }
  };

  useEffect(() => {
    if (!!student.id) {
      dispatch(
        StudentActions.setNewStudent({
          ...student,
          step: 0,
        }),
      );
    }

    return () => {
      dispatch(StudentActions.setNewStudent());
    };
  }, [dispatch, student]);

  useEffect(() => {
    dispatch(StudentActions.studentRequest(match.params.id));
    dispatch(EventActions.allEventsRequest());
  }, [dispatch, match]);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Grid item xs={12} className="Margin-t-3 Margin-b-3">
          <Typography variant="h4">
            <b>Editar participante</b>
          </Typography>
        </Grid>

        <Form>
          <StepDefault stepTitles={stepTitles} activeStep={newStudent.step} />

          {loading && (
            <Grid container justify="center" className="Padding-3 Margin-b-4">
              <CircularProgress />
            </Grid>
          )}

          {!loading && newStudent.id && (
            <>
              {step === 0 && <General />}
              {step === 1 && <Published />}

              <Grid container justify="flex-end" alignItems="center">
                <Button
                  secondary
                  disabled={disabledBack}
                  className="Margin-r-2"
                  onClick={handlePrevStep}
                >
                  Voltar
                </Button>
                <Button disabled={disabledNext} onClick={handleNextStep} loading={loading}>
                  Avançar
                </Button>
              </Grid>
            </>
          )}
        </Form>
      </Grid>
    </Body>
  );
};
