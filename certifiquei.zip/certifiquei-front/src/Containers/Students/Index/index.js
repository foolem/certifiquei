import React, { useEffect } from 'react';
import { Grid } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import Header from '../../../Components/Headers/Index';
import Search from '../../../Components/Filters/Search';
import Filters from '../../../Components/Filters/Filters';
import Table from '../../../Components/Table';
import Body from '../../../Components/Body';

import StudentActions, { StudentSelectors } from '../../../Modules/Student';
import EventActions, { EventSelectors } from '../../../Modules/Event';

import { studentIndexColumns } from '../../../Helpers/Columns/Student';

export default () => {
  const dispatch = useDispatch();
  const events = useSelector(state => EventSelectors.getAllEvents(state));
  const students = useSelector(state => StudentSelectors.getStudents(state));
  const loading = useSelector(state => StudentSelectors.getLoading(state));
  const meta = useSelector(state => StudentSelectors.getMeta(state));

  useEffect(() => {
    dispatch(EventActions.allEventsRequest());
  }, []);

  useEffect(() => {
    dispatch(StudentActions.studentsRequest());
  }, [dispatch, meta.user_first_name_i_cont, meta.active_in, meta.event_id_in]);

  const setMeta = data => {
    dispatch(StudentActions.setMeta({ ...meta, ...data }));
  };

  const remove = data => {
    dispatch(StudentActions.removeStudentRequest({ id: data.id, eventId: data.eventId }));
  };

  const columns = studentIndexColumns(remove);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Header
          title="Participantes"
          actionText="Novo participante"
          href="/organizing/students/new"
        />

        <Grid container spacing={3}>
          <Grid item xs={12} md={6} className="Margin-t-3 Margin-b-3">
            <Search
              label="Procure por nome"
              onSubmit={data => setMeta({ user_first_name_i_cont: data })}
            />
          </Grid>
          <Grid item xs={12} md={6} className="Margin-t-3 Margin-b-3">
            <Filters
              data={meta}
              filters={{
                event_id_in: {
                  name: 'event_id_in',
                  type: 'select',
                  label: 'Eventos',
                  options: events.map(item => ({ value: item.id, label: item.title })),
                },
              }}
              onChange={e => setMeta(e)}
            />
          </Grid>
        </Grid>

        <Grid item xs={12}>
          <Table
            data={students}
            columns={columns}
            loading={loading}
            meta={meta}
            setMeta={setMeta}
          />
        </Grid>
      </Grid>
    </Body>
  );
};
