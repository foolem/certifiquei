import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useParams } from 'react-router-dom';

import { Grid, Typography, CircularProgress } from '@material-ui/core';

import UserActions, { UserSelectors } from '../../Modules/User';

import { Body } from './styles';

export default () => {
  const dispatch = useDispatch();
  const { token } = useParams();
  const loading = useSelector(state => UserSelectors.getLoading(state));

  useEffect(() => {
    if (token) dispatch(UserActions.confirmEmailRequest({ token }));
  }, [token]);

  return (
    <Body style={{ paddingLeft: 0 }}>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6} className="Padding-3">
          <Typography variant="h6" color="primary">
            Confirmando e-mail...
          </Typography>

          {loading && (
            <Grid className="Padding-3">
              <CircularProgress />
            </Grid>
          )}
        </Grid>
      </Grid>
    </Body>
  );
};
