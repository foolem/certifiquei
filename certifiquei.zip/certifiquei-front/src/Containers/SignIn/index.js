import React, { useState, useEffect } from 'react';
import { Grid, Link, InputLabel, TextField, Typography } from '@material-ui/core';
import { toast } from 'react-toastify';

import { useDispatch, useSelector } from 'react-redux';
import UserActions, { UserSelectors } from '../../Modules/User';

import { Body, Main, Form } from './styles';
import { Images } from '../../Themes';
import Btn from '../../Components/Btn';

export default () => {
  const dispatch = useDispatch();
  const loading = useSelector(state => UserSelectors.getLoading(state));
  const [state, setState] = useState({
    email: '',
    password: '',
  });

  useEffect(() => {
    if (window.location.href.includes('noAuth')) {
      toast.error('Você precisa estar logado para acessar essa página');
    }
  }, []);

  return (
    <Body src={Images.images.loginEd}>
      <Grid item xs={12} md={4} className="img-grid" />

      <Grid className="main" container item xs={12} md={8} justify="center">
        <Main>
          <section className="login">
            <div className="title">Login</div>
            <div className="subtitle">
              Faça o login para ter acesso ao seu painel de controle. <br />
            </div>

            <Form className="tr-form">
              <InputLabel className="Margin-t-1">E-mail</InputLabel>
              <TextField
                fullWidth
                variant="outlined"
                placeholder="email@exemplo.com"
                value={state.email}
                onChange={e => setState({ ...state, email: e.target.value })}
              />

              <InputLabel className="Margin-t-1">Senha</InputLabel>
              <TextField
                fullWidth
                variant="outlined"
                placeholder="Digite sua senha"
                type="password"
                value={state.password}
                onChange={e => setState({ ...state, password: e.target.value })}
              />

              <div className="forgot">
                <Link href="/forgot-password">Esqueceu sua senha?</Link>
              </div>
              <div className="submit">
                <Btn
                  fullWidth
                  fullheight
                  className="Margin-r-3"
                  type="submit"
                  onClick={e => {
                    e.preventDefault();
                    dispatch(UserActions.signInRequest(state));
                  }}
                  loading={loading}
                  disabled={loading}
                >
                  Enviar
                </Btn>
                <Typography variant="subtitle1">
                  Não tem conta?{'  '}
                  <a href="/signup">Crie sua conta</a>
                </Typography>
              </div>
            </Form>
          </section>
        </Main>
      </Grid>
    </Body>
  );
};
