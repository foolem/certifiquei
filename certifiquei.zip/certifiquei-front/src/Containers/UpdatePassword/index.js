import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useParams } from 'react-router-dom';

import { Grid, Typography, Link, InputLabel, TextField } from '@material-ui/core';
import { toast } from 'react-toastify';

import UserActions, { UserSelectors } from '../../Modules/User';

import Btn from '../../Components/Btn';
import { Body } from './styles';
import { Images } from '../../Themes';

export default () => {
  const dispatch = useDispatch();
  const { token } = useParams();
  const [password, setPassword] = useState('');
  const [passwordConfirmation, setPasswordConfirmation] = useState('');
  const loading = useSelector(state => UserSelectors.getLoading(state));

  const handleUpdatePassword = () => {
    if (password !== passwordConfirmation) {
      toast.error('As senhas não estão iguais');
      return;
    }

    if (password) dispatch(UserActions.updatePasswordRequest({ token, password }));
  };

  return (
    <Body src={Images.images.loginEd} style={{ paddingLeft: 0 }}>
      <Grid container>
        <Grid item xs={12} md={4} className="img-grid" />

        <Grid item xs={12} md={8} className="Padding-3">
          <Typography variant="h6" color="primary">
            Altere sua senha
          </Typography>

          <Typography variant="caption" className="Margin-b-2">
            Digite sua senha nova e confirme
          </Typography>

          <InputLabel className="Margin-t-2">Nova senha</InputLabel>
          <TextField
            value={password}
            onChange={e => setPassword(e.target.value)}
            fullWidth
            variant="outlined"
            placeholder="Senha"
            type="password"
          />
          <InputLabel className="Margin-t-2">Confirmar nova senha</InputLabel>
          <TextField
            value={passwordConfirmation}
            onChange={e => setPasswordConfirmation(e.target.value)}
            fullWidth
            variant="outlined"
            placeholder="Confirmar senha"
            type="password"
          />

          <Grid container spacing={3} alignItems="center" justify="flex-end" className="Margin-t-1">
            <Grid item md={7} className="D-flex Justify-end">
              <Link href="/signin">Login</Link>
            </Grid>
            <Grid item md={5} className="D-flex Justify-end">
              <Btn
                variant="contained"
                green
                fullWidth
                fullHeight
                disabled={loading}
                loading={loading}
                onClick={handleUpdatePassword}
              >
                Alterar senha
              </Btn>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Body>
  );
};
