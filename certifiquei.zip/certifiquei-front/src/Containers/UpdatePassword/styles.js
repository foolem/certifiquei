import styled from 'styled-components';

export const Body = styled.div`
  display: flex;
  height: 100vh !important;
  img {
    width: 100%;
  }
  .main {
    padding-top: 60px;
  }

  .img-grid {
    background-image: ${props => `url(${props.src})`};
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
    @media (max-width: 900px) {
      display: none;
    }
  }

  .sub-info {
    color: #48484c;
    font-size: 0.9rem;
    font-weight: bold;
  }
`;
