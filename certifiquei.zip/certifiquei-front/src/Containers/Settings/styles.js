import styled from 'styled-components';
import { Colors, Metrics, Fonts } from '../../Themes';

export const CardItem = styled.div`
  color: ${Colors.primaryTextBlack};
  font-size: ${Fonts.link};
  letter-spacing: 0;
  line-height: 16px;
  padding: ${Metrics.defaults.padding};

  &:hover {
    background-color: #f7f7fa;
    color: ${Colors.primaryTextBlue};
    font-weight: bold;
    cursor: pointer;
    transition: all 0.2s ease-in-out;
  }

  ${({ active }) =>
    !!active &&
    `
      background-color: #f7f7fa;
      color: ${Colors.primaryTextBlue};
      font-weight: bold;
      cursor: pointer;
      transition: all .2s ease-in-out;
    `}
`;
