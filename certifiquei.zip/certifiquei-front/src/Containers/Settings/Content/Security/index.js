import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';

import UserActions, { UserSelectors } from '../../../../Modules/User';

import Input from '../../../../Components/Form/Input';
import Button from '../../../../Components/Btn';

export default () => {
  const dispatch = useDispatch();
  const user = useSelector(state => UserSelectors.getNewUser(state));
  const loading = useSelector(state => UserSelectors.getLoading(state));

  const handleSetUser = data => {
    dispatch(UserActions.setNewUser(data));
  };

  const handleSave = async () => {
    const valid = user.password === user.passwordConfirmation;

    if (!valid) {
      toast.error('As senhas não coincidem, por favor, verifique os dados.');

      return;
    }

    dispatch(UserActions.editUserRequest());
  };

  return (
    <Grid container spacing={3} className="Padding-1">
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Segurança e login</b>
        </Typography>
      </Grid>

      <Grid container item xs={12} spacing={3}>
        <Grid item xs={12} md={6}>
          <Input
            label="Senha"
            type="password"
            value={user.password}
            onChange={e => handleSetUser({ ...user, password: e.target.value })}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <Input
            label="Confirme a senha"
            type="password"
            value={user.passwordConfirmation}
            onChange={e => handleSetUser({ ...user, passwordConfirmation: e.target.value })}
          />
        </Grid>
      </Grid>

      <Grid container justify="flex-end" alignItems="center" className="Margin-t-3">
        <Button onClick={handleSave} loading={loading}>
          Salvar
        </Button>
      </Grid>
    </Grid>
  );
};
