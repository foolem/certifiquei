import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';

import UserActions, { UserSelectors } from '../../../../Modules/User';

import Button from '../../../../Components/Btn';
import Input from '../../../../Components/Form/Input';

import { GRRMask } from '../../../../Helpers/Masks';

import schema from './validation';

export default () => {
  const dispatch = useDispatch();

  const user = useSelector(state => UserSelectors.getNewUser(state));
  const loading = useSelector(state => UserSelectors.getLoading(state));

  const handleSetUser = data => {
    dispatch(UserActions.setNewUser(data));
  };

  const handleSave = async () => {
    const valid = await schema.isValid(user);

    if (!valid) {
      toast.error('Verifique os campos e tente novamente');

      return;
    }

    dispatch(UserActions.editUserRequest());
  };

  return (
    <Grid container spacing={3} className="Padding-1">
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Informações gerais</b>
        </Typography>
      </Grid>

      <Grid container item xs={12} spacing={3}>
        <Grid item xs={12} md={6}>
          <Input
            label="Primeiro nome*"
            value={user.firstName}
            onChange={e => handleSetUser({ ...user, firstName: e.target.value })}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <Input
            label="Sobrenome*"
            value={user.lastName}
            onChange={e => handleSetUser({ ...user, lastName: e.target.value })}
          />
        </Grid>
      </Grid>

      <Grid container item xs={12} spacing={3}>
        <Grid item xs={12} md={6}>
          <Input
            label="Email*"
            value={user.email}
            onChange={e => handleSetUser({ ...user, email: e.target.value })}
          />
        </Grid>

        {user.userType === 'regular' && (
          <Grid item xs={12} md={6}>
            <Input
              label="GRR"
              value={user.grr}
              onChange={e => handleSetUser({ ...user, grr: e.target.value })}
              InputProps={{ inputComponent: GRRMask }}
            />
          </Grid>
        )}

        {user.userType === 'manager' && (
          <Grid item xs={12} md={6}>
            <Input
              label="Curso"
              value={user.course}
              onChange={e => handleSetUser({ ...user, course: e.target.value })}
            />
          </Grid>
        )}
      </Grid>

      <Grid container justify="flex-end" alignItems="center" className="Margin-t-3">
        <Button onClick={handleSave} loading={loading}>
          Salvar
        </Button>
      </Grid>
    </Grid>
  );
};
