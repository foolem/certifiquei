import React, { useEffect, useState } from 'react';
import { Grid, Card, CardContent } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import Header from '../../Components/Headers/Index';
import Body from '../../Components/Body';

import GeneralContent from './Content/General';
import SecurityContent from './Content/Security';

import { CardItem } from './styles';

import UserActions, { UserSelectors } from '../../Modules/User';

export default () => {
  const dispatch = useDispatch();

  const user = useSelector(state => UserSelectors.getUser(state));

  const [content, setContent] = useState('general');

  const handleSetUser = data => {
    dispatch(UserActions.setNewUser(data));
  };

  useEffect(() => {
    dispatch(UserActions.validateTokenRequest());
  }, [dispatch]);

  useEffect(() => {
    handleSetUser({ ...user });
  }, [user]);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Header title="Configurações" className="Margin-b-3" />

        <Grid container spacing={3}>
          <Grid item className="Margin-t-3" xs={12} md={3}>
            <Card>
              <CardContent>
                <CardItem onClick={() => setContent('general')} active={content === 'general'}>
                  Geral
                </CardItem>
                <CardItem onClick={() => setContent('security')} active={content === 'security'}>
                  Segurança e login
                </CardItem>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={9} className="Margin-t-3 Margin-b-3">
            <Card>
              <CardContent>
                {content === 'general' ? <GeneralContent /> : <SecurityContent />}
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Grid>
    </Body>
  );
};
