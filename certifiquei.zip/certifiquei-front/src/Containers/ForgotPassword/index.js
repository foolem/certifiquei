import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Grid, Typography, Link, InputLabel, TextField } from '@material-ui/core';

import UserActions, { UserSelectors } from '../../Modules/User';

import Btn from '../../Components/Btn';
import { Body } from './styles';
import { Images } from '../../Themes';

export default () => {
  const dispatch = useDispatch();
  const [email, setEmail] = useState('');
  const loading = useSelector(state => UserSelectors.getLoading(state));

  const handleForgotPassword = () => {
    if (email) dispatch(UserActions.resetPasswordRequest({ email }));
  };

  return (
    <Body src={Images.images.loginEd} style={{ paddingLeft: 0 }}>
      <Grid container>
        <Grid item xs={12} md={4} className="img-grid" />

        <Grid item xs={12} md={8} className="Padding-3">
          <Typography variant="h6" color="primary">
            Esqueceu sua senha?
          </Typography>

          <Typography variant="caption" className="Margin-b-2">
            Informe seu email para podermos lhe enviar uma nova senha.
          </Typography>

          <InputLabel className="Margin-t-2">Email*</InputLabel>
          <TextField
            value={email}
            onChange={e => setEmail(e.target.value)}
            fullWidth
            variant="outlined"
            placeholder="Email"
          />

          <Grid container spacing={3} alignItems="center" justify="flex-end" className="Margin-t-1">
            <Grid item md={7} className="D-flex Justify-end">
              <Link href="/signin">Login</Link>
            </Grid>
            <Grid item md={5} className="D-flex Justify-end">
              <Btn
                variant="contained"
                green
                fullWidth
                fullHeight
                disabled={loading}
                loading={loading}
                onClick={handleForgotPassword}
              >
                Enviar email
              </Btn>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Body>
  );
};
