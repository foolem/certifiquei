/* eslint-disable react/no-danger */
import React from 'react';
import { Grid, InputLabel, Typography } from '@material-ui/core';
import { useSelector } from 'react-redux';
import { format } from 'date-fns';

import { StudentSelectors } from '../../../../Modules/Student';

export default () => {
  const staff = useSelector(state => StudentSelectors.getStudent(state));

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Informações gerais</b>
        </Typography>
      </Grid>

      <Grid item md={6} xs={12}>
        <InputLabel>Nome</InputLabel>
        <Typography variant="body1">{staff.firstName}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Sobrenome</InputLabel>
        <Typography variant="body1">{staff.lastName}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>E-mail</InputLabel>
        <Typography variant="body1">{staff.email}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Evento</InputLabel>
        <Typography variant="body1">{staff.eventName}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Membro desde</InputLabel>
        <Typography variant="body1">{format(new Date(staff.createdAt), 'dd/MM/yyyy')}</Typography>
      </Grid>
    </Grid>
  );
};
