/* eslint-disable react/no-danger */
import React, { useEffect } from 'react';
import { CircularProgress, Grid } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';

import Header from '../../../Components/Headers/Index';
import Form from '../../../Components/Form';
import Body from '../../../Components/Body';
import General from './General';

import StaffActions, { StaffSelectors } from '../../../Modules/Staff';

export default () => {
  const dispatch = useDispatch();
  const { id } = useParams();

  const staff = useSelector(state => StaffSelectors.getStaff(state));
  const loading = useSelector(state => StaffSelectors.getLoading(state));

  useEffect(() => {
    dispatch(StaffActions.staffRequest(id));
    dispatch(StaffActions.staffTestsRequest(id));
  }, [dispatch, id]);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Header
          title={staff.title}
          actionText="Editar"
          href={`/organizing/staffs/${staff.id}/edit`}
        />

        <Grid container className="Margin-t-3">
          <Form>
            {loading && (
              <Grid
                container
                justify="center"
                alignItems="center"
                className="Margin-t-3 Margin-b-3"
              >
                <CircularProgress size={40} />
              </Grid>
            )}

            {!loading && staff.id && <General />}
          </Form>
        </Grid>
      </Grid>
    </Body>
  );
};
