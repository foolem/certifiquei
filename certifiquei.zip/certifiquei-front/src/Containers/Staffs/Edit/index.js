import React, { useEffect } from 'react';
import { CircularProgress, Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import StaffActions, { StaffSelectors } from '../../../Modules/Staff';
import EventActions from '../../../Modules/Event';

import Form from '../../../Components/Form';
import Button from '../../../Components/Btn';
import StepDefault from '../../../Components/StepDefault';
import Body from '../../../Components/Body';

import General from '../Form/General';
import Published from '../Form/Published';

export default ({ match }) => {
  const dispatch = useDispatch();
  const staff = useSelector(state => StaffSelectors.getStaff(state));
  const newStaff = useSelector(state => StaffSelectors.getNewStaff(state));
  const loading = useSelector(state => StaffSelectors.getLoading(state));

  const { step } = newStaff;
  const stepTitles = ['Geral', 'Publicação'];
  const disabledBack = step === 0;
  const disabledNext = step === 1;

  const handlePrevStep = () => {
    const newStep = step - 1;

    dispatch(StaffActions.setNewStaff({ ...newStaff, step: newStep }));
  };

  const handleNextStep = async () => {
    const newStep = step + 1;

    if (newStep === 1) {
      dispatch(StaffActions.editStaffRequest());
    } else {
      dispatch(StaffActions.setNewStaff({ ...newStaff, step: newStep }));
    }
  };

  useEffect(() => {
    if (!!staff.id) {
      dispatch(
        StaffActions.setNewStaff({
          ...staff,
          step: 0,
        }),
      );
    }

    return () => {
      dispatch(StaffActions.setNewStaff());
    };
  }, [dispatch, staff]);

  useEffect(() => {
    dispatch(StaffActions.staffRequest(match.params.id));
    dispatch(EventActions.allEventsRequest());
  }, [dispatch, match]);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Grid item xs={12} className="Margin-t-3 Margin-b-3">
          <Typography variant="h4">
            <b>Editar staff</b>
          </Typography>
        </Grid>

        <Form>
          <StepDefault stepTitles={stepTitles} activeStep={newStaff.step} />

          {loading && (
            <Grid container justify="center" className="Padding-3 Margin-b-4">
              <CircularProgress />
            </Grid>
          )}

          {!loading && newStaff.id && (
            <>
              {step === 0 && <General />}
              {step === 1 && <Published />}

              <Grid container justify="flex-end" alignItems="center">
                <Button
                  secondary
                  disabled={disabledBack}
                  className="Margin-r-2"
                  onClick={handlePrevStep}
                >
                  Voltar
                </Button>
                <Button disabled={disabledNext} onClick={handleNextStep} loading={loading}>
                  Avançar
                </Button>
              </Grid>
            </>
          )}
        </Form>
      </Grid>
    </Body>
  );
};
