import React, { useEffect } from 'react';
import { Grid } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import Header from '../../../Components/Headers/Index';
import Search from '../../../Components/Filters/Search';
import Filters from '../../../Components/Filters/Filters';
import Table from '../../../Components/Table';
import Body from '../../../Components/Body';

import StaffActions, { StaffSelectors } from '../../../Modules/Staff';
import EventActions from '../../../Modules/Event';

import { staffIndexColumns } from '../../../Helpers/Columns/Staff';

export default () => {
  const dispatch = useDispatch();
  const events = useSelector(state => StaffSelectors.getAllStaffs(state));
  const staffs = useSelector(state => StaffSelectors.getStaffs(state));
  const loading = useSelector(state => StaffSelectors.getLoading(state));
  const meta = useSelector(state => StaffSelectors.getMeta(state));

  useEffect(() => {
    dispatch(EventActions.allEventsRequest());
  }, [dispatch]);

  useEffect(() => {
    dispatch(StaffActions.staffsRequest());
  }, [dispatch, meta.user_first_name_i_cont, meta.active_in, meta.event_id_in]);

  const setMeta = data => {
    dispatch(StaffActions.setMeta({ ...meta, ...data }));
  };

  const remove = data => {
    dispatch(StaffActions.removeStaffRequest(data.id));
  };

  const columns = staffIndexColumns(remove);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Header title="Staffs" actionText="Novo staff" href="/organizing/staffs/new" />

        <Grid container spacing={3}>
          <Grid item xs={12} md={6} className="Margin-t-3 Margin-b-3">
            <Search
              label="Procure por nome"
              onSubmit={data => setMeta({ user_first_name_i_cont: data })}
            />
          </Grid>
          <Grid item xs={12} md={6} className="Margin-t-3 Margin-b-3">
            <Filters
              data={meta}
              filters={{
                event_id_in: {
                  name: 'event_id_in',
                  type: 'select',
                  label: 'Staffos',
                  options: events.map(item => ({ value: item.id, label: item.title })),
                },
              }}
              onChange={e => setMeta(e)}
            />
          </Grid>
        </Grid>

        <Grid item xs={12}>
          <Table data={staffs} columns={columns} loading={loading} meta={meta} setMeta={setMeta} />
        </Grid>
      </Grid>
    </Body>
  );
};
