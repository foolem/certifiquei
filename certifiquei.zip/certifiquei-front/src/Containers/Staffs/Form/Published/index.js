import React from 'react';
import { Grid, Link, Typography } from '@material-ui/core';

export default () => {
  return (
    <Grid container className="Padding-1">
      <Grid item container justify="center" xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Staff salvo!</b>
        </Typography>
      </Grid>

      {!window.location.href.includes('edit') && (
        <Grid item container justify="center" xs={12} className="Margin-t-1 Margin-b-1">
          <Typography variant="subtitle1">
            Um e-mail de confirmação foi enviado ao staff.
          </Typography>
        </Grid>
      )}
      <Grid item container justify="center" xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="body1">
          <Link onClick={() => window.history.back()}>Clique aqui</Link> para voltar
        </Typography>
      </Grid>
    </Grid>
  );
};
