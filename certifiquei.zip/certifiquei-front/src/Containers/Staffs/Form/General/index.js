import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import StaffActions, { StaffSelectors } from '../../../../Modules/Staff';
import { EventSelectors } from '../../../../Modules/Event';

import Input from '../../../../Components/Form/Input';
import Select from '../../../../Components/Form/Select';

import { GRRMask } from '../../../../Helpers/Masks';

export default () => {
  const dispatch = useDispatch();
  const staff = useSelector(state => StaffSelectors.getNewStaff(state));
  const events = useSelector(state => EventSelectors.getAllEvents(state));

  const handleSetStaff = data => {
    dispatch(StaffActions.setNewStaff(data));
  };

  return (
    <Grid container spacing={3} className="Padding-1">
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Informações gerais</b>
        </Typography>
      </Grid>

      {!window.location.href.includes('event_id') && (
        <Grid container item xs={12} md={6} spacing={3} className="Margin-t-1 Margin-b-1">
          <Grid item xs={12}>
            <Select
              label="Evento*"
              value={staff.eventId}
              options={events.map(item => ({ value: item.id, label: item.title }))}
              onChange={e => handleSetStaff({ ...staff, eventId: e.target.value })}
              disabled={window.location.href.includes('edit')}
            />
          </Grid>
        </Grid>
      )}

      <Grid container item xs={12} spacing={3}>
        <Grid item xs={12} md={6}>
          <Input
            label="Primeiro nome*"
            value={staff.firstName}
            onChange={e => handleSetStaff({ ...staff, firstName: e.target.value })}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <Input
            label="Sobrenome*"
            value={staff.lastName}
            onChange={e => handleSetStaff({ ...staff, lastName: e.target.value })}
          />
        </Grid>
      </Grid>

      <Grid container item xs={12} spacing={3}>
        <Grid item xs={12} md={6}>
          <Input
            label="Email*"
            value={staff.email}
            onChange={e => handleSetStaff({ ...staff, email: e.target.value })}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <Input
            label="GRR"
            value={staff.grr}
            onChange={e => handleSetStaff({ ...staff, grr: e.target.value })}
            InputProps={{
              inputComponent: GRRMask,
            }}
          />
        </Grid>
      </Grid>
    </Grid>
  );
};
