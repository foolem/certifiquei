import React, { useEffect } from 'react';
import { CircularProgress, Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import ActivityActions, { ActivitySelectors } from '../../../Modules/Activity';
import EventActions from '../../../Modules/Event';

import Form from '../../../Components/Form';
import Button from '../../../Components/Btn';
import StepDefault from '../../../Components/StepDefault';
import Body from '../../../Components/Body';

import General from '../Form/General';
import Published from '../Form/Published';

export default ({ match }) => {
  const dispatch = useDispatch();
  const activity = useSelector(state => ActivitySelectors.getActivity(state));
  const newActivity = useSelector(state => ActivitySelectors.getNewActivity(state));
  const loading = useSelector(state => ActivitySelectors.getLoading(state));

  const { step } = newActivity;
  const stepTitles = ['Geral', 'Publicação'];
  const disabledBack = step === 0;
  const disabledNext = step === 1;

  const handlePrevStep = () => {
    const newStep = step - 1;

    dispatch(ActivityActions.setNewActivity({ ...newActivity, step: newStep }));
  };

  const handleNextStep = async () => {
    const newStep = step + 1;

    if (newStep === 1) {
      dispatch(ActivityActions.editActivityRequest());
    } else {
      dispatch(ActivityActions.setNewActivity({ ...newActivity, step: newStep }));
    }
  };

  useEffect(() => {
    if (!!activity.id) {
      dispatch(
        ActivityActions.setNewActivity({
          ...activity,
          step: 0,
        }),
      );
    }

    return () => {
      dispatch(ActivityActions.setNewActivity());
    };
  }, [dispatch, activity]);

  useEffect(() => {
    dispatch(ActivityActions.activityRequest(match.params.id));
    dispatch(EventActions.allEventsRequest());
  }, [dispatch, match]);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Grid item xs={12} className="Margin-t-3 Margin-b-3">
          <Typography variant="h4">
            <b>Editar atividade</b>
          </Typography>
        </Grid>

        <Form>
          <StepDefault stepTitles={stepTitles} activeStep={newActivity.step} />

          {loading && (
            <Grid container justify="center" className="Padding-3 Margin-b-4">
              <CircularProgress />
            </Grid>
          )}

          {!loading && newActivity.id && (
            <>
              {step === 0 && <General />}
              {step === 1 && <Published />}

              <Grid container justify="flex-end" alignItems="center">
                <Button
                  secondary
                  disabled={disabledBack}
                  className="Margin-r-2"
                  onClick={handlePrevStep}
                >
                  Voltar
                </Button>
                <Button disabled={disabledNext} onClick={handleNextStep} loading={loading}>
                  Avançar
                </Button>
              </Grid>
            </>
          )}
        </Form>
      </Grid>
    </Body>
  );
};
