import React, { useEffect } from 'react';
import { Grid } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import Header from '../../../Components/Headers/Index';
import Search from '../../../Components/Filters/Search';
import Filters from '../../../Components/Filters/Filters';
import Table from '../../../Components/Table';
import Body from '../../../Components/Body';
import PresenceDialog from '../../../Components/Dialog/Presence';

import ActivityActions, { ActivitySelectors } from '../../../Modules/Activity';
import EventActions, { EventSelectors } from '../../../Modules/Event';

import { activityIndexColumns } from '../../../Helpers/Columns/Activity';

export default () => {
  const dispatch = useDispatch();
  const events = useSelector(state => EventSelectors.getAllEvents(state));
  const activities = useSelector(state => ActivitySelectors.getActivities(state));
  const loading = useSelector(state => ActivitySelectors.getLoading(state));
  const meta = useSelector(state => ActivitySelectors.getMeta(state));

  useEffect(() => {
    dispatch(EventActions.allEventsRequest());
  }, []);

  useEffect(() => {
    dispatch(ActivityActions.activitiesRequest());
  }, [dispatch, meta.title_i_cont, meta.event_id_in]);

  const setMeta = data => {
    dispatch(ActivityActions.setMeta({ ...meta, ...data }));
  };

  const remove = data => {
    dispatch(ActivityActions.removeActivityRequest(data.id));
  };

  const initPresence = data => {
    dispatch(ActivityActions.togglePresenceNav(data));
  };

  const columns = activityIndexColumns(remove, initPresence, true);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Header title="Atividades" actionText="Nova atividade" href="/organizing/activities/new" />

        <Grid container spacing={3}>
          <Grid item xs={12} md={6} className="Margin-t-3 Margin-b-3">
            <Search label="Procure por nome" onSubmit={data => setMeta({ title_i_cont: data })} />
          </Grid>
          <Grid item xs={12} md={6} className="Margin-t-3 Margin-b-3">
            <Filters
              data={meta}
              filters={{
                event_id_in: {
                  name: 'event_id_in',
                  type: 'select',
                  label: 'Eventos',
                  options: events.map(item => ({ value: item.id, label: item.title })),
                },
              }}
              onChange={e => setMeta(e)}
            />
          </Grid>
        </Grid>

        <Grid item xs={12}>
          <Table
            data={activities}
            columns={columns}
            loading={loading}
            meta={meta}
            setMeta={setMeta}
          />
        </Grid>
      </Grid>

      <PresenceDialog />
    </Body>
  );
};
