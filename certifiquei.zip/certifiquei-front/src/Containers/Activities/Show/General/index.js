/* eslint-disable react/no-danger */
import React from 'react';
import { Grid, InputLabel, Typography } from '@material-ui/core';
import { useSelector } from 'react-redux';

import { ActivitySelectors } from '../../../../Modules/Activity';

export default () => {
  const activity = useSelector(state => ActivitySelectors.getActivity(state));

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Informações gerais</b>
        </Typography>
      </Grid>

      <Grid item md={6} xs={12}>
        <InputLabel>Título</InputLabel>
        <Typography variant="body1">{activity.title}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Descrição</InputLabel>
        <Typography variant="body1">{activity.description}</Typography>
      </Grid>
      <Grid item md={6} xs={12}>
        <InputLabel>Presenças contabilizadas</InputLabel>
        <Typography variant="body1">{activity.presencesCount}</Typography>
      </Grid>
    </Grid>
  );
};
