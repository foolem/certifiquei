/* eslint-disable react/no-danger */
import React, { useEffect } from 'react';
import { CircularProgress, Grid } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';

import Header from '../../../Components/Headers/Index';
import Form from '../../../Components/Form';
import Body from '../../../Components/Body';
import Button from '../../../Components/Btn';
import PresencesDialog from '../../../Components/Dialog/Presence';

import General from './General';
import Presences from './Presences';

import ActivityActions, { ActivitySelectors } from '../../../Modules/Activity';
import PresenceActions, { PresenceSelectors } from '../../../Modules/Presence';

export default () => {
  const dispatch = useDispatch();
  const { id } = useParams();

  const activity = useSelector(state => ActivitySelectors.getActivity(state));
  const loading = useSelector(state => ActivitySelectors.getLoading(state));
  const presencesMeta = useSelector(state => PresenceSelectors.getMeta(state));

  useEffect(() => {
    dispatch(ActivityActions.activityRequest(id));
  }, [dispatch, id]);

  useEffect(() => {
    dispatch(PresenceActions.presencesRequest(id));
  }, [dispatch, presencesMeta]);

  const togglePresenceNav = () => {
    dispatch(ActivityActions.togglePresenceNav(activity));
  };

  return (
    <Body>
      <Grid container className="Padding-1">
        <Header
          title={activity.title}
          actionText="Editar"
          href={`/organizing/activities/${activity.id}/edit`}
        />

        <Button onClick={togglePresenceNav} secondary className="Margin-t-1">
          Adicionar presenças
        </Button>

        <Grid container className="Margin-t-3">
          {loading && (
            <Grid container justify="center" alignItems="center" className="Margin-t-3 Margin-b-3">
              <CircularProgress size={40} />
            </Grid>
          )}

          <Form className="Margin-t-3">{!loading && activity.id && <General />}</Form>
          <Form className="Margin-t-3">{!loading && activity.id && <Presences />}</Form>
        </Grid>
      </Grid>

      <PresencesDialog />
    </Body>
  );
};
