/* eslint-disable react/no-danger */
import React from 'react';
import { Grid, Link, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import PresenceActions, { PresenceSelectors } from '../../../../Modules/Presence';
import { ActivitySelectors } from '../../../../Modules/Activity';

import Table from '../../../../Components/Table';
import Button from '../../../../Components/Btn';

import { presenceIndexColumns } from '../../../../Helpers/Columns/Presence';

export default () => {
  const dispatch = useDispatch();

  const activity = useSelector(state => ActivitySelectors.getActivity(state));
  const meta = useSelector(state => PresenceSelectors.getMeta(state));
  const presences = useSelector(state => PresenceSelectors.getPresences(state));
  const loading = useSelector(state => PresenceSelectors.getLoading(state));

  const setMeta = data => {
    dispatch(PresenceActions.setMeta({ ...meta, ...data }));
  };

  const remove = data => {
    dispatch(PresenceActions.removePresenceRequest({ activityId: activity.id, id: data.id }));
  };

  const columns = presenceIndexColumns(remove);

  return (
    <Grid container spacing={3}>
      <Grid item container justify="space-between" xs={12} className="Margin-b-1">
        <Grid item>
          <Typography variant="h5">
            <b>Presenças</b>
          </Typography>
        </Grid>

        <Grid item>
          <Link href={`/organizing/presences/new?activity_id=${activity.id}`} underline="none">
            <Button fullheight>Nova presença</Button>
          </Link>
        </Grid>
      </Grid>

      <Grid item xs={12}>
        <Table data={presences} columns={columns} loading={loading} meta={meta} setMeta={setMeta} />
      </Grid>
    </Grid>
  );
};
