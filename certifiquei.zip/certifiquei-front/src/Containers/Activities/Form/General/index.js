import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import ActivityActions, { ActivitySelectors } from '../../../../Modules/Activity';
import { EventSelectors } from '../../../../Modules/Event';

import Input from '../../../../Components/Form/Input';
import Select from '../../../../Components/Form/Select';

import { WorkloadMask } from '../../../../Helpers/Masks';

export default () => {
  const dispatch = useDispatch();
  const activity = useSelector(state => ActivitySelectors.getNewActivity(state));
  const events = useSelector(state => EventSelectors.getAllEvents(state));

  const handleSetActivity = data => {
    dispatch(ActivityActions.setNewActivity(data));
  };

  return (
    <Grid container spacing={3} className="Padding-1">
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Informações gerais</b>
        </Typography>
      </Grid>

      {!window.location.href.includes('event_id') && (
        <Grid container item xs={12} md={6} spacing={3} className="Margin-t-1 Margin-b-1">
          <Grid item xs={12}>
            <Select
              label="Evento*"
              value={activity.eventId}
              options={events.map(item => ({ value: item.id, label: item.title }))}
              onChange={e => handleSetActivity({ ...activity, eventId: e.target.value })}
              disabled={window.location.href.includes('edit')}
            />
          </Grid>
        </Grid>
      )}

      <Grid container item xs={12} spacing={3}>
        <Grid item xs={12} md={6}>
          <Input
            label="Título*"
            value={activity.title}
            onChange={e => handleSetActivity({ ...activity, title: e.target.value })}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <Input
            label="Descrição*"
            value={activity.description}
            onChange={e => handleSetActivity({ ...activity, description: e.target.value })}
          />
        </Grid>
      </Grid>

      <Grid container item xs={12} spacing={3}>
        <Grid item xs={12} md={6}>
          <Input
            label="Carga horária*"
            value={activity.workload}
            onChange={e => handleSetActivity({ ...activity, workload: e.target.value })}
            InputProps={{ inputComponent: WorkloadMask }}
          />
        </Grid>
      </Grid>
    </Grid>
  );
};
