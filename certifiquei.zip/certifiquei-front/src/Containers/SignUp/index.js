import React, { useState, useEffect } from 'react';
import { Grid, Link } from '@material-ui/core';
import { toast } from 'react-toastify';

import { useDispatch, useSelector } from 'react-redux';
import UserActions, { UserSelectors } from '../../Modules/User';

import Btn from '../../Components/Btn';
import Input from '../../Components/Form/Input';
import Select from '../../Components/Form/Select';

import { Body, Main, Form } from './styles';
import { Images } from '../../Themes';
import { GRRMask } from '../../Helpers/Masks';

export default () => {
  const dispatch = useDispatch();
  const loading = useSelector(state => UserSelectors.getLoading(state));
  const [state, setState] = useState({
    firstName: '',
    lastName: '',
    userType: 'regular',
    course: '',
    grr: 'GRR',
    email: '',
    password: '',
    passwordConfirmation: '',
  });

  useEffect(() => {
    if (window.location.href.includes('noAuth')) {
      toast.error('Você precisa estar logado para acessar essa página');
    }
  }, []);

  return (
    <Body src={Images.images.loginEd}>
      <Grid item xs={12} md={4} className="img-grid" />

      <Grid className="main" container item xs={12} md={8} justify="center">
        <Main>
          <section className="login">
            <div className="title">Cadastro</div>
            <div className="subtitle">Precisamos de alguns dados para criar sua conta.</div>

            <Form className="tr-form">
              <Input
                className="Margin-b-1"
                label="Nome"
                fullWidth
                variant="outlined"
                value={state.firstName}
                onChange={e => setState({ ...state, firstName: e.target.value })}
              />

              <Input
                className="Margin-b-1"
                label="Sobrenome"
                fullWidth
                variant="outlined"
                value={state.lastName}
                onChange={e => setState({ ...state, lastName: e.target.value })}
              />

              <Input
                className="Margin-b-1"
                label="E-mail"
                fullWidth
                variant="outlined"
                placeholder="email@exemplo.com"
                value={state.email}
                onChange={e => setState({ ...state, email: e.target.value })}
              />

              <Select
                className="Margin-b-1"
                label="Tipo de usuário"
                fullWidth
                variant="outlined"
                value={state.userType}
                options={[
                  { label: 'Estudante', value: 'regular' },
                  { label: 'Organizador', value: 'manager' },
                ]}
                onChange={e => setState({ ...state, userType: e.target.value })}
              />

              {state.userType === 'manager' && (
                <Input
                  className="Margin-b-1"
                  label="Curso"
                  fullWidth
                  variant="outlined"
                  value={state.course}
                  onChange={e => setState({ ...state, course: e.target.value })}
                />
              )}

              {state.userType === 'regular' && (
                <Input
                  className="Margin-b-1"
                  label="GRR"
                  fullWidth
                  variant="outlined"
                  value={state.grr}
                  onChange={e => setState({ ...state, grr: e.target.value })}
                  InputProps={{ inputComponent: GRRMask }}
                />
              )}

              <hr className="MuiDivider-root Margin-t-2 Margin-b-2" />

              <Input
                className="Margin-b-1"
                label="Senha"
                fullWidth
                variant="outlined"
                placeholder="Digite sua senha"
                type="password"
                value={state.password}
                onChange={e => setState({ ...state, password: e.target.value })}
              />

              <Input
                className="Margin-b-1"
                label="Confirme a senha"
                fullWidth
                variant="outlined"
                placeholder="Confirme sua senha"
                type="password"
                value={state.passwordConfirmation}
                onChange={e =>
                  setState({
                    ...state,
                    passwordConfirmation: e.target.value,
                  })
                }
              />

              <div className="submit">
                <Btn
                  fullWidth
                  fullheight
                  className="Margin-r-3"
                  type="submit"
                  onClick={e => {
                    e.preventDefault();
                    dispatch(UserActions.signUpRequest(state));
                  }}
                  loading={loading}
                  disabled={loading}
                >
                  Enviar
                </Btn>
              </div>
            </Form>
          </section>
        </Main>
      </Grid>
    </Body>
  );
};
