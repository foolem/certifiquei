import React, { useEffect } from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';

import PresenceActions, { PresenceSelectors } from '../../../Modules/Presence';
import StudentActions from '../../../Modules/Student';
import ActivityActions from '../../../Modules/Activity';
import StaffActions from '../../../Modules/Staff';

import Form from '../../../Components/Form';
import Button from '../../../Components/Btn';
import StepDefault from '../../../Components/StepDefault';
import Body from '../../../Components/Body';

import General from '../Form/General';
import Published from '../Form/Published';

import generalSchema from '../Form/General/validation';

export default () => {
  const dispatch = useDispatch();
  const presence = useSelector(state => PresenceSelectors.getNewPresence(state));
  const loading = useSelector(state => PresenceSelectors.getLoading(state));

  const activityId = window.location.href.split('activity_id=')[1];

  const { step } = presence;
  const stepTitles = ['Geral', 'Criação'];
  const disabledBack = step === 0;
  const disabledNext = step === 1;
  const schemas = {
    0: generalSchema,
  };

  const handlePrevStep = () => {
    const newStep = step - 1;

    dispatch(PresenceActions.setNewPresence({ ...presence, step: newStep }));
  };

  const handleNextStep = async () => {
    const valid = schemas[step] ? await schemas[step].isValid(presence) : true;

    if (!valid) {
      toast.error('Verifique os campos e tente novamente');

      return;
    }

    const newStep = step + 1;

    if (newStep === 1) {
      dispatch(
        ActivityActions.createPresenceRequest(presence.activityId, {
          userId: presence.userId,
          staffId: presence.staffId,
          activityId: presence.activityId,
        }),
      );
    } else {
      dispatch(PresenceActions.setNewPresence({ ...presence, step: newStep }));
    }
  };

  useEffect(() => {
    dispatch(StudentActions.allStudentsRequest());
    dispatch(ActivityActions.allActivitiesRequest());
    dispatch(StaffActions.allStaffsRequest());
  }, [dispatch]);

  useEffect(() => {
    if (!!activityId) dispatch(PresenceActions.setNewPresence({ ...presence, activityId }));
  }, [dispatch, activityId]);

  return (
    <Body>
      <Grid container className="Padding-1">
        <Grid item xs={12} className="Margin-t-3 Margin-b-3">
          <Typography variant="h4">
            <b>Nova presença</b>
          </Typography>
        </Grid>

        <Form>
          <StepDefault stepTitles={stepTitles} activeStep={presence.step} />

          {step === 0 && <General />}
          {step === 1 && <Published />}

          <Grid container justify="flex-end" alignItems="center">
            <Button
              secondary
              disabled={disabledBack}
              className="Margin-r-2"
              onClick={handlePrevStep}
            >
              Voltar
            </Button>
            <Button disabled={disabledNext} onClick={handleNextStep} loading={loading}>
              Avançar
            </Button>
          </Grid>
        </Form>
      </Grid>
    </Body>
  );
};
