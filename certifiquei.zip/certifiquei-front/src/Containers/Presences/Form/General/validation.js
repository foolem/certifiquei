import * as yup from 'yup';

const schema = yup.object().shape({
  userId: yup.string().required(),
  staffId: yup.string().required(),
  activityId: yup.string().required(),
});

export default schema;
