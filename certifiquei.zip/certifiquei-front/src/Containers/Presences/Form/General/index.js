import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';

import PresenceActions, { PresenceSelectors } from '../../../../Modules/Presence';
import { StudentSelectors } from '../../../../Modules/Student';
import { StaffSelectors } from '../../../../Modules/Staff';
import { ActivitySelectors } from '../../../../Modules/Activity';

import Select from '../../../../Components/Form/Select';

export default () => {
  const dispatch = useDispatch();
  const presence = useSelector(state => PresenceSelectors.getNewPresence(state));
  const students = useSelector(state => StudentSelectors.getAllStudents(state));
  const staffs = useSelector(state => StaffSelectors.getAllStaffs(state));
  const activities = useSelector(state => ActivitySelectors.getAllActivities(state));

  const handleSetPresence = data => {
    dispatch(PresenceActions.setNewPresence(data));
  };

  return (
    <Grid container spacing={3} className="Padding-1">
      <Grid item xs={12} className="Margin-t-1 Margin-b-1">
        <Typography variant="h5">
          <b>Informações gerais</b>
        </Typography>
      </Grid>

      <Grid container item xs={12} md={6} spacing={3} className="Margin-t-1 Margin-b-1">
        <Grid item xs={12}>
          <Select
            label="Participante*"
            value={presence.userId}
            options={students.map(item => ({
              value: item.userId,
              label: `${item.firstName} - ${item.email} - ${item.eventName}`,
            }))}
            onChange={e => handleSetPresence({ ...presence, userId: e.target.value })}
          />
        </Grid>
      </Grid>

      <Grid container item xs={12} md={6} spacing={3} className="Margin-t-1 Margin-b-1">
        <Grid item xs={12}>
          <Select
            label="Atividade*"
            value={presence.activityId}
            options={activities.map(item => ({
              value: item.id,
              label: `${item.title} - ${item.eventName}`,
            }))}
            onChange={e => handleSetPresence({ ...presence, activityId: e.target.value })}
          />
        </Grid>
      </Grid>

      <Grid container item xs={12} md={6} spacing={3} className="Margin-t-1 Margin-b-1">
        <Grid item xs={12}>
          <Select
            label="Staff*"
            value={presence.staffId}
            options={staffs.map(item => ({
              value: item.id,
              label: `${item.firstName} - ${item.email} - ${item.eventName}`,
            }))}
            onChange={e => handleSetPresence({ ...presence, staffId: e.target.value })}
          />
        </Grid>
      </Grid>
    </Grid>
  );
};
