import styled from 'styled-components';
import { Grid, Card } from '@material-ui/core';
import { Metrics, Fonts, Colors } from '../../Themes';

export const Body = styled.div`
  display: flex;
  height: 100vh !important;
  img {
    width: 100%;
  }
  .main {
    padding-top: 60px;
  }

  .img-grid {
    background-image: ${props => `url(${props.src})`};
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
    @media (max-width: 900px) {
      display: none;
    }
  }

  .sub-info {
    color: #48484c;
    font-size: 0.9rem;
    font-weight: bold;
  }
`;

export const Main = styled.main`
  width: 100%;
  margin-left: 120px;
  display: flex;
  flex-direction: column;

  @media (max-width: 900px) {
    margin-left: 0;
    padding: 1em;
  }
  header {
    max-width: 700px;
    width: 100%;
    display: flex;
    align-items: center;
    div {
      width: 100%;
      display: flex;
      justify-content: center;
    }
    .text-help {
      display: flex;
      justify-content: flex-end;
      * {
        font-weight: bold;
        font-size: 16px;
        line-height: 24px;
        letter-spacing: 0;
        color: ${Colors.navGray};
        text-decoration: unset;
        &:last-child {
          margin-left: 56px;
        }
      }
    }
    .btn-group {
      justify-content: flex-end;
    }
  }
  section {
    margin-top: 90px;
    display: flex;
    flex-direction: column;
    width: 100%;
    max-width: 580px;

    .title {
      font-size: 32px;
      font-weight: 900;
      letter-spacing: 0;
      line-height: 38px;
      color: ${Colors.primaryTextBlack};
    }

    .subtitle {
      font-size: 16px;
      letter-spacing: 0;
      line-height: 23px;
      padding: 5px 0 25px 0;
      color: ${Colors.navGray};
      a {
        color: ${Colors.primaryTextBlue};
        font-weight: 400 !important;
        text-decoration: underline;
      }
    }

    form {
      width: 100%;
      .forgot {
        margin-top: 18px;
        margin-bottom: 90px;
        a {
          color: ${Colors.primaryTextBlue};
          font-size: 16px;
          letter-spacing: 0;
          line-height: 23px;
          text-decoration: underline;
          font-weight: 400 !important;
        }
      }
      .submit {
        display: flex;
        align-items: center;
        justify-content: flex-start;
        font-size: 14px;
        height: 62px;

        button {
          width: 197px;
        }

        span {
          color: ${Colors.white};
          font-size: 16px;
          a {
            color: ${Colors.primaryTextBlue};
            font-weight: bold;
            text-decoration: underline;
            font-weight: 400 !important;
          }
        }
      }
    }
  }
`;

export const Form = styled.form``;
