import React, { useState, useEffect } from 'react';
import { Grid } from '@material-ui/core';
import { useParams } from 'react-router-dom';

import { useDispatch, useSelector } from 'react-redux';
import UserActions, { UserSelectors } from '../../Modules/User';
import EventActions, { EventSelectors } from '../../Modules/Event';

import Btn from '../../Components/Btn';
import Input from '../../Components/Form/Input';

import { Body, Main, Form } from './styles';
import { Images } from '../../Themes';
import { GRRMask } from '../../Helpers/Masks';

export default () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const loading = useSelector(state => UserSelectors.getLoading(state));
  const event = useSelector(state => EventSelectors.getEvent(state));

  const [state, setState] = useState({
    firstName: '',
    lastName: '',
    userType: 'regular',
    course: '',
    grr: 'GRR',
    email: '',
    password: '',
    passwordConfirmation: '',
    eventId: id,
  });

  useEffect(() => {
    dispatch(EventActions.eventRequest(id));
  }, [dispatch, id]);

  return (
    <Body src={Images.images.loginEd}>
      <Grid item xs={12} md={4} className="img-grid" />

      <Grid className="main" container item xs={12} md={8} justify="center">
        <Main>
          <section className="login">
            <div className="title">{event.title}</div>
            <div className="subtitle">Precisamos de alguns dados para te registrar no evento.</div>

            <Form className="tr-form">
              <Input
                className="Margin-b-1"
                label="Nome"
                fullWidth
                variant="outlined"
                value={state.firstName}
                onChange={e => setState({ ...state, firstName: e.target.value })}
              />

              <Input
                className="Margin-b-1"
                label="Sobrenome"
                fullWidth
                variant="outlined"
                value={state.lastName}
                onChange={e => setState({ ...state, lastName: e.target.value })}
              />

              <Input
                className="Margin-b-1"
                label="E-mail"
                fullWidth
                variant="outlined"
                placeholder="email@exemplo.com"
                value={state.email}
                onChange={e => setState({ ...state, email: e.target.value })}
              />

              <Input
                className="Margin-b-1"
                label="GRR"
                fullWidth
                variant="outlined"
                value={state.grr}
                onChange={e => setState({ ...state, grr: e.target.value })}
                InputProps={{ inputComponent: GRRMask }}
              />

              <hr className="MuiDivider-root Margin-t-2 Margin-b-2" />

              <Input
                className="Margin-b-1"
                label="Senha"
                fullWidth
                variant="outlined"
                placeholder="Digite sua senha"
                type="password"
                value={state.password}
                onChange={e => setState({ ...state, password: e.target.value })}
              />

              <Input
                className="Margin-b-1"
                label="Confirme a senha"
                fullWidth
                variant="outlined"
                placeholder="Confirme sua senha"
                type="password"
                value={state.passwordConfirmation}
                onChange={e =>
                  setState({
                    ...state,
                    passwordConfirmation: e.target.value,
                  })
                }
              />

              <div className="submit">
                <Btn
                  fullWidth
                  fullheight
                  className="Margin-r-3"
                  type="submit"
                  onClick={e => {
                    e.preventDefault();
                    dispatch(UserActions.signUpRequest(state));
                  }}
                  loading={loading}
                  disabled={loading}
                >
                  Enviar
                </Btn>
              </div>
            </Form>
          </section>
        </Main>
      </Grid>
    </Body>
  );
};
