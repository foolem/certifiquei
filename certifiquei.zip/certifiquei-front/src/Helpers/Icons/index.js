import ai from './ai.json';
import bi from './bi.json';
import bs from './bs.json';
import cg from './cg.json';
import di from './di.json';
import fa from './fa.json';
import fc from './fc.json';
import fi from './fi.json';
import gi from './gi.json';
import gr from './gr.json';
import hi from './hi.json';
import im from './im.json';
import io from './io.json';
import md from './md.json';
import ri from './ri.json';
import si from './si.json';
import ti from './ti.json';
import vsc from './vsc.json';
import wi from './wi.json';

const data = [].concat.apply(
  [],
  [ai, bi, bs, cg, di, fa, fc, fi, gi, gr, hi, im, io, md, ri, si, ti, vsc, wi]
);
const hashIcons = {};

data.forEach(item => {
  hashIcons[item.name] = item;
});

export { hashIcons };
export default data;
