export const eventStatus = {
  draft: 'Rascunho',
  active: 'Ativo',
  finished: 'Finalizado',
  delivered: 'Distribuído',
};

export const eventAccessType = {
  eternal: 'Eterno',
  days_after_buy: 'Dias depois da compra',
  specific_date: 'Data específica',
};

export const eventWorkloadType = {
  hour: 'hora',
  day: 'dia',
  week: 'semana',
  month: 'mês',
};

export const eventLecturesViewOrder = {
  free: 'Tudo liberado',
  cascade: 'Em cascata',
};

export const eventModuleStatus = {
  active: 'Ativo',
  disabled: 'Inativo',
};

export const roleNames = {
  admin: 'Admin',
  tutor: 'Tutor',
  teacher: 'Professor',
};

export const themeStatus = {
  disabled: 'Inativo',
  active: 'Ativo',
};

export const couponKinds = {
  fixed: 'Valor fixo',
  percentage: 'Percentual',
};

export const orderKinds = {
  charge: 'Cobrança',
  refund: 'Reembolso',
  split_payment: 'Split',
};

export const orderStrategies = {
  credit_card: 'Cartão de crédito',
  boleto: 'Boleto',
  bonus: 'Bônus',
};

export const orderStatus = {
  pending: 'Pendente',
  successful: 'Sucesso',
  failure: 'Falha',
};

export const testKinds = {
  on_starting: 'Início do módulo',
  on_finishing: 'Final do módulo',
};

export const testTimeLimits = {
  minute: 'Minutos',
  hour: 'Horas',
  day: 'Dias',
  no_limit: 'Sem limite',
};
