import React from 'react';
import { CheckOutlined, CloseOutlined } from '@material-ui/icons';

import { themeStatus } from '../Strings';
import { getToken, getPlatformId } from '../../Services/Api';

const editorUrl = process.env.REACT_APP_EDITOR_URL;
const baseUrl = process.env.REACT_APP_API_URL;
const backUrl = `${window.location.origin}/site/themes`;

const handleTheme = id => {
  const jwt = getToken();
  const platformId = getPlatformId();

  return `${editorUrl}?type=demo&token=${jwt}&base_url=${baseUrl}/&back_url=${backUrl}&template_id=${id}&platform_id=${platformId}`;
};

export const themeIndexColumns = remove => [
  {
    name: 'title',
    label: 'Nome',
  },

  {
    name: 'status',
    label: 'Status',
    formatLabel: row => themeStatus[row.status],
    className: row => (row.status === 'active' ? 'color-green' : 'color-red'),
    icon: row => (row.status === 'active' ? <CheckOutlined /> : <CloseOutlined />),
  },
  {
    name: 'actions',
    data: [
      {
        label: 'Editar',
        onClick: row => window.open(handleTheme(row.id)),
      },
      {
        label: 'Remover',
        onClick: row => remove(row),
      },
    ],
  },
];
