export const presenceIndexColumns = remove => [
  {
    name: 'userFirstName',
    label: 'Participante',
  },
  {
    name: 'activityName',
    label: 'Atividade',
  },
  {
    name: 'eventName',
    label: 'Evento',
  },
  {
    name: 'actions',
    data: [
      {
        label: 'Remover',
        onClick: row => remove(row),
      },
    ],
  },
];
