export const staffIndexColumns = remove => [
  {
    name: 'firstName',
    label: 'Nome',
  },
  {
    name: 'lastName',
    label: 'Sobrenome',
  },
  {
    name: 'presencesCount',
    label: 'Presenças realizadas',
  },
  {
    name: 'actions',
    data: [
      {
        label: 'Visualizar',
        onClick: row => window.location.replace(`/organizing/events/${row.id}`),
      },
      {
        label: 'Editar',
        onClick: row => window.location.replace(`/organizing/events/${row.id}/edit`),
      },
      {
        label: 'Remover',
        onClick: row => remove(row),
      },
    ],
  },
];
