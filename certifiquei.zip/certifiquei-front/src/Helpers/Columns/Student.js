import React from 'react';
import format from 'date-fns/format';
import { Grid, Link } from '@material-ui/core';
import Fingerprint from '@material-ui/icons/FingerprintOutlined';

export const studentIndexColumns = remove => [
  {
    name: 'firstName',
    label: 'Nome',
  },
  {
    name: 'lastName',
    label: 'Sobrenome',
  },
  {
    name: 'email',
    label: 'E-mail',
  },
  {
    name: 'eventName',
    label: 'Evento',
    formatLabel: row => row.eventName,
  },
  {
    name: 'presencesCount',
    label: 'Presenças',
  },
  {
    name: 'createdAt',
    label: 'Criado em',
    formatLabel: row => format(new Date(row.createdAt), 'dd/MM/yyyy'),
  },
  {
    name: 'qr',
    label: 'QR Code',
    formatLabel: row => (
      <Link
        href={`https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${row.userId}`}
        target="_blank"
        rel="noopener noreferrer"
      >
        <Grid className="Padding-1">
          <Fingerprint />
        </Grid>
      </Link>
    ),
  },
  {
    name: 'actions',
    data: [
      {
        label: 'Visualizar',
        onClick: row => window.location.replace(`/organizing/students/${row.id}`),
      },
      {
        label: 'Editar',
        onClick: row => window.location.replace(`/organizing/students/${row.id}/edit`),
      },
      {
        label: 'Remover',
        onClick: row => remove(row),
      },
    ],
  },
];
