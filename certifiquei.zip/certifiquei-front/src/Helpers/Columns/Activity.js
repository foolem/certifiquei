import React from 'react';
import { Grid, Link } from '@material-ui/core';
import AddAPhotoOutlinedIcon from '@material-ui/icons/AddAPhotoOutlined';

export const activityIndexColumns = (remove, checkIn, showEvent) =>
  [
    {
      name: 'title',
      label: 'Nome',
      formatLabel: row => <Link href={`/organizing/activities/${row.id}`}>{row.title}</Link>,
    },
    {
      name: 'description',
      label: 'Descrição',
    },
    {
      name: 'presencesCount',
      label: 'Presenças',
    },
    showEvent
      ? {
          name: 'eventName',
          label: 'Evento',
        }
      : null,
    {
      name: 'presence',
      label: 'Check-in',
      formatLabel: row => (
        <Link onClick={() => checkIn(row)}>
          <Grid className="Padding-1">
            <AddAPhotoOutlinedIcon />
          </Grid>
        </Link>
      ),
    },
    {
      name: 'actions',
      data: [
        {
          label: 'Check-in',
          onClick: row => checkIn(row),
        },
        {
          label: 'Visualizar',
          onClick: row => window.location.replace(`/organizing/activities/${row.id}`),
        },
        {
          label: 'Editar',
          onClick: row => window.location.replace(`/organizing/activities/${row.id}/edit`),
        },
        {
          label: 'Remover',
          onClick: row => remove(row),
        },
      ],
    },
  ].filter(item => !!item);
