import React from 'react';
import { Link } from '@material-ui/core';

import { eventStatus } from '../Strings';

export const eventIndexColumns = remove => [
  {
    name: 'title',
    label: 'Nome',
    formatLabel: row => <Link href={`/organizing/events/${row.id}`}>{row.title}</Link>,
  },
  {
    name: 'studentsCount',
    label: 'Participantes',
  },
  {
    name: 'link',
    label: 'Link de cadastro',
    formatLabel: row => (
      <Link href={`/events/${row.id}/signup`} target="_blank" rel="noopener noreferrer">
        Link
      </Link>
    ),
  },
  {
    name: 'status',
    label: 'Status',
    formatLabel: row => eventStatus[row.status],
  },
  {
    name: 'actions',
    data: [
      {
        label: 'Visualizar',
        onClick: row => window.location.replace(`/organizing/events/${row.id}`),
      },
      {
        label: 'Editar',
        onClick: row => window.location.replace(`/organizing/events/${row.id}/edit`),
      },
      {
        label: 'Remover',
        onClick: row => remove(row),
      },
    ],
  },
];
