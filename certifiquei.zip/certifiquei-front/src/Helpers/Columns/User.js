import { roleNames } from '../Strings';

export const userIndexColumns = remove => [
  {
    name: 'firstName',
    label: 'Nome',
  },
  {
    name: 'lastName',
    label: 'Sobrenome',
  },
  {
    name: 'email',
    label: 'E-mail',
  },
  {
    name: 'userRoles',
    label: 'Funções',
    formatLabel: row => row.userRoles.map(item => roleNames[item.name]).join(', ') || 'N/A',
  },
  {
    name: 'actions',
    data: [
      {
        label: 'Editar',
        onClick: row => window.location.replace(`/users/profiles/${row.id}/edit`),
      },
      {
        label: 'Remover',
        onClick: row => remove(row),
      },
    ],
  },
];
