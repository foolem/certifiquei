export const waitlistIndexColumns = remove => [
  {
    name: 'name',
    label: 'Nome',
  },
  {
    name: 'email',
    label: 'E-mail',
  },
  {
    name: 'phone',
    label: 'Telefone',
  },
  {
    name: 'eventName',
    label: 'Evento',
  },
  {
    name: 'actions',
    data: [
      {
        label: 'Remover',
        onClick: row => remove(row),
      },
    ],
  },
];
