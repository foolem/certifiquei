import format from 'date-fns/format';

import { eventStatus } from '../Strings';

import { toMoney } from '../Currency';

export const salesColumns = () => [
  {
    name: 'title',
    label: 'Produto',
  },
  {
    name: 'averageTicket',
    label: 'Ticket médio',
    formatLabel: (row) => toMoney(row.averageTicket),
  },
  {
    name: 'total',
    label: 'Total vendido',
    formatLabel: (row) => toMoney(row.total),
  },
  {
    name: 'totalRefunded',
    label: 'Total reembolsado',
    formatLabel: (row) => toMoney(row.totalRefunded),
  },
  {
    name: 'createdAt',
    label: 'Data',
    formatLabel: (row) => format(new Date(row.createdAt), 'dd/MM/yyyy'),
  },
  {
    name: 'status',
    label: 'Status',
    formatLabel: (row) => eventStatus[row.status],
  },
];
