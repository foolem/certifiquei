import React from 'react';
import { Link } from '@material-ui/core';

export const studentCertificateIndexColumns = () => [
  {
    name: 'userFirstName',
    label: 'Nome',
    formatLabel: row => row.user.firstName,
  },
  {
    name: 'userLastName',
    label: 'Sobrenome',
    formatLabel: row => row.user.lastName,
  },
  {
    name: 'userEmail',
    label: 'E-mail',
    formatLabel: row => row.user.email,
  },
  {
    name: 'eventTitle',
    label: 'Evento',
    formatLabel: row => row.event.title,
  },
  {
    name: 'resourceUrl',
    label: 'Link',
    formatLabel: row => (
      <Link href={row.resourceUrl} target="_blank" rel="noopener noreferrer">
        Visualizar
      </Link>
    ),
  },
];
