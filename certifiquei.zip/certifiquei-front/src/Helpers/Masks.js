import React from 'react';
import MaskedInput from 'react-text-mask';

const grrMask = ['G', 'R', 'R', /./, /./, /./, /./, /./, /./, /./, /./];

const workloadMask = [/[0-9]/, /[0-9]/, ':', /[0-9]/, /[0-9]/];

const dateMask = [/[0-9]/, /[0-9]/, '/', /[0-9]/, /[0-9]/, '/', /[0-9]/, /[0-9]/, /[0-9]/, /[0-9]/];

const dateTimeMask = [
  /[0-9]/,
  /[0-9]/,
  '/',
  /[0-9]/,
  /[0-9]/,
  '/',
  /[0-9]/,
  /[0-9]/,
  /[0-9]/,
  /[0-9]/,
  ' - ',
  /[0-9]/,
  /[0-9]/,
  ':',
  /[0-9]/,
  /[0-9]/,
];

const timeMask = [
  /[0-9]/,
  /[0-9]/,
  ':',
  /[0-9]/,
  /[0-9]/,
  ' - ',
  /[0-9]/,
  /[0-9]/,
  ':',
  /[0-9]/,
  /[0-9]/,
];

const Input = (props, mask) => {
  const { inputRef, ...other } = props;
  return (
    <MaskedInput
      {...other}
      ref={ref => {
        inputRef(ref ? ref.inputElement : null);
      }}
      mask={mask}
      guide={false}
      placeholderChar={'\u2000'}
      showMask
    />
  );
};

export const GRRMask = props => Input(props, grrMask);

export const WorkloadMask = props => Input(props, workloadMask);

export const DateMask = props => Input(props, dateMask);

export const DateTimeMask = props => Input(props, dateTimeMask);

export const TimeMask = props => Input(props, timeMask);
