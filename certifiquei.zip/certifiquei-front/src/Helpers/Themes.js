import Images from '../Themes/Images';

export default [
  { title: 'Básico para negócios', preview: Images.themes.demo, type: 'demo' },
  { title: 'Básico para universidade', preview: Images.themes.fluid, type: 'fluid' },
  { title: 'Básico para serviços', preview: Images.themes.minimal, type: 'minimal' },
];
