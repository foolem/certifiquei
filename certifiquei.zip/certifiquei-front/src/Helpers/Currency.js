const deCurrency = value => {
  if (Number.isInteger(value)) return value * 100;

  return (
    [
      ...value
        .replace('$', '')
        .replace(/\+/g, '')
        .replace(/-/g, '')
        .replace(/,/g, '')
        .replace(/\./g, '')
        .split(''),
    ].join('') * 100
  );
};

const toReal = cents => cents / 100;

const toCurrency = number => {
  const parsedNumber = Number.isNaN(parseFloat(number)) ? 0 : number;

  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(
    parsedNumber,
  );
};

const toMoney = cents => {
  return toCurrency(toReal(cents));
};

const toValue = number => {
  return new Intl.NumberFormat('pt-BR').format(number);
};

export { toCurrency, deCurrency, toReal, toMoney, toValue };
