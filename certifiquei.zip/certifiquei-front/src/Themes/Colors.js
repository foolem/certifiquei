const colors = {
  transparent: 'transparent',
  white: '#FFFFFF',
  gray: '#828691',
  lightGray: '#FAFAFE',
  strongerGray: '#F0F0F7',
  navGray: '#A8A8A8',
  borderGray: 'rgba(0, 0, 0, 0.12)',
  smoothText: 'rgba(#060606, 0.35)',
  text: '#111111',
  primaryBlue: '#3F2F5B',
  primaryTextBlue: '#496CAD',
  primaryTextBlack: '#48484C',
  yellow: '#EAA93A',
  green: '#17D373',
  blue: '#2D2D5F',
  red: '#D12525',
};

export default colors;
