const metrics = {
  defaults: {
    margin: "1em",
    marginBigger: "2em",
    marginLittle: ".5em",
    marginBiggest: "3em",
    padding: "1em",
    paddingBigger: "2em",
    paddingBiggest: "3em",
    paddingLittle: ".5em",
  },
  body: {
    padding: "1em 3em 0 20em",
    maxWidth: "1366px",
  },
  drawer: {
    width: "17rem",
    paddingTop: "2em",
  },
  pagination: {
    padding: ".7em",
    height: "100%",
  },
  verticalStep: {
    width: "1em",
    height: "1em",
    padding: ".3em",
  },
  horizontalStep: {
    littleLineWidth: "1em",
    bottom: "38px",
    width: "10px",
    height: "10px",
  },
  popover: {
    width: "30em !important",
    widthLittle: "10em !important",
    minHeight: "3em",
  },
  button: {
    padding: ".8em 3em !important",
    paddingLittle: ".8em 1em !important",
    paddingTiny: ".5em 1em !important",
  },
  icons: {
    help: {
      width: "15px",
      height: "15px",
    },
  },
  dialog: {
    horizontalPadding: "24px",
    actions: {
      padding: "8px 24px",
    },
  },
  csvCard: {
    minWidth: "18em",
  },
};

export default metrics;
