import { createGlobalStyle } from 'styled-components';
import Colors from './Colors';
import Metrics from './Metrics';
import Fonts from './Fonts';

const GlobalStyle = createGlobalStyle`
    body, html {
        height: 100%;
        font-family: 'Roboto', sans-serif !important;
        margin: 0;
        -webkit-font-smoothing: antialiased;
    }

    font: 14px 'Roboto', sans-serif;

    *:focus {
        outline: 0;
    }

    a {
        text-decoration: underline;
        color: ${Colors.blue} !important;
        font-weight: bold !important;
        &:hover {
          cursor: pointer
        }
    }

    .No-underline {
      text-decoration: none !important;
    }

    .MuiTypography-colorError {
      color: ${Colors.red} !important;
    }

    .MuiLink-underlineNone {
      text-decoration: none !important;
    }

    ul {
        list-style: none;
    }

    .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline {
      border-color: ${Colors.primaryBlue} !important;
    }

    .MuiDivider-root {
      margin-top: ${Metrics.defaults.margin} !important;
      margin-bottom: ${Metrics.defaults.margin} !important;
      color: ${Colors.borderGray};
    }

    .MuiInputBase-input {
      background: ${Colors.white} !important
    }

    .MuiTypography-root {
      font-family: "Roboto", sans-serif !important;
      strong {
        color: ${Colors.primaryBlue}
      }
    }

    .MuiTypography-h5 {
      color: ${Colors.text};
      font-weight: 600 !important;
    }

    .MuiTypography-h6 {
      color: ${Colors.text};
      font-weight: 600 !important;
    }

    .MuiTypography-colorPrimary {
      color: ${Colors.blue} !important;
    }

    .MuiTypography-body1 {
      font-size: 0.8em !important;
    }

    .MuiTypography-body2 {
      font-size: 0.7em !important;
    }

    .MuiTypography-caption {
      font-size: 0.7em !important;
      i {
        color: ${Colors.primaryBlue};
        font-size: 1em !important;
      }
    }

    .MuiLink-root {
      font-size: ${Fonts.link};
      text-decoration: underline;
    }

    .MuiTableCell-head {
      border-bottom: 0 !important;
      color: ${Colors.blue} !important;
      text-transform: uppercase;
      letter-spacing: .1em !important;
    }

    .MuiInputLabel-root {
      margin-bottom: ${Metrics.defaults.paddingLittle} !important;
      font-weight: 600 !important;
      color: ${Colors.text} !important;
      font-size: .8em !important;
    }

    .Error-Icon {
      font-size: 1em !important;
      margin-right: ${Metrics.defaults.marginLittle};
      fill: ${Colors.blue} !important
    }

    .MuiDialog-paper {
      padding: ${Metrics.defaults.paddingBigger}
    }

    .MuiTableCell-body {
      border: 0 !important;
    }

    tbody tr:nth-child(odd) {
      background-color: ${Colors.lightGray} !important;
    }

    .Toastify__toast {
      border-radius: 4px !important;
    }

    .Drawer {
      transition: all ease-in-out;
      div {
        transition: all ease-in-out;
        white-space: nowrap;
        flex-shrink: initial;
        border-right: 0;
      }
    }

    .Drawer-mobile {
      div {
        width: 3rem !important;
      }
    }

    .MuiCircularProgress-colorPrimary {
      color: ${Colors.primaryBlue} !important;
    }

    .color-black {
      color: black !important;
    }

    .color-green {
      color: ${Colors.green} !important;
    }

    .color-red {
      color: ${Colors.red} !important;
    }

    .color-white {
      color: ${Colors.white} !important;
    }

    .size-1em {
      width: 1em !important;
      height: 1em !important;
    }

    .Abs-right {
      z-index: 999;
      position: absolute;
      right: 1em;
      top: 1em;
    }
    
    .Placeholder {
      width: 5em;
      height: 5em;
      border-radius: 5px;
    }

    .MuiCard-root {
      box-sizing: border-box;
      border: 1px solid #EEF0F4!important;
      border-radius: 0px!important;
    }

    .MuiPaper-elevation1 {
      box-shadow: none!important;
    }

    .No-right-radius {
      .MuiOutlinedInput-root {
        border-top-right-radius: 0 !important;
        border-bottom-right-radius: 0 !important;
      }
    }

    h5 {
      color: ${Colors.primaryBlue} !important;
    }

    .qr-code {
      width: 15em;
      height: 15em;
      object-fit: cover;
      margin: 1.5em;
    }

    ${genCommonClasses()}
    
`;

function genCommonClasses() {
  let styles = ``;
  for (let i = 0; i < 4; i++) {
    let metric =
      i === 0
        ? Metrics.defaults.paddingLittle
        : i === 1
        ? Metrics.defaults.padding
        : i === 2
        ? Metrics.defaults.paddingBigger
        : Metrics.defaults.paddingBiggest;

    styles += `
      .Padding-${i} {
        padding: ${metric} !important;
      }
      .Padding-t-${i} {
        padding-top: ${metric} !important;
      }
      .Padding-b-${i} {
        padding-bottom: ${metric} !important;
      }
      .Padding-r-${i} {
        padding-right: ${metric} !important;
      }
      .Padding-l-${i} {
        padding-left: ${metric} !important;
      }

      .Margin-${i} {
        margin: ${metric} !important;
      }
      .Margin-t-${i} {
        margin-top: ${metric} !important;
      }
      .Margin-b-${i} {
        margin-bottom: ${metric} !important;
      }
      .Margin-r-${i} {
        margin-right: ${metric} !important;
      }
      .Margin-l-${i} {
        margin-left: ${metric} !important;
      }
    `;
  }

  styles += `
    .D-flex {
      display: flex !important;
    }
    .Justify-end {
      justify-content: flex-end !important;
    }
    .No-decoration {
      text-decoration: unset !important
    }
    .Subroute {
      margin-left: 1.5em !important
    }
    .Hidden {
      display: none
    }
    .Hidden-xs {
      display: flex;
    }
    .Inner-Table {
      padding-left: 2em;
      width: auto !important;
    }
    .Home-icon {
      width: 3em;
    }

    @media screen (max-width: 900px) {
      .Hidden-xs {
        display: none
      }
    }
  `;

  return styles;
}

export default GlobalStyle;
