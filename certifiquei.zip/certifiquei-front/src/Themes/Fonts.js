const fonts = {
  title: '24px',
  link: '14px',
};

export default fonts;
