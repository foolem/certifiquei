import loginEd from '../Assets/Images/login_ed.png';
import placeholder from '../Assets/Images/placeholder.png';

import demo from '../Assets/Images/template-demo.png';
import fluid from '../Assets/Images/template-fluid.png';
import minimal from '../Assets/Images/template-minimal.png';

import home from '../Assets/Icons/home.svg';
import organizing from '../Assets/Icons/education.svg';
import blog from '../Assets/Icons/blog.svg';
import financial from '../Assets/Icons/financial.svg';
import profile from '../Assets/Icons/profile.svg';
import settings from '../Assets/Icons/settings.svg';

import sale from '../Assets/Icons/sale.svg';
import piggy from '../Assets/Icons/piggy-bank.svg';
import trolley from '../Assets/Icons/trolley.svg';
import calculator from '../Assets/Icons/calculator.svg';
import www from '../Assets/Icons/www.svg';
import school from '../Assets/Icons/school.svg';
import certificate from '../Assets/Icons/certificate.svg';
import hired from '../Assets/Icons/hired.svg';
import resume from '../Assets/Icons/resume.svg';
import checkList from '../Assets/Icons/check-list.svg';
import videoConference from '../Assets/Icons/video-conference.svg';
import videoConference1 from '../Assets/Icons/video-conference-1.svg';

const images = {
  placeholder,
  icons: {
    home,
    organizing,
    blog,
    financial,
    profile,
    settings,
    sale,
    piggy,
    trolley,
    calculator,
    www,
    school,
    certificate,
    hired,
    resume,
    checkList,
    videoConference,
    videoConference1,
  },
  images: {
    loginEd,
  },
  themes: {
    demo,
    fluid,
    minimal,
  },
};

export default images;
