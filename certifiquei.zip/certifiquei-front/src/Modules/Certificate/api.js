import api from '../../Services/Api';

export const getCertificates = params => api.get('certificates', params);
export const getTemplates = params => api.get('certificate-templates', params);
export const createCertificate = params => api.post('certificates', params);

export const getTemplate = id => api.get(`certificate-templates/${id}`);
export const getNewCertificate = id => api.get(`certificates/${id}`);
export const postCertificate = params => api.post('certificates', params);
export const putCertificate = params => api.put(`certificates/${params.id}`, params);
export const deleteCertificate = id => api.delete(`certificates/${id}`);
export const duplicateCertificate = id => api.post(`certificates/${id}/duplicate`);
export const postValidate = params => api.post('certificates/validate', params);
