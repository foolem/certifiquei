/* eslint-disable no-return-assign */
import { createReducer, createActions } from 'reduxsauce';
import produce from 'immer';

/* ------------- Types and Action Creators ------------- */

const { Types, Creators } = createActions(
  {
    enableComponent: ['id'],
    enableDivider: ['id'],
    setBackground: ['image'],
    setSign: ['id', 'image'],
    resetCertificate: ['data'],
    changePosition: ['data'],
    changePositionSign: ['data'],
    viewCertificate: ['data'],
    closeView: ['data'],
    sendBackWidth: ['data'],
    sendDragWidth: ['data'],
    centerComponents: ['data'],
    changeText: ['event', 'field', 'id', 'text'],

    certificatesRequest: ['data'],
    certificatesSuccess: ['data', 'pagination'],
    certificatesFailure: ['data'],

    templatesRequest: ['data'],
    templatesSuccess: ['data', 'pagination'],
    templatesFailure: ['data'],

    createCertificateRequest: ['data'],
    createCertificateSuccess: ['data'],
    createCertificateFailure: null,

    editCertificateRequest: ['data'],
    editCertificateSuccess: ['data'],
    editCertificateFailure: null,

    removeCertificateRequest: ['id'],
    removeCertificateSuccess: ['data'],
    removeCertificateFailure: null,

    duplicateCertificateRequest: ['id'],
    duplicateCertificateSuccess: ['data'],
    duplicateCertificateFailure: null,

    templateRequest: ['id'],
    templateSuccess: ['data'],
    templateFailure: null,

    certificateRequest: ['id'],
    certificateSuccess: ['data'],
    certificateFailure: null,

    validateCertificateRequest: ['data'],
    validateCertificateSuccess: ['data'],
    validateCertificateFailure: null,

    setNewCertificate: ['data'],

    setMeta: ['data'],
  },
  { prefix: 'CERTIFICATE/' },
);

export const CertificateTypes = Types;
export default Creators;

/* ------------- Initial State ------------- */

const INITIAL_STATE = {
  certificates: [],
  templates: [],
  loading: false,
  saving: false,
  newCertificate: {},
  validCertificate: null,
  meta: {
    page: 1,
    pageCount: 0,
    total: 0,
  },
};

/* ------------- Selectors ------------- */

export const CertificateSelectors = {
  getCertificates: state => state.certificate.certificates,
  getTemplates: state => state.certificate.templates,
  getNewCertificate: state => state.certificate.newCertificate,
  getValidCertificate: state => state.certificate.validCertificate,
  getLoading: state => state.certificate.loading,
  getSaving: state => state.certificate.saving,
  getMeta: state => state.certificate.meta,
};

/* ------------- Reducers ------------- */

const loading = state =>
  produce(state, draft => {
    draft.loading = true;
  });

const error = state =>
  produce(state, draft => {
    draft.loading = false;
    draft.validCertificate = null;
  });

const success = state =>
  produce(state, draft => {
    draft.loading = false;
  });

const certificatesSuccess = (state, { data, pagination }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.certificates = data;
    draft.meta.total = pagination.total;
    draft.meta.pageCount = pagination.page_count;
  });

const templatesSuccess = (state, { data, pagination }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.templates = data;
    draft.meta.total = pagination.total;
    draft.meta.pageCount = pagination.page_count;
  });

const createCertificateRequest = state =>
  produce(state, draft => {
    draft.saving = true;
  });

const createCertificateSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.saving = false;
    draft.certificates = [...state.certificates, data];
  });

const createCertificateFailure = state =>
  produce(state, draft => {
    draft.saving = false;
  });

const removeCertificateSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.certificates = state.certificates.filter(item => item.id !== data.id);
  });

const duplicateCertificateSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.certificates = [...state.certificates, { ...data }];
  });

const getTemplateSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.newCertificate = data.metadata;
    draft.template = data;
  });

export const setNewCertificate = (state, { data }) =>
  produce(state, draft => {
    draft.newCertificate = data;
  });

export const setMeta = (state, { data }) =>
  produce(state, draft => {
    draft.meta.page = data.page;
    draft.meta.limit = data.limit;
    draft.meta.title_i_cont = data.title_i_cont;
    draft.meta.pageCount = data.pageCount;
    draft.meta.total = data.total;
  });

const enableComponent = (state, { id }) =>
  produce(state, draft => {
    draft.newCertificate.fields.map(comp => {
      if (comp.id === id) {
        return (comp.open = !comp.open);
      }
      return comp;
    });
  });

const enableDivider = (state, { id }) =>
  produce(state, draft => {
    draft.newCertificate.fields.map(comp => {
      if (comp.id === id && !!comp.divider) {
        return (comp.divider.open = !comp.divider.open);
      }
      return comp;
    });
  });

const setBackground = (state, { image }) =>
  produce(state, draft => {
    draft.newCertificate.background = image;
  });

const setSign = (state, { id, image }) =>
  produce(state, draft => {
    draft.newCertificate.fields.map(item => {
      if (item.id === id) {
        item.img = image;
      }
    });
  });

const resetCertificate = () => INITIAL_STATE;

const changePosition = (state, { id, position }) =>
  produce(state, draft => {
    draft.newCertificate.fields.map(comp => {
      if (comp.id === id) {
        return (comp.position = position);
      }
      return comp;
    });
  });

const changePositionSign = (state, { id, position }) =>
  produce(state, draft => {
    draft.newCertificate.fields.map(comp => {
      if (comp.id === id) {
        return (comp.position = position);
      }
      return comp;
    });
  });

const viewCertificate = state =>
  produce(state, draft => {
    draft.view = state.fields.map(comp => {
      comp.value = comp.value.replace('[NOME_DO_CURSO]', 'Curso Digital Avançado');
      comp.value = comp.value.replace('[DATA_DA_EMISSAO]', '10/12/2019');
      comp.value = comp.value.replace('[NOME_DO_ALUNO]', 'Alberto Santos Dumont');
      comp.value = comp.value.replace('[INSERIR_CARGA_HORARIA]', '50 horas');
      comp.value = comp.value.replace('[DATA_DE_INICIO]', '01/01/2019');
      comp.value = comp.value.replace('[DATA_DE_TERMINO]', '01/06/2019');
      comp.value = comp.value.replace('[NOME_DO_RESPONSAVEL]', 'Isaac Newton');
      comp.value = comp.value.replace('[RESPONSAVEL_01]', 'Isaac Newton');
      comp.value = comp.value.replace('[RESPONSAVEL_02]', 'James Joule');
    });
    draft.modalView = true;
  });

const closeView = state =>
  produce(state, draft => {
    draft.modalView = false;
  });

const sendBackWidth = (state, { backWidth }) =>
  produce(state, draft => {
    draft.newCertificate.backgroundWidth = Math.round(backWidth);
  });

const sendDragWidth = (state, { width, idDrag }) =>
  produce(state, draft => {
    draft.newCertificate.fields.map(item => {
      if (idDrag === item.id) {
        if (idDrag === 5)
          return (item.widthCenter =
            (Math.round(draft.backgroundWidth) - Math.round(width)) / 2 - 120);
        if (idDrag === 6)
          return (item.widthCenter =
            (Math.round(draft.backgroundWidth) - Math.round(width)) / 2 + 120);
        return (item.widthCenter = (Math.round(draft.backgroundWidth) - Math.round(width)) / 2);
      }
      return item;
    });
  });

const centerComponents = state =>
  produce(state, draft => {
    draft.newCertificate.fields.map(item => {
      return (item.position.x = item.widthCenter);
    });
  });

const changeText = (state, { event, field, id }) =>
  produce(state, draft => {
    draft.newCertificate.fields.map(item => {
      if (item.id === id) {
        item[field] = event;
      }
      return item;
    });
  });

const validateCertificateSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.validCertificate = data;
  });

/* ------------- Hookup Reducers To Types ------------- */

export const reducer = createReducer(INITIAL_STATE, {
  [Types.ENABLE_COMPONENT]: enableComponent,
  [Types.ENABLE_DIVIDER]: enableDivider,
  [Types.SET_BACKGROUND]: setBackground,
  [Types.SET_SIGN]: setSign,
  [Types.RESET_CERTIFICATE]: resetCertificate,
  [Types.CHANGE_POSITION]: changePosition,
  [Types.CHANGE_POSITION_SIGN]: changePositionSign,
  [Types.VIEW_CERTIFICATE]: viewCertificate,
  [Types.CLOSE_VIEW]: closeView,
  [Types.SEND_BACK_WIDTH]: sendBackWidth,
  [Types.SEND_DRAG_WIDTH]: sendDragWidth,
  [Types.CENTER_COMPONENTS]: centerComponents,
  [Types.CHANGE_TEXT]: changeText,

  [Types.CERTIFICATES_REQUEST]: loading,
  [Types.CERTIFICATES_SUCCESS]: certificatesSuccess,
  [Types.CERTIFICATES_FAILURE]: error,

  [Types.TEMPLATES_REQUEST]: loading,
  [Types.TEMPLATES_SUCCESS]: templatesSuccess,
  [Types.TEMPLATES_FAILURE]: error,

  [Types.CREATE_CERTIFICATE_REQUEST]: createCertificateRequest,
  [Types.CREATE_CERTIFICATE_SUCCESS]: createCertificateSuccess,
  [Types.CREATE_CERTIFICATE_FAILURE]: createCertificateFailure,

  [Types.TEMPLATE_REQUEST]: loading,
  [Types.TEMPLATE_SUCCESS]: getTemplateSuccess,
  [Types.TEMPLATE_FAILURE]: error,

  [Types.CERTIFICATE_REQUEST]: loading,
  [Types.CERTIFICATE_SUCCESS]: getTemplateSuccess,
  [Types.CERTIFICATE_FAILURE]: error,

  [Types.EDIT_CERTIFICATE_REQUEST]: loading,
  [Types.EDIT_CERTIFICATE_SUCCESS]: success,
  [Types.EDIT_CERTIFICATE_FAILURE]: error,

  [Types.REMOVE_CERTIFICATE_REQUEST]: loading,
  [Types.REMOVE_CERTIFICATE_SUCCESS]: removeCertificateSuccess,
  [Types.REMOVE_CERTIFICATE_FAILURE]: error,

  [Types.DUPLICATE_CERTIFICATE_REQUEST]: loading,
  [Types.DUPLICATE_CERTIFICATE_SUCCESS]: duplicateCertificateSuccess,
  [Types.DUPLICATE_CERTIFICATE_FAILURE]: error,

  [Types.VALIDATE_CERTIFICATE_REQUEST]: loading,
  [Types.VALIDATE_CERTIFICATE_SUCCESS]: validateCertificateSuccess,
  [Types.VALIDATE_CERTIFICATE_FAILURE]: error,

  [Types.SET_NEW_CERTIFICATE]: setNewCertificate,

  [Types.SET_META]: setMeta,
});
