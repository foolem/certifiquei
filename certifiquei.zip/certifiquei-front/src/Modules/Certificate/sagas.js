import { takeLatest, call, put, all, select } from 'redux-saga/effects';
import { toast } from 'react-toastify';
import * as api from './api';
import CertificateActions, { CertificateSelectors } from '.';

export function* certificates() {
  const meta = yield select(CertificateSelectors.getMeta);

  const response = yield call(api.getCertificates, meta);
  if (response.ok) {
    yield put(CertificateActions.certificatesSuccess(response.data, response.pagination));
  } else {
    yield put(CertificateActions.certificatesFailure(response.data));
  }
}

export function* templates() {
  const meta = yield select(CertificateSelectors.getMeta);

  const response = yield call(api.getTemplates, meta);
  if (response.ok) {
    yield put(CertificateActions.templatesSuccess(response.data, response.pagination));
  } else {
    yield put(CertificateActions.templatesFailure(response.data));
  }
}

export function* template({ id }) {
  const response = yield call(api.getTemplate, id);
  if (response.ok) {
    yield put(CertificateActions.templateSuccess(response.data));
  } else {
    yield put(CertificateActions.templateFailure());
  }
}

export function* certificate({ id }) {
  const response = yield call(api.getNewCertificate, id);
  if (response.ok) {
    yield put(CertificateActions.certificateSuccess(response.data));
  } else {
    yield put(CertificateActions.certificateFailure());
  }
}

export function* createCertificate({ data }) {
  const response = yield call(api.postCertificate, data);
  if (response.ok) {
    toast.success('Certificado adicionado com sucesso');
    yield put(CertificateActions.createCertificateSuccess(response.data));
    window.location.replace('/organizing/certificates');
  } else {
    toast.error(response.data);

    yield put(CertificateActions.createCertificateFailure());
  }
}

export function* editCertificate({ data }) {
  const response = yield call(api.putCertificate, data);
  if (response.ok) {
    toast.success('Certificado editado com sucesso');
    yield put(CertificateActions.editCertificateSuccess());
  } else {
    toast.error(response.data);

    yield put(CertificateActions.editCertificateFailure());
  }
}

export function* removeCertificate({ id }) {
  const response = yield call(api.deleteCertificate, id);
  if (response.ok) {
    toast.success('Certificado deletado com sucesso');
    yield put(CertificateActions.removeCertificateSuccess(response.data));
  } else {
    toast.error(response.data);

    yield put(CertificateActions.removeCertificateFailure());
  }
}

export function* duplicateCertificate({ id }) {
  const response = yield call(api.duplicateCertificate, id);
  if (response.ok) {
    toast.success('Certificado duplicado com sucesso');
    yield put(CertificateActions.duplicateCertificateSuccess(response.data));
  } else {
    toast.error(response.data);
    yield put(CertificateActions.duplicateCertificateFailure());
  }
}

export function* validate({ data }) {
  const response = yield call(api.postValidate, data);
  if (response.ok) {
    toast.success('Este certificado é válido');
    yield put(CertificateActions.validateCertificateSuccess(response.data));
  } else {
    toast.error('Este código não válido');

    yield put(CertificateActions.validateCertificateFailure());
  }
}

export default all([
  takeLatest('CERTIFICATE/CERTIFICATES_REQUEST', certificates),
  takeLatest('CERTIFICATE/TEMPLATES_REQUEST', templates),
  takeLatest('CERTIFICATE/TEMPLATE_REQUEST', template),
  takeLatest('CERTIFICATE/CERTIFICATE_REQUEST', certificate),
  takeLatest('CERTIFICATE/CREATE_CERTIFICATE_REQUEST', createCertificate),
  takeLatest('CERTIFICATE/EDIT_CERTIFICATE_REQUEST', editCertificate),
  takeLatest('CERTIFICATE/REMOVE_CERTIFICATE_REQUEST', removeCertificate),
  takeLatest('CERTIFICATE/DUPLICATE_CERTIFICATE_REQUEST', duplicateCertificate),
  takeLatest('CERTIFICATE/VALIDATE_CERTIFICATE_REQUEST', validate),
]);
