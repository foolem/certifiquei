import { createReducer, createActions } from 'reduxsauce';
import produce from 'immer';

/* ------------- Types and Action Creators ------------- */

const { Types, Creators } = createActions(
  {
    studentsRequest: ['data'],
    studentsSuccess: ['data', 'pagination'],
    studentsFailure: ['data'],

    allStudentsRequest: ['data'],
    allStudentsSuccess: ['data', 'pagination'],
    allStudentsFailure: ['data'],

    studentRequest: ['data'],
    studentSuccess: ['data'],
    studentFailure: ['data'],

    removeStudentRequest: ['data'],
    removeStudentSuccess: ['data'],
    removeStudentFailure: ['data'],

    createStudentRequest: ['data'],
    createStudentSuccess: ['data'],
    createStudentFailure: ['data'],

    editStudentRequest: ['data'],
    editStudentSuccess: ['data'],
    editStudentFailure: ['data'],

    setMeta: ['data'],

    setNewStudent: ['data'],
  },
  { prefix: 'STUDENT/' },
);

export const StudentTypes = Types;
export default Creators;

/* ------------- Initial State ------------- */

const INITIAL_STATE = {
  allStudents: [],
  data: [],
  loading: false,
  student: {},
  newStudent: {
    step: 0,
    name: '',
    active: true,
  },
  meta: {
    page: 1,
    pageCount: 0,
    total: 0,
    event_id_in: [],
    active_in: [],
  },
};

/* ------------- Selectors ------------- */

export const StudentSelectors = {
  getNewStudent: state => state.student.newStudent,
  getStudent: state => state.student.student,
  getAllStudents: state => state.student.allStudents,
  getStudents: state => state.student.data,
  getLoading: state => state.student.loading,
  getMeta: state => state.student.meta,
};

/* ------------- Reducers ------------- */

const loading = state =>
  produce(state, draft => {
    draft.loading = true;
  });

const error = state =>
  produce(state, draft => {
    draft.loading = false;
  });

const studentsSuccess = (state, { data, pagination }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = data;
    draft.meta.total = pagination.total;
    draft.meta.pageCount = pagination.page_count;
  });

const allStudentsSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.allStudents = data;
  });

const studentSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.student = data;
  });

const removeStudentSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = state.data.filter(item => item.id !== data.id);
  });

const createStudentSuccess = state =>
  produce(state, draft => {
    draft.loading = false;
    draft.newStudent.step = state.newStudent.step + 1;
  });

const editStudentSuccess = state =>
  produce(state, draft => {
    draft.loading = false;
    draft.newStudent.step = state.newStudent.step + 1;
  });

export const setMeta = (state, { data }) =>
  produce(state, draft => {
    draft.meta.page = data.page;
    draft.meta.limit = data.limit;
    draft.meta.user_first_name_i_cont = data.user_first_name_i_cont;
    draft.meta.active_in = data.active_in;
    draft.meta.event_id_in = data.event_id_in;
    draft.meta.pageCount = data.pageCount;
    draft.meta.total = data.total;
  });

export const setNewStudent = (state, { data }) =>
  produce(state, draft => {
    draft.newStudent = data;
  });

/* ------------- Hookup Reducers To Types ------------- */

export const reducer = createReducer(INITIAL_STATE, {
  [Types.STUDENTS_REQUEST]: loading,
  [Types.STUDENTS_SUCCESS]: studentsSuccess,
  [Types.STUDENTS_FAILURE]: error,

  [Types.ALL_STUDENTS_REQUEST]: loading,
  [Types.ALL_STUDENTS_SUCCESS]: allStudentsSuccess,
  [Types.ALL_STUDENTS_FAILURE]: error,

  [Types.STUDENT_REQUEST]: loading,
  [Types.STUDENT_SUCCESS]: studentSuccess,
  [Types.STUDENT_FAILURE]: error,

  [Types.REMOVE_STUDENT_REQUEST]: loading,
  [Types.REMOVE_STUDENT_SUCCESS]: removeStudentSuccess,
  [Types.REMOVE_STUDENT_FAILURE]: error,

  [Types.CREATE_STUDENT_REQUEST]: loading,
  [Types.CREATE_STUDENT_SUCCESS]: createStudentSuccess,
  [Types.CREATE_STUDENT_FAILURE]: error,

  [Types.EDIT_STUDENT_REQUEST]: loading,
  [Types.EDIT_STUDENT_SUCCESS]: editStudentSuccess,
  [Types.EDIT_STUDENT_FAILURE]: error,

  [Types.SET_META]: setMeta,

  [Types.SET_NEW_STUDENT]: setNewStudent,
});
