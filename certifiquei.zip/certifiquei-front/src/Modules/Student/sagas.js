import { takeLatest, call, put, all, select } from 'redux-saga/effects';
import { toast } from 'react-toastify';
import * as api from './api';
import StudentActions, { StudentSelectors } from '.';

export function* students() {
  const meta = yield select(StudentSelectors.getMeta);

  const response = yield call(api.getStudents, meta);
  if (response.ok) {
    yield put(StudentActions.studentsSuccess(response.data, response.pagination));
  } else {
    yield put(StudentActions.studentsFailure(response.data));
  }
}

export function* allStudents() {
  const meta = yield select(StudentSelectors.getMeta);

  const response = yield call(api.getAllStudents, meta);
  if (response.ok) {
    yield put(StudentActions.allStudentsSuccess(response.data, response.pagination));
  } else {
    yield put(StudentActions.allStudentsFailure(response.data));
  }
}

export function* student({ data }) {
  const response = yield call(api.getStudent, data);
  if (response.ok) {
    yield put(StudentActions.studentSuccess(response.data, response.pagination));
  } else {
    yield put(StudentActions.studentFailure(response.data));
  }
}

export function* removeStudent({ data }) {
  const response = yield call(api.removeStudent, data);
  if (response.ok) {
    yield put(StudentActions.removeStudentSuccess(response.data));
    toast.success('Participante removido com sucesso.');
  } else {
    yield put(StudentActions.removeStudentFailure(response.data));
    toast.error(response.data);
  }
}

export function* createStudent() {
  const newStudent = yield select(StudentSelectors.getNewStudent);

  const response = yield call(api.createStudent, newStudent);
  if (response.ok) {
    yield put(StudentActions.createStudentSuccess(response.data));
    toast.success('Participante criado com sucesso.');
  } else {
    yield put(StudentActions.createStudentFailure(response.data));
    toast.error(response.data);
  }
}

export function* editStudent() {
  const newStudent = yield select(StudentSelectors.getNewStudent);

  const response = yield call(api.editStudent, newStudent);
  if (response.ok) {
    yield put(StudentActions.editStudentSuccess(response.data));
    toast.success('Participante editado com sucesso.');
  } else {
    yield put(StudentActions.editStudentFailure(response.data));
    toast.error(response.data);
  }
}

export default all([
  takeLatest('STUDENT/ALL_STUDENTS_REQUEST', allStudents),
  takeLatest('STUDENT/STUDENTS_REQUEST', students),
  takeLatest('STUDENT/STUDENT_REQUEST', student),
  takeLatest('STUDENT/REMOVE_STUDENT_REQUEST', removeStudent),
  takeLatest('STUDENT/CREATE_STUDENT_REQUEST', createStudent),
  takeLatest('STUDENT/EDIT_STUDENT_REQUEST', editStudent),
]);
