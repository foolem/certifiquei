import api from '../../Services/Api';

export const getAllStudents = params => api.get('students/all', params);
export const getStudents = params => api.get('students', params);
export const getStudent = id => api.get(`students/${id}`);
export const editStudent = params =>
  api.put(`events/${params.eventId}/students/${params.id}`, params);
export const removeStudent = params => api.delete(`events/${params.eventId}/students/${params.id}`);
export const createStudent = params => api.post(`events/${params.eventId}/students`, params);
