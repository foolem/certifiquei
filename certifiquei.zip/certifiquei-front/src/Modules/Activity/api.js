import api from '../../Services/Api';

export const getAllActivities = params => api.get('activities/all', params);
export const getActivities = params => api.get('activities', params);
export const getActivity = id => api.get(`activities/${id}`);
export const editActivity = params => api.put(`activities/${params.id}`, params);
export const removeActivity = id => api.delete(`activities/${id}`);
export const createActivity = params => api.post(`activities`, params);
export const createPresence = (id, params) => api.post(`activities/${id}/presences`, params);
export const removePresence = params =>
  api.delete(`activities/${params.activityId}/presences/${params.id}`);
