import { createReducer, createActions } from 'reduxsauce';
import produce from 'immer';

/* ------------- Types and Action Creators ------------- */

const { Types, Creators } = createActions(
  {
    activitiesRequest: ['data'],
    activitiesSuccess: ['data', 'pagination'],
    activitiesFailure: ['data'],

    allActivitiesRequest: ['data'],
    allActivitiesSuccess: ['data', 'pagination'],
    allActivitiesFailure: ['data'],

    activityRequest: ['data'],
    activitySuccess: ['data'],
    activityFailure: ['data'],

    removeActivityRequest: ['data'],
    removeActivitySuccess: ['data'],
    removeActivityFailure: ['data'],

    createActivityRequest: ['data'],
    createActivitySuccess: ['data'],
    createActivityFailure: ['data'],

    editActivityRequest: ['data'],
    editActivitySuccess: ['data'],
    editActivityFailure: ['data'],

    createPresenceRequest: ['id', 'data'],
    createPresenceSuccess: ['data'],
    createPresenceFailure: ['data'],

    removePresenceRequest: ['data'],
    removePresenceSuccess: ['data'],
    removePresenceFailure: ['data'],

    setMeta: ['data'],

    setNewActivity: ['data'],

    togglePresenceNav: ['data'],
  },
  { prefix: 'ACTIVITY/' },
);

export const ActivityTypes = Types;
export default Creators;

/* ------------- Initial State ------------- */

const INITIAL_STATE = {
  allActivities: [],
  data: [],
  loading: false,
  uploading: false,
  activity: {},
  activityTests: [],
  newActivity: {
    step: 0,
    title: '',
    description: '',
    workload: '01:00',
  },
  meta: {
    page: 1,
    pageCount: 0,
    total: 0,
    event_id_eq: '',
    event_id_in: [],
  },
  presence: {
    open: false,
    loading: false,
    data: {},
  },
};

/* ------------- Selectors ------------- */

export const ActivitySelectors = {
  getNewActivity: state => state.activity.newActivity,
  getActivity: state => state.activity.activity,
  getActivities: state => state.activity.data,
  getAllActivities: state => state.activity.allActivities,
  getLoading: state => state.activity.loading,
  getMeta: state => state.activity.meta,
  getPresence: state => state.activity.presence,
};

/* ------------- Reducers ------------- */

const loading = state =>
  produce(state, draft => {
    draft.loading = true;
  });

const error = state =>
  produce(state, draft => {
    draft.loading = false;
  });

const loadingPresence = state =>
  produce(state, draft => {
    draft.presence.loading = true;
  });

const errorPresence = state =>
  produce(state, draft => {
    draft.presence.loading = false;
  });

const activitiesSuccess = (state, { data, pagination }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = data;
    draft.meta.total = pagination.total;
    draft.meta.pageCount = pagination.page_count;
  });

const allActivitiesSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.allActivities = data;
  });

const activitySuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.activity = data;
  });

const removeActivitySuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = state.data.filter(item => item.id !== data.id);
  });

const createActivitySuccess = state =>
  produce(state, draft => {
    draft.loading = false;
    draft.newActivity.step = state.newActivity.step + 1;
  });

const editActivitySuccess = state =>
  produce(state, draft => {
    draft.loading = false;
    draft.newActivity.step = state.newActivity.step + 1;
  });

const createPresenceSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.presence.loading = false;
  });

export const setMeta = (state, { data }) =>
  produce(state, draft => {
    draft.meta.page = data.page;
    draft.meta.limit = data.limit;
    draft.meta.event_id_eq = data.event_id_eq;
    draft.meta.event_id_in = data.event_id_in;
    draft.meta.pageCount = data.pageCount;
    draft.meta.total = data.total;
  });

export const setNewActivity = (state, { data }) =>
  produce(state, draft => {
    draft.newActivity = data;
  });

export const togglePresenceNav = (state, { data }) =>
  produce(state, draft => {
    draft.presence = {
      data: data || {},
      open: !state.presence.open,
      loading: false,
    };
  });

/* ------------- Hookup Reducers To Types ------------- */

export const reducer = createReducer(INITIAL_STATE, {
  [Types.ACTIVITIES_REQUEST]: loading,
  [Types.ACTIVITIES_SUCCESS]: activitiesSuccess,
  [Types.ACTIVITIES_FAILURE]: error,

  [Types.ALL_ACTIVITIES_REQUEST]: loading,
  [Types.ALL_ACTIVITIES_SUCCESS]: allActivitiesSuccess,
  [Types.ALL_ACTIVITIES_FAILURE]: error,

  [Types.ACTIVITY_REQUEST]: loading,
  [Types.ACTIVITY_SUCCESS]: activitySuccess,
  [Types.ACTIVITY_FAILURE]: error,

  [Types.REMOVE_ACTIVITY_REQUEST]: loading,
  [Types.REMOVE_ACTIVITY_SUCCESS]: removeActivitySuccess,
  [Types.REMOVE_ACTIVITY_FAILURE]: error,

  [Types.CREATE_ACTIVITY_REQUEST]: loading,
  [Types.CREATE_ACTIVITY_SUCCESS]: createActivitySuccess,
  [Types.CREATE_ACTIVITY_FAILURE]: error,

  [Types.EDIT_ACTIVITY_REQUEST]: loading,
  [Types.EDIT_ACTIVITY_SUCCESS]: editActivitySuccess,
  [Types.EDIT_ACTIVITY_FAILURE]: error,

  [Types.CREATE_PRESENCE_REQUEST]: loadingPresence,
  [Types.CREATE_PRESENCE_SUCCESS]: createPresenceSuccess,
  [Types.CREATE_PRESENCE_FAILURE]: errorPresence,

  [Types.SET_META]: setMeta,

  [Types.SET_NEW_ACTIVITY]: setNewActivity,

  [Types.TOGGLE_PRESENCE_NAV]: togglePresenceNav,
});
