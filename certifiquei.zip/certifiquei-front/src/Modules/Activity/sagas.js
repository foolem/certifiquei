import { takeLatest, call, put, all, select } from 'redux-saga/effects';
import { toast } from 'react-toastify';
import * as api from './api';
import ActivityActions, { ActivitySelectors } from '.';
import StudentActions from '../Student';
import StaffActions from '../Staff';

export function* activities() {
  const meta = yield select(ActivitySelectors.getMeta);

  const response = yield call(api.getActivities, meta);
  if (response.ok) {
    yield put(ActivityActions.activitiesSuccess(response.data, response.pagination));
  } else {
    yield put(ActivityActions.activitiesFailure(response.data));
  }
}

export function* allActivities() {
  const meta = yield select(ActivitySelectors.getMeta);

  const response = yield call(api.getAllActivities, meta);
  if (response.ok) {
    yield put(ActivityActions.allActivitiesSuccess(response.data, response.pagination));
  } else {
    yield put(ActivityActions.allActivitiesFailure(response.data));
  }
}

export function* activity({ data }) {
  const response = yield call(api.getActivity, data);
  if (response.ok) {
    yield put(ActivityActions.activitySuccess(response.data, response.pagination));
  } else {
    yield put(ActivityActions.activityFailure(response.data));
  }
}

export function* removeActivity({ data }) {
  const response = yield call(api.removeActivity, data);
  if (response.ok) {
    yield put(ActivityActions.removeActivitySuccess(response.data));
    toast.success('Atividade removida com sucesso.');
  } else {
    yield put(ActivityActions.removeActivityFailure(response.data));
    toast.error(response.data);
  }
}

export function* createActivity() {
  const newActivity = yield select(ActivitySelectors.getNewActivity);

  const response = yield call(api.createActivity, newActivity);
  if (response.ok) {
    yield put(ActivityActions.createActivitySuccess(response.data));
    toast.success('Atividade criada com sucesso.');
  } else {
    yield put(ActivityActions.createActivityFailure(response.data));
    toast.error(response.data);
  }
}

export function* editActivity() {
  const newActivity = yield select(ActivitySelectors.getNewActivity);

  const response = yield call(api.editActivity, newActivity);
  if (response.ok) {
    yield put(ActivityActions.editActivitySuccess(response.data));
    toast.success('Atividade editada com sucesso.');
  } else {
    yield put(ActivityActions.editActivityFailure(response.data));
    toast.error(response.data);
  }
}

export function* createPresence({ id, data }) {
  const response = yield call(api.createPresence, id, data);
  if (response.ok) {
    yield put(ActivityActions.createPresenceSuccess(response.data));
    yield put(StudentActions.studentsRequest());
    yield put(StaffActions.staffsRequest());
    yield put(ActivityActions.activitiesRequest());

    toast.success('Presença registrada com sucesso.');
  } else {
    yield put(ActivityActions.createPresenceFailure(response.data));
    toast.error(response.data);
  }
}

export function* removePresence({ data }) {
  const response = yield call(api.removePresence, data);
  if (response.ok) {
    yield put(ActivityActions.removePresenceSuccess(response.data));
    yield put(StudentActions.studentsRequest());
    yield put(StaffActions.staffsRequest());
    yield put(ActivityActions.activitiesRequest());

    toast.success('Presença removida com sucesso.');
  } else {
    yield put(ActivityActions.removePresenceFailure(response.data));
    toast.error(response.data);
  }
}

export default all([
  takeLatest('ACTIVITY/ALL_ACTIVITIES_REQUEST', allActivities),
  takeLatest('ACTIVITY/ACTIVITIES_REQUEST', activities),
  takeLatest('ACTIVITY/ACTIVITY_REQUEST', activity),
  takeLatest('ACTIVITY/REMOVE_ACTIVITY_REQUEST', removeActivity),
  takeLatest('ACTIVITY/CREATE_ACTIVITY_REQUEST', createActivity),
  takeLatest('ACTIVITY/EDIT_ACTIVITY_REQUEST', editActivity),
  takeLatest('ACTIVITY/CREATE_PRESENCE_REQUEST', createPresence),
  takeLatest('ACTIVITY/REMOVE_PRESENCE_REQUEST', removePresence),
]);
