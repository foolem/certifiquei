import { takeLatest, call, put, all, select } from 'redux-saga/effects';
import { toast } from 'react-toastify';
import * as api from './api';
import StaffActions, { StaffSelectors } from '.';

export function* staffs() {
  const meta = yield select(StaffSelectors.getMeta);

  const response = yield call(api.getStaffs, meta);
  if (response.ok) {
    yield put(StaffActions.staffsSuccess(response.data, response.pagination));
  } else {
    yield put(StaffActions.staffsFailure(response.data));
  }
}

export function* allStaffs() {
  const meta = yield select(StaffSelectors.getMeta);

  const response = yield call(api.getAllStaffs, meta);
  if (response.ok) {
    yield put(StaffActions.allStaffsSuccess(response.data, response.pagination));
  } else {
    yield put(StaffActions.allStaffsFailure(response.data));
  }
}

export function* staff({ data }) {
  const response = yield call(api.getStaff, data);
  if (response.ok) {
    yield put(StaffActions.staffSuccess(response.data, response.pagination));
  } else {
    yield put(StaffActions.staffFailure(response.data));
  }
}

export function* removeStaff({ data }) {
  const response = yield call(api.removeStaff, data);
  if (response.ok) {
    yield put(StaffActions.removeStaffSuccess(response.data));
    toast.success('Staff removido com sucesso.');
  } else {
    yield put(StaffActions.removeStaffFailure(response.data));
    toast.error(response.data);
  }
}

export function* createStaff() {
  const newStaff = yield select(StaffSelectors.getNewStaff);

  const response = yield call(api.createStaff, newStaff);
  if (response.ok) {
    yield put(StaffActions.createStaffSuccess(response.data));
    toast.success('Staff criado com sucesso.');
  } else {
    yield put(StaffActions.createStaffFailure(response.data));
    toast.error(response.data);
  }
}

export default all([
  takeLatest('STAFF/STAFFS_REQUEST', staffs),
  takeLatest('STAFF/ALL_STAFFS_REQUEST', allStaffs),
  takeLatest('STAFF/STAFF_REQUEST', staff),
  takeLatest('STAFF/REMOVE_STAFF_REQUEST', removeStaff),
  takeLatest('STAFF/CREATE_STAFF_REQUEST', createStaff),
]);
