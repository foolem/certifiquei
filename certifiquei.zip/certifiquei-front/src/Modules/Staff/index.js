import { createReducer, createActions } from 'reduxsauce';
import produce from 'immer';

/* ------------- Types and Action Creators ------------- */

const { Types, Creators } = createActions(
  {
    staffsRequest: ['data'],
    staffsSuccess: ['data', 'pagination'],
    staffsFailure: ['data'],

    allStaffsRequest: ['data'],
    allStaffsSuccess: ['data', 'pagination'],
    allStaffsFailure: ['data'],

    staffRequest: ['data'],
    staffSuccess: ['data'],
    staffFailure: ['data'],

    removeStaffRequest: ['data'],
    removeStaffSuccess: ['data'],
    removeStaffFailure: ['data'],

    createStaffRequest: ['data'],
    createStaffSuccess: ['data'],
    createStaffFailure: ['data'],

    setMeta: ['data'],

    setNewStaff: ['data'],
  },
  { prefix: 'STAFF/' },
);

export const StaffTypes = Types;
export default Creators;

/* ------------- Initial State ------------- */

const INITIAL_STATE = {
  allStaffs: [],
  data: [],
  loading: false,
  uploading: false,
  staff: {},
  newStaff: {
    step: 0,
    name: '',
  },
  meta: {
    page: 1,
    pageCount: 0,
    total: 0,
    event_id_in: [],
    active_in: [],
  },
  nav: {
    import: false,
  },
  import: {
    step: 0,
    preview: [],
  },
};

/* ------------- Selectors ------------- */

export const StaffSelectors = {
  getNewStaff: state => state.staff.newStaff,
  getStaff: state => state.staff.staff,
  getStaffs: state => state.staff.data,
  getAllStaffs: state => state.staff.allStaffs,
  getLoading: state => state.staff.loading,
  getMeta: state => state.staff.meta,
};

/* ------------- Reducers ------------- */

const loading = state =>
  produce(state, draft => {
    draft.loading = true;
  });

const error = state =>
  produce(state, draft => {
    draft.loading = false;
  });

const staffsSuccess = (state, { data, pagination }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = data;
    draft.meta.total = pagination.total;
    draft.meta.pageCount = pagination.page_count;
  });

const allStaffsSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.allStaffs = data;
  });

const staffSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.staff = data;
  });

const removeStaffSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = state.data.filter(item => item.id !== data.id);
  });

const createStaffSuccess = state =>
  produce(state, draft => {
    draft.loading = false;
    draft.newStaff.step = state.newStaff.step + 1;
  });

export const setMeta = (state, { data }) =>
  produce(state, draft => {
    draft.meta.page = data.page;
    draft.meta.limit = data.limit;
    draft.meta.user_first_name_i_cont = data.user_first_name_i_cont;
    draft.meta.event_id_in = data.event_id_in;
    draft.meta.pageCount = data.pageCount;
    draft.meta.total = data.total;
  });

export const setNewStaff = (state, { data }) =>
  produce(state, draft => {
    draft.newStaff = data;
  });

/* ------------- Hookup Reducers To Types ------------- */

export const reducer = createReducer(INITIAL_STATE, {
  [Types.STAFFS_REQUEST]: loading,
  [Types.STAFFS_SUCCESS]: staffsSuccess,
  [Types.STAFFS_FAILURE]: error,

  [Types.ALL_STAFFS_REQUEST]: loading,
  [Types.ALL_STAFFS_SUCCESS]: allStaffsSuccess,
  [Types.ALL_STAFFS_FAILURE]: error,

  [Types.STAFF_REQUEST]: loading,
  [Types.STAFF_SUCCESS]: staffSuccess,
  [Types.STAFF_FAILURE]: error,

  [Types.REMOVE_STAFF_REQUEST]: loading,
  [Types.REMOVE_STAFF_SUCCESS]: removeStaffSuccess,
  [Types.REMOVE_STAFF_FAILURE]: error,

  [Types.CREATE_STAFF_REQUEST]: loading,
  [Types.CREATE_STAFF_SUCCESS]: createStaffSuccess,
  [Types.CREATE_STAFF_FAILURE]: error,

  [Types.SET_META]: setMeta,

  [Types.SET_NEW_STAFF]: setNewStaff,
});
