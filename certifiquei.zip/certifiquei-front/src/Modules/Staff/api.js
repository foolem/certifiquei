import api from '../../Services/Api';

export const getStaffs = params => api.get('staffs', params);
export const getAllStaffs = params => api.get('staffs/all', params);
export const getStaff = id => api.get(`staffs/${id}`);
export const removeStaff = id => api.delete(`staffs/${id}`);
export const createStaff = params => api.post(`staffs`, params);
