import { takeLatest, call, put, all, select } from 'redux-saga/effects';
import * as api from './api';
import StudentCertificateActions, { StudentCertificateSelectors } from '.';

export function* studentCertificates() {
  const meta = yield select(StudentCertificateSelectors.getMeta);

  const response = yield call(api.getStudentCertificates, meta);
  if (response.ok) {
    yield put(
      StudentCertificateActions.studentCertificatesSuccess(response.data, response.pagination),
    );
  } else {
    yield put(StudentCertificateActions.studentCertificatesFailure(response.data));
  }
}

export default all([
  takeLatest('STUDENT_CERTIFICATE/STUDENT_CERTIFICATES_REQUEST', studentCertificates),
]);
