import { createReducer, createActions } from 'reduxsauce';
import produce from 'immer';

/* ------------- Types and Action Creators ------------- */

const { Types, Creators } = createActions(
  {
    studentCertificatesRequest: ['data'],
    studentCertificatesSuccess: ['data', 'pagination'],
    studentCertificatesFailure: ['data'],

    setMeta: ['data'],
  },
  { prefix: 'STUDENT_CERTIFICATE/' },
);

export const StudentCertificateTypes = Types;
export default Creators;

/* ------------- Initial State ------------- */

const INITIAL_STATE = {
  data: [],
  loading: false,
  meta: {
    page: 1,
    pageCount: 0,
    total: 0,
    active_in: [],
  },
};

/* ------------- Selectors ------------- */

export const StudentCertificateSelectors = {
  getStudentCertificates: state => state.studentCertificate.data,
  getLoading: state => state.studentCertificate.loading,
  getMeta: state => state.studentCertificate.meta,
};

/* ------------- Reducers ------------- */

const loading = state =>
  produce(state, draft => {
    draft.loading = true;
  });

const error = state =>
  produce(state, draft => {
    draft.loading = false;
  });

const studentsSuccess = (state, { data, pagination }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = data;
    draft.meta.total = pagination.total;
    draft.meta.pageCount = pagination.page_count;
  });

export const setMeta = (state, { data }) =>
  produce(state, draft => {
    draft.meta.page = data.page;
    draft.meta.limit = data.limit;
    draft.meta.user_first_name_i_cont = data.user_first_name_i_cont;
    draft.meta.active_in = data.active_in;
    draft.meta.event_id_in = data.event_id_in;
    draft.meta.pageCount = data.pageCount;
    draft.meta.total = data.total;
  });

/* ------------- Hookup Reducers To Types ------------- */

export const reducer = createReducer(INITIAL_STATE, {
  [Types.STUDENT_CERTIFICATES_REQUEST]: loading,
  [Types.STUDENT_CERTIFICATES_SUCCESS]: studentsSuccess,
  [Types.STUDENT_CERTIFICATES_FAILURE]: error,

  [Types.SET_META]: setMeta,
});
