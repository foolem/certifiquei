import api from '../../Services/Api';

export const getStudentCertificates = params => api.get('student-certificates', params);
