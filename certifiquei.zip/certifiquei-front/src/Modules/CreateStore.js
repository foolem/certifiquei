import { createStore, applyMiddleware } from 'redux';
import { persistStore } from 'redux-persist';
import { routerMiddleware } from 'connected-react-router';
import createSagaMiddleware from 'redux-saga';
import persistedReducers from '../Config/Persist';

export default (rootReducer, rootSaga, history) => {
  const sagaMiddleware = createSagaMiddleware();
  const store = createStore(
    persistedReducers(rootReducer),
    applyMiddleware(routerMiddleware(history), sagaMiddleware)
  );
  const persistor = persistStore(store);
  sagaMiddleware.run(rootSaga);

  return {
    store,
    persistor,
  };
};
