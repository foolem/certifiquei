import api from '../../Services/Api';

export const getPresences = (id, params) => api.get(`activities/${id}/presences`, params);
export const removePresence = params =>
  api.delete(`activities/${params.activityId}/presences/${params.id}`);
export const createPresence = params => api.post(`events/${params.eventId}/presences`, params);
