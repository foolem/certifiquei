import { takeLatest, call, put, all, select } from 'redux-saga/effects';
import { toast } from 'react-toastify';
import * as api from './api';
import PresenceActions, { PresenceSelectors } from '.';

export function* presences({ activityId }) {
  const meta = yield select(PresenceSelectors.getMeta);

  const response = yield call(api.getPresences, activityId, meta);
  if (response.ok) {
    yield put(PresenceActions.presencesSuccess(response.data, response.pagination));
  } else {
    yield put(PresenceActions.presencesFailure(response.data));
  }
}

export function* removePresence({ data }) {
  const response = yield call(api.removePresence, data);
  if (response.ok) {
    yield put(PresenceActions.removePresenceSuccess(response.data));
    toast.success('Presença removida com sucesso.');
  } else {
    yield put(PresenceActions.removePresenceFailure(response.data));
    toast.error(response.data);
  }
}

export function* createPresence() {
  const newPresence = yield select(PresenceSelectors.getNewPresence);

  const response = yield call(api.createPresence, newPresence);
  if (response.ok) {
    yield put(PresenceActions.createPresenceSuccess(response.data));
    toast.success('Presença criada com sucesso.');
  } else {
    yield put(PresenceActions.createPresenceFailure(response.data));
    toast.error(response.data);
  }
}

export default all([
  takeLatest('PRESENCE/PRESENCES_REQUEST', presences),
  takeLatest('PRESENCE/REMOVE_PRESENCE_REQUEST', removePresence),
  takeLatest('PRESENCE/CREATE_PRESENCE_REQUEST', createPresence),
]);
