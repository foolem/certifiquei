import { createReducer, createActions } from 'reduxsauce';
import produce from 'immer';

/* ------------- Types and Action Creators ------------- */

const { Types, Creators } = createActions(
  {
    presencesRequest: ['activityId', 'data'],
    presencesSuccess: ['data', 'pagination'],
    presencesFailure: ['data'],

    removePresenceRequest: ['data'],
    removePresenceSuccess: ['data'],
    removePresenceFailure: ['data'],

    createPresenceRequest: ['data'],
    createPresenceSuccess: ['data'],
    createPresenceFailure: ['data'],

    setMeta: ['data'],

    setNewPresence: ['data'],
  },
  { prefix: 'PRESENCE/' },
);

export const PresenceTypes = Types;
export default Creators;

/* ------------- Initial State ------------- */

const INITIAL_STATE = {
  data: [],
  loading: false,
  newPresence: {
    step: 0,
  },
  meta: {
    page: 1,
    pageCount: 0,
    total: 0,
    activity_id_in: [],
    active_in: [],
  },
};

/* ------------- Selectors ------------- */

export const PresenceSelectors = {
  getNewPresence: state => state.presence.newPresence,
  getPresences: state => state.presence.data,
  getLoading: state => state.presence.loading,
  getMeta: state => state.presence.meta,
};

/* ------------- Reducers ------------- */

const loading = state =>
  produce(state, draft => {
    draft.loading = true;
  });

const error = state =>
  produce(state, draft => {
    draft.loading = false;
  });

const presencesSuccess = (state, { data, pagination }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = data;
    draft.meta.total = pagination.total;
    draft.meta.pageCount = pagination.page_count;
  });

const presenceSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.presence = data;
  });

const removePresenceSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = state.data.filter(item => item.id !== data.id);
  });

const createPresenceSuccess = state =>
  produce(state, draft => {
    draft.loading = false;
    draft.newPresence.step = state.newPresence.step + 1;
  });

export const setMeta = (state, { data }) =>
  produce(state, draft => {
    draft.meta.page = data.page;
    draft.meta.limit = data.limit;
    draft.meta.user_first_name_i_cont = data.user_first_name_i_cont;
    draft.meta.active_in = data.active_in;
    draft.meta.activity_id_in = data.activity_id_in;
    draft.meta.pageCount = data.pageCount;
    draft.meta.total = data.total;
  });

export const setNewPresence = (state, { data }) =>
  produce(state, draft => {
    draft.newPresence = data;
  });

/* ------------- Hookup Reducers To Types ------------- */

export const reducer = createReducer(INITIAL_STATE, {
  [Types.PRESENCES_REQUEST]: loading,
  [Types.PRESENCES_SUCCESS]: presencesSuccess,
  [Types.PRESENCES_FAILURE]: error,

  [Types.REMOVE_PRESENCE_REQUEST]: loading,
  [Types.REMOVE_PRESENCE_SUCCESS]: removePresenceSuccess,
  [Types.REMOVE_PRESENCE_FAILURE]: error,

  [Types.CREATE_PRESENCE_REQUEST]: loading,
  [Types.CREATE_PRESENCE_SUCCESS]: createPresenceSuccess,
  [Types.CREATE_PRESENCE_FAILURE]: error,

  [Types.SET_META]: setMeta,

  [Types.SET_NEW_PRESENCE]: setNewPresence,
});
