/* eslint-disable import/no-named-as-default */
import { all } from 'redux-saga/effects';

import user from './User/sagas';
import event from './Event/sagas';
import certificate from './Certificate/sagas';
import student from './Student/sagas';
import staff from './Staff/sagas';
import activity from './Activity/sagas';
import studentCertificate from './StudentCertificate/sagas';
import presence from './Presence/sagas';

export default function* rootSaga() {
  yield all([user, event, certificate, student, staff, activity, studentCertificate, presence]);
}
