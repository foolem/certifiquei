import { combineReducers } from 'redux';
import { createBrowserHistory } from 'history';
import configureStore from './CreateStore';
import rootSaga from './RootSaga';

const history = createBrowserHistory();

const finalReducers = combineReducers({
  user: require('./User').reducer,
  event: require('./Event').reducer,
  certificate: require('./Certificate').reducer,
  student: require('./Student').reducer,
  staff: require('./Staff').reducer,
  activity: require('./Activity').reducer,
  studentCertificate: require('./StudentCertificate').reducer,
  presence: require('./Presence').reducer,
});

const { store, persistor } = configureStore(finalReducers, rootSaga, history);

export { store, persistor, history };
