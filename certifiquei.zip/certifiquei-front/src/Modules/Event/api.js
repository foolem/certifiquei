import api from '../../Services/Api';

export const getEvents = params => api.get('events', params);
export const getAllEvents = () => api.get('events/all');
export const getEvent = id => api.get(`events/${id}`);
export const createEvent = params => api.post('events', params);
export const editEvent = params => api.put(`events/${params.id}`, params);
export const removeEvent = id => api.delete(`events/${id}`);
export const distribute = id => api.get(`events/${id}/distribute-certificates`);
