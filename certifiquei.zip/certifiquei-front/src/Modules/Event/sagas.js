import { takeLatest, call, put, all, select } from 'redux-saga/effects';
import { toast } from 'react-toastify';
import * as api from './api';
import EventActions, { EventSelectors } from '.';

export function* events() {
  const meta = yield select(EventSelectors.getMeta);

  const response = yield call(api.getEvents, meta);
  if (response.ok) {
    yield put(EventActions.eventsSuccess(response.data, response.pagination));
  } else {
    yield put(EventActions.eventsFailure(response.data));
  }
}

export function* allEvents() {
  const response = yield call(api.getAllEvents);
  if (response.ok) {
    yield put(EventActions.allEventsSuccess(response.data));
  } else {
    yield put(EventActions.allEventsFailure(response.data));
  }
}

export function* show({ data }) {
  const response = yield call(api.getEvent, data);
  if (response.ok) {
    yield put(EventActions.eventSuccess(response.data));
  } else {
    yield put(EventActions.eventFailure(response.data));
  }
}

export function* create() {
  const event = yield select(EventSelectors.getNewEvent);

  const response = yield call(api.createEvent, {
    ...event,
    securitiesAttributes: event.securitiesAttributes.map(item => ({ kind: item })),
  });
  if (response.ok) {
    yield put(EventActions.createEventSuccess(response.data));
    toast.success('Evento criado com sucesso.');
  } else {
    yield put(EventActions.createEventFailure(response.data));
    toast.error(response.data);
  }
}

export function* edit() {
  const event = yield select(EventSelectors.getNewEvent);
  const currentEvent = yield select(EventSelectors.getEvent);

  const currentSecurities = currentEvent.securities;

  const data = {
    ...event,
    securitiesAttributes: ['internal', 'blockchain'].map(item => ({
      kind: item,
      id: currentSecurities.find(inner => inner.kind === item)?.id,
      _destroy: !event.securitiesAttributes.includes(item),
    })),
  };

  const response = yield call(api.editEvent, data);

  if (response.ok) {
    yield put(EventActions.editEventSuccess(response.data));
    toast.success('Evento editado com sucesso.');
  } else {
    yield put(EventActions.editEventFailure(response.data));
    toast.error(response.data);
  }
}

export function* remove({ data }) {
  const response = yield call(api.removeEvent, data);
  if (response.ok) {
    yield put(EventActions.removeEventSuccess(response.data));
    toast.success('Evento removido com sucesso.');
  } else {
    yield put(EventActions.removeEventFailure(response.data));
    toast.error(response.data);
  }
}

export function* distributeCertificates({ data }) {
  const response = yield call(api.distribute, data);
  if (response.ok) {
    yield put(EventActions.distributeSuccess(response.data));
    toast.success('A distribuição foi iniciada com sucesso.');
  } else {
    yield put(EventActions.distributeFailure(response.data));
    toast.error(response.data);
  }
}

export default all([
  takeLatest('EVENT/EVENTS_REQUEST', events),
  takeLatest('EVENT/ALL_EVENTS_REQUEST', allEvents),
  takeLatest('EVENT/EVENT_REQUEST', show),
  takeLatest('EVENT/CREATE_EVENT_REQUEST', create),
  takeLatest('EVENT/EDIT_EVENT_REQUEST', edit),
  takeLatest('EVENT/REMOVE_EVENT_REQUEST', remove),
  takeLatest('EVENT/DISTRIBUTE_REQUEST', distributeCertificates),
]);
