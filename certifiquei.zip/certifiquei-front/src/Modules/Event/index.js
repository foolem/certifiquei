import { createReducer, createActions } from 'reduxsauce';
import produce from 'immer';

/* ------------- Types and Action Creators ------------- */

const { Types, Creators } = createActions(
  {
    eventsRequest: ['data'],
    eventsSuccess: ['data', 'pagination'],
    eventsFailure: ['data'],

    allEventsRequest: ['data'],
    allEventsSuccess: ['data'],
    allEventsFailure: ['data'],

    eventRequest: ['data'],
    eventSuccess: ['data'],
    eventFailure: ['data'],

    createEventRequest: ['data'],
    createEventSuccess: ['data'],
    createEventFailure: ['data'],

    editEventRequest: ['data'],
    editEventSuccess: ['data'],
    editEventFailure: ['data'],

    removeEventRequest: ['data'],
    removeEventSuccess: ['data'],
    removeEventFailure: ['data'],

    distributeRequest: ['data'],
    distributeSuccess: ['data'],
    distributeFailure: ['data'],

    setNewEvent: ['data'],
    setNewEventDescription: ['data'],

    setMeta: ['data'],
  },
  { prefix: 'EVENT/' },
);

export const EventTypes = Types;
export default Creators;

/* ------------- Initial State ------------- */

const INITIAL_STATE = {
  data: [],
  all: [],
  event: {},
  newEvent: {
    step: 0,
    title: '',
    description: '',
    online: false,
    addressAttributes: {},
    deliveriesAttributes: [{ kind: 'email' }],
    securitiesAttributes: ['internal'],
    activitiesAttributes: [],
  },
  loading: false,
  meta: {
    page: 1,
    pageCount: 0,
    total: 0,
    status_in: [],
    category_id_in: [],
    level_id_in: [],
  },
};

/* ------------- Selectors ------------- */

export const EventSelectors = {
  getEvents: state => state.event.data,
  getAllEvents: state => state.event.all,
  getEvent: state => state.event.event,
  getNewEvent: state => state.event.newEvent,
  getLoading: state => state.event.loading,
  getMeta: state => state.event.meta,
};

/* ------------- Reducers ------------- */

const loading = state =>
  produce(state, draft => {
    draft.loading = true;
  });

const error = state =>
  produce(state, draft => {
    draft.loading = false;
  });

const success = state =>
  produce(state, draft => {
    draft.loading = false;
  });

const eventsSuccess = (state, { data, pagination }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = data;
    draft.meta.total = pagination.total;
    draft.meta.pageCount = pagination.page_count;
  });

const allEventsSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.all = data;
  });

const eventSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.event = data;
  });

const createEventSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.newEvent = { ...data, step: state.newEvent.step + 1 };
  });

const editEventSuccess = state =>
  produce(state, draft => {
    draft.loading = false;
    draft.newEvent = { ...state.newEvent, step: state.newEvent.step + 1 };
  });

const removeEventSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = state.data.filter(item => item.id !== data.id);
  });

export const setNewEvent = (state, { data }) =>
  produce(state, draft => {
    draft.newEvent = data;
  });

export const setNewEventDescription = (state, { data }) =>
  produce(state, draft => {
    draft.newEvent.description = data;
  });

export const setMeta = (state, { data }) =>
  produce(state, draft => {
    draft.meta.title_i_cont = data.title_i_cont;
    draft.meta.status_in = data.status_in;
    draft.meta.category_id_in = data.category_id_in;
    draft.meta.level_id_in = data.level_id_in;
    draft.meta.page = data.page;
    draft.meta.limit = data.limit;
    draft.meta.pageCount = data.pageCount;
    draft.meta.total = data.total;
  });

/* ------------- Hookup Reducers To Types ------------- */

export const reducer = createReducer(INITIAL_STATE, {
  [Types.EVENTS_REQUEST]: loading,
  [Types.EVENTS_SUCCESS]: eventsSuccess,
  [Types.EVENTS_FAILURE]: error,

  [Types.ALL_EVENTS_REQUEST]: loading,
  [Types.ALL_EVENTS_SUCCESS]: allEventsSuccess,
  [Types.ALL_EVENTS_FAILURE]: error,

  [Types.EVENT_REQUEST]: loading,
  [Types.EVENT_SUCCESS]: eventSuccess,
  [Types.EVENT_FAILURE]: error,

  [Types.CREATE_EVENT_REQUEST]: loading,
  [Types.CREATE_EVENT_SUCCESS]: createEventSuccess,
  [Types.CREATE_EVENT_FAILURE]: error,

  [Types.EDIT_EVENT_REQUEST]: loading,
  [Types.EDIT_EVENT_SUCCESS]: editEventSuccess,
  [Types.EDIT_EVENT_FAILURE]: error,

  [Types.REMOVE_EVENT_REQUEST]: loading,
  [Types.REMOVE_EVENT_SUCCESS]: removeEventSuccess,
  [Types.REMOVE_EVENT_FAILURE]: error,

  [Types.DISTRIBUTE_REQUEST]: loading,
  [Types.DISTRIBUTE_SUCCESS]: success,
  [Types.DISTRIBUTE_FAILURE]: error,

  [Types.SET_NEW_EVENT]: setNewEvent,
  [Types.SET_NEW_EVENT_DESCRIPTION]: setNewEventDescription,

  [Types.SET_META]: setMeta,
});
