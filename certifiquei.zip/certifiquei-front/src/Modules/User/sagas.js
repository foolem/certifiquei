import { takeLatest, call, put, all, select } from 'redux-saga/effects';
import { toast } from 'react-toastify';
import * as api from './api';
import { setToken, removeToken } from '../../Services/Api';
import UserActions, { UserSelectors } from '.';

export function* signInSaga({ data }) {
  const response = yield call(api.signIn, data);
  if (response.ok) {
    toast.success('Seja bem-vindo!');
    yield put(UserActions.signInSuccess(response.data));
    setToken(response.data.jwt);

    setTimeout(() => {
      if (window.location.href.includes('ref=')) {
        window.location.replace(decodeURIComponent(window.location.href.split('ref=')[1]));
      } else {
        window.location.replace('/');
      }
    }, 1000);
  } else {
    toast.error('E-mail ou senha incorretos, tente novamente');
    yield put(UserActions.signInFailure(response.data));
  }
}

export function* signUpSaga({ data }) {
  const response = yield call(api.signUp, data);

  if (response.ok) {
    toast.success('Seja bem-vindo!');
    yield put(UserActions.signUpSuccess(response.data));
    setToken(response.data.jwt);
    setTimeout(() => {
      window.location.replace('/');
    }, 2000);
  } else {
    toast.error(response.data);
    yield put(UserActions.signUpFailure(response.data));
  }
}

export function* logout() {
  yield put(UserActions.logoutSuccess());
  removeToken();
  window.location.replace('/signin');
}

export function* validateTokenSaga() {
  const response = yield call(api.validateToken);
  if (response.ok) {
    yield put(UserActions.validateTokenSuccess(response.data));
  } else {
    yield put(UserActions.validateTokenFailure(response.data));
    window.location.replace(`/signin?noAuth=&ref=${encodeURIComponent(window.location.pathname)}`);
  }
}

export function* userSaga({ data }) {
  const response = yield call(api.user, data);
  if (response.ok) {
    yield put(UserActions.userSuccess(response.data));
  } else {
    yield put(UserActions.userFailure(response.data));
  }
}

export function* users() {
  const meta = yield select(UserSelectors.getMeta);
  const filters = yield select(UserSelectors.getFilters);

  const response = yield call(api.getUsers, { ...meta, ...filters });
  if (response.ok) {
    yield put(UserActions.usersSuccess(response.data, response.pagination));
  } else {
    yield put(UserActions.usersFailure(response.data));
  }
}

export function* editSaga() {
  const auth = yield select(UserSelectors.getNewUser);

  const response = yield call(api.editUser, auth);
  if (response.ok) {
    toast.success('Informações alteradas com sucesso.');
    yield put(UserActions.editUserSuccess(response.data));
  } else {
    toast.error(response.data);
    yield put(UserActions.editUserFailure(response.data));
  }
}

export function* removeSaga({ data }) {
  const response = yield call(api.removeUser, data);

  if (response.ok) {
    toast.success('Usuário removido com sucesso.');
    yield put(UserActions.removeUserSuccess(response.data));
  } else {
    toast.error(response.data);
    yield put(UserActions.removeUserFailure(response.data));
  }
}

export function* resetPassword({ data }) {
  const userType = window.location.href.split('userType=')[1];

  const response = yield call(api.postResetPassword, { ...data, userType });
  if (response.ok) {
    toast.success(
      'Foram enviadas instruções para o seu e-mail. Verifique sua caixa de entrada e spam.',
    );

    yield put(UserActions.resetPasswordSuccess(response.data));
  } else {
    toast.error(response.data);

    yield put(UserActions.resetPasswordFailure(response.data));
  }
}

export function* updatePassword({ data }) {
  const response = yield call(api.putUpdatePassword, data);
  if (response.ok) {
    yield put(UserActions.updatePasswordSuccess(response.data));
    toast.success('Senha alterada com sucesso. Realize o login novamente');
    setTimeout(() => {
      window.location.replace('/signin');
    }, 2000);
  } else {
    toast.error(response.data);

    yield put(UserActions.updatePasswordFailure(response.data));
  }
}

export function* confirmEmail({ data }) {
  const response = yield call(api.postConfirmEmail, data);
  if (response.ok) {
    yield put(UserActions.confirmEmailSuccess(response.data));
    toast.success('E-mail confirmado com sucesso. Realize o login para entrar na plataforma');
    setTimeout(() => {
      window.location.replace('/signin');
    }, 2000);
  } else {
    toast.error(response.data);

    yield put(UserActions.confirmEmailFailure(response.data));
  }
}

export default all([
  takeLatest('SIGN_IN_REQUEST', signInSaga),
  takeLatest('SIGN_UP_REQUEST', signUpSaga),
  takeLatest('LOGOUT_REQUEST', logout),
  takeLatest('USER_REQUEST', userSaga),
  takeLatest('USERS_REQUEST', users),
  takeLatest('EDIT_USER_REQUEST', editSaga),
  takeLatest('REMOVE_USER_REQUEST', removeSaga),
  takeLatest('CONFIRM_EMAIL_REQUEST', confirmEmail),
  takeLatest('VALIDATE_TOKEN_REQUEST', validateTokenSaga),
  takeLatest('RESET_PASSWORD_REQUEST', resetPassword),
  takeLatest('UPDATE_PASSWORD_REQUEST', updatePassword),
]);
