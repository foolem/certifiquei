import api, { getToken } from '../../Services/Api';

export const signIn = params => api.post('sessions', params);

export const signUp = params => api.post('users', params);

export const user = id => api.get(`users/${id}`);

export const editUser = params => api.put(`users/${params.id}`, params);

export const removeUser = id => api.delete(`users/${id}`);

export const postResetPassword = params => api.post(`users/reset-password`, params);

export const putUpdatePassword = params => api.put(`users/update-password`, params);

export const postConfirmEmail = params => api.post(`users/confirm-email`, params);

export const validateToken = () =>
  api.post('sessions/validate-token', {
    token: `Bearer ${getToken()}`,
  });

export const getUsers = params => api.get('users', params);
