import { createReducer, createActions } from 'reduxsauce';
import produce from 'immer';
import { getToken } from '../../Services/Api';

/* ------------- Types and Action Creators ------------- */

const { Types, Creators } = createActions({
  signInRequest: ['data'],
  signInSuccess: ['data'],
  signInFailure: ['data'],

  signUpRequest: ['data'],
  signUpSuccess: ['data'],
  signUpFailure: ['data'],

  logoutRequest: ['data'],
  logoutSuccess: ['data'],
  logoutFailure: ['data'],

  usersRequest: ['data'],
  usersSuccess: ['data', 'pagination'],
  usersFailure: ['data'],

  userRequest: ['data'],
  userSuccess: ['data'],
  userFailure: ['data'],

  editUserRequest: ['data'],
  editUserSuccess: ['data'],
  editUserFailure: ['data'],

  removeUserRequest: ['data'],
  removeUserSuccess: ['data'],
  removeUserFailure: ['data'],

  validateTokenRequest: ['data'],
  validateTokenSuccess: ['data'],
  validateTokenFailure: ['data'],

  resetPasswordRequest: ['data'],
  resetPasswordSuccess: ['data'],
  resetPasswordFailure: ['data'],

  updatePasswordRequest: ['data'],
  updatePasswordSuccess: ['data'],
  updatePasswordFailure: ['data'],

  confirmEmailRequest: ['data'],
  confirmEmailSuccess: ['data'],
  confirmEmailFailure: ['data'],

  setMeta: ['data'],

  setFilters: ['data'],

  setNewUser: ['data'],
});

export const UserTypes = Types;
export default Creators;

/* ------------- Initial State ------------- */

const INITIAL_STATE = {
  data: [],
  currentUser: {
    id: '',
    role: '',
    jwt: '',
    firstName: '',
    lastName: '',
    email: '',
    document: '',
    bio: '',
    userRoles: [],
  },
  user: {},
  newUser: {
    step: 0,
    firstName: '',
    lastName: '',
    email: '',
    document: '',
    bio: '',
    userRolesAttributes: [],
    recipient: {},
  },
  loading: false,
  saving: false,
  meta: {
    first_name_i_cont: '',
    status_in: [],
    page: 1,
    pageCount: 0,
    total: 0,
  },
  filters: {
    first_name_i_cont: '',
    status_in: [],
  },
};

/* ------------- Selectors ------------- */

export const UserSelectors = {
  getUsers: state => state.user.data,
  getUser: state => state.user.currentUser,
  getShowUser: state => state.user.user,
  getNewUser: state => state.user.newUser,
  getJWT: () => getToken(),
  getLoading: state => state.user.loading,
  getSaving: state => state.user.saving,
  getUserRole: state => state.user.currentUser.role,
  getIsAdmin: state => state.user.currentUser.admin,
  getMeta: state => state.user.meta,
  getFilters: state => state.user.filters,
};

/* ------------- Reducers ------------- */

const signInSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.currentUser = { ...data };
  });

const signUpSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.currentUser = { ...data };
  });

const logoutSuccess = state =>
  produce(state, draft => {
    draft.loading = false;
    draft.jwt = '';
  });

const userSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.user = data;
  });

const editUserSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.currentUser = data;
  });

const loading = state =>
  produce(state, draft => {
    draft.loading = true;
  });

const error = state =>
  produce(state, draft => {
    draft.loading = false;
  });

const success = state =>
  produce(state, draft => {
    draft.loading = false;
  });

const validateTokenSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.jwt = data.jwt;
    draft.currentUser = { ...data };
  });

const usersSuccess = (state, { data, pagination }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = data;
    draft.meta.total = pagination.total;
    draft.meta.pageCount = pagination.page_count;
  });

const removeUserSuccess = (state, { data }) =>
  produce(state, draft => {
    draft.loading = false;
    draft.data = state.data.filter(item => item.id !== data.id);
  });

export const setMeta = (state, { data }) =>
  produce(state, draft => {
    draft.meta.page = data.page;
    draft.meta.limit = data.limit;
    draft.meta.first_name_i_cont = data.first_name_i_cont;
    draft.meta.pageCount = data.pageCount;
    draft.meta.total = data.total;
  });

export const setFilters = (state, { data }) =>
  produce(state, draft => {
    draft.filters = data;
  });

export const setNewUser = (state, { data }) =>
  produce(state, draft => {
    draft.newUser = data;
  });

/* ------------- Hookup Reducers To Types ------------- */

export const reducer = createReducer(INITIAL_STATE, {
  [Types.SIGN_IN_REQUEST]: loading,
  [Types.SIGN_IN_SUCCESS]: signInSuccess,
  [Types.SIGN_IN_FAILURE]: error,

  [Types.SIGN_UP_REQUEST]: loading,
  [Types.SIGN_UP_SUCCESS]: signUpSuccess,
  [Types.SIGN_UP_FAILURE]: error,

  [Types.LOGOUT_REQUEST]: loading,
  [Types.LOGOUT_SUCCESS]: logoutSuccess,
  [Types.LOGOUT_FAILURE]: error,

  [Types.USER_REQUEST]: loading,
  [Types.USER_SUCCESS]: userSuccess,
  [Types.USER_FAILURE]: error,

  [Types.REMOVE_USER_REQUEST]: loading,
  [Types.REMOVE_USER_SUCCESS]: removeUserSuccess,
  [Types.REMOVE_USER_FAILURE]: error,

  [Types.USERS_REQUEST]: loading,
  [Types.USERS_SUCCESS]: usersSuccess,
  [Types.USERS_FAILURE]: error,

  [Types.EDIT_USER_REQUEST]: loading,
  [Types.EDIT_USER_SUCCESS]: editUserSuccess,
  [Types.EDIT_USER_FAILURE]: error,

  [Types.VALIDATE_TOKEN_REQUEST]: loading,
  [Types.VALIDATE_TOKEN_SUCCESS]: validateTokenSuccess,
  [Types.VALIDATE_TOKEN_FAILURE]: error,

  [Types.RESET_PASSWORD_REQUEST]: loading,
  [Types.RESET_PASSWORD_SUCCESS]: success,
  [Types.RESET_PASSWORD_FAILURE]: error,

  [Types.UPDATE_PASSWORD_REQUEST]: loading,
  [Types.UPDATE_PASSWORD_SUCCESS]: success,
  [Types.UPDATE_PASSWORD_FAILURE]: error,

  [Types.CONFIRM_EMAIL_REQUEST]: loading,
  [Types.CONFIRM_EMAIL_SUCCESS]: success,
  [Types.CONFIRM_EMAIL_FAILURE]: error,

  [Types.SET_META]: setMeta,

  [Types.SET_FILTERS]: setFilters,

  [Types.SET_NEW_USER]: setNewUser,
});
