import React from 'react';
import { Switch } from 'react-router-dom';

import SignIn from '../Containers/SignIn';
import SignUp from '../Containers/SignUp';
import EventSignUp from '../Containers/EventSignup';
import ForgotPassword from '../Containers/ForgotPassword';
import UpdatePassword from '../Containers/UpdatePassword';
import ConfirmEmail from '../Containers/ConfirmEmail';
import Validate from '../Containers/Validate';

import Home from '../Containers/Home';

import EventsIndex from '../Containers/Events/Index';
import EventsNew from '../Containers/Events/New';
import EventsEdit from '../Containers/Events/Edit';
import EventsShow from '../Containers/Events/Show';

import StudentsIndex from '../Containers/Students/Index';
import StudentsNew from '../Containers/Students/New';
import StudentsEdit from '../Containers/Students/Edit';
import StudentsShow from '../Containers/Students/Show';

import PresencesIndex from '../Containers/Presences/Index';
import PresencesNew from '../Containers/Presences/New';

import ActivitiesIndex from '../Containers/Activities/Index';
import ActivitiesNew from '../Containers/Activities/New';
import ActivitiesEdit from '../Containers/Activities/Edit';
import ActivitiesShow from '../Containers/Activities/Show';

import StaffsIndex from '../Containers/Staffs/Index';
import StaffsNew from '../Containers/Staffs/New';
import StaffsShow from '../Containers/Staffs/Show';

import CertificatesIndex from '../Containers/Certificates/Index';
import CertificatesGallery from '../Containers/Certificates/Gallery';
import CertificatesNew from '../Containers/Certificates/New';
import CertificatesEdit from '../Containers/Certificates/Edit';
import CertificatesNewEdit from '../Containers/Certificates/NewEdit';

import Settings from '../Containers/Settings';

import RouteWrapper from './RouteWrapper';

const Routes = () => {
  return (
    <Switch>
      <RouteWrapper path="/" exact isPrivate component={Home} />
      <RouteWrapper path="/signin" exact component={SignIn} />
      <RouteWrapper path="/signup" exact component={SignUp} />
      <RouteWrapper path="/events/:id/signup" exact component={EventSignUp} />
      <RouteWrapper path="/forgot-password" exact component={ForgotPassword} />
      <RouteWrapper path="/update-password/:token" exact component={UpdatePassword} />
      <RouteWrapper path="/confirm-email/:token" exact component={ConfirmEmail} />
      <RouteWrapper path="/validate" exact component={Validate} />

      <RouteWrapper path="/organizing/events" exact isPrivate component={EventsIndex} />
      <RouteWrapper path="/organizing/events/new" exact isPrivate component={EventsNew} />
      <RouteWrapper path="/organizing/events/:id/edit" exact isPrivate component={EventsEdit} />
      <RouteWrapper path="/organizing/events/:id" exact isPrivate component={EventsShow} />

      <RouteWrapper path="/organizing/students" exact isPrivate component={StudentsIndex} />
      <RouteWrapper path="/organizing/students/new" exact isPrivate component={StudentsNew} />
      <RouteWrapper path="/organizing/students/:id/edit" exact isPrivate component={StudentsEdit} />
      <RouteWrapper path="/organizing/students/:id" exact isPrivate component={StudentsShow} />

      <RouteWrapper path="/organizing/presences" exact isPrivate component={PresencesIndex} />
      <RouteWrapper path="/organizing/presences/new" exact isPrivate component={PresencesNew} />

      <RouteWrapper path="/organizing/activities" exact isPrivate component={ActivitiesIndex} />
      <RouteWrapper path="/organizing/activities/new" exact isPrivate component={ActivitiesNew} />
      <RouteWrapper
        path="/organizing/activities/:id/edit"
        exact
        isPrivate
        component={ActivitiesEdit}
      />
      <RouteWrapper path="/organizing/activities/:id" exact isPrivate component={ActivitiesShow} />

      <RouteWrapper path="/organizing/staffs" exact isPrivate component={StaffsIndex} />
      <RouteWrapper path="/organizing/staffs/new" exact isPrivate component={StaffsNew} />
      <RouteWrapper path="/organizing/staffs/:id" exact isPrivate component={StaffsShow} />

      <RouteWrapper path="/organizing/certificates" exact isPrivate component={CertificatesIndex} />
      <RouteWrapper
        path="/organizing/certificates/gallery"
        exact
        isPrivate
        component={CertificatesGallery}
      />
      <RouteWrapper
        path="/organizing/certificates/new"
        exact
        isPrivate
        component={CertificatesNew}
      />
      <RouteWrapper
        path="/organizing/certificates/new/edit/:templateId"
        exact
        isPrivate
        component={CertificatesNewEdit}
      />
      <RouteWrapper
        path="/organizing/certificates/:id/edit"
        exact
        isPrivate
        component={CertificatesEdit}
      />

      <RouteWrapper path="/settings" exact isPrivate component={Settings} />
    </Switch>
  );
};

export default Routes;
