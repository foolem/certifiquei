import React from 'react';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';
import { Route } from 'react-router-dom';

import UserActions from '../Modules/User';
import { getToken } from '../Services/Api';

export default function RouteWrapper({ component: Component, isPrivate, ...props }) {
  const dispatch = useDispatch();
  const jwt = getToken();

  if (!jwt && isPrivate) {
    window.location.replace(`/signin?noAuth=&ref=${encodeURIComponent(window.location.pathname)}`);
  }

  if (isPrivate) {
    dispatch(UserActions.validateTokenRequest());
  }

  // eslint-disable-next-line react/jsx-props-no-spreading
  return <Route {...props} component={Component} />;
}

RouteWrapper.propTypes = {
  isPrivate: PropTypes.bool,
  component: PropTypes.oneOfType([PropTypes.element, PropTypes.func]).isRequired,
};

RouteWrapper.defaultProps = {
  isPrivate: false,
};
