class CreateDeliveries < ActiveRecord::Migration[6.0]
  def change
    create_table :deliveries, id: :uuid do |t|
      t.integer :kind
      t.text :content

      t.uuid :event_id, index: true
      t.timestamps
    end
  end
end
