class CreatePresence < ActiveRecord::Migration[6.0]
  def change
    create_table :presences, id: :uuid do |t|
      t.uuid :activity_id, index: true
      t.uuid :staff_id, index: true
      t.uuid :student_id, index: true
      t.datetime :deleted_at

      t.timestamps
    end
  end
end
