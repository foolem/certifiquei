class CreateUsers < ActiveRecord::Migration[6.0]
  def change
    create_table :users, id: :uuid do |t|
      t.integer :user_type, default: 0
      t.string :course
      t.string :grr
      t.string :email, index: true
      t.string :first_name
      t.string :last_name
      t.string :jwt
      t.string :password_digest
      t.string :password_token, index: true
      t.datetime :deleted_at

      t.timestamps
    end
  end
end
