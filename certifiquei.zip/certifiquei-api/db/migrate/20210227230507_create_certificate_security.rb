class CreateCertificateSecurity < ActiveRecord::Migration[6.0]
  def change
    create_table :certificate_securities, id: :uuid do |t|
      t.string :resource, index: true

      t.uuid :student_certificate_id, index: true
      t.uuid :security_id, index: true
      t.timestamps
    end
  end
end
