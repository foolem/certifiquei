class CreateCertificateTemplates < ActiveRecord::Migration[6.0]
  def change
    create_table :certificate_templates, id: :uuid do |t|
      t.string :title
      t.jsonb :metadata

      t.timestamps
    end
  end
end
