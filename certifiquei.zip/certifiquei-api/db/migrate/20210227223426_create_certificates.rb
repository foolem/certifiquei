class CreateCertificates < ActiveRecord::Migration[6.0]
  def change
    create_table :certificates, id: :uuid do |t|
      t.string :title
      t.jsonb :metadata
      t.datetime :deleted_at
      t.uuid :user_id, index: true
      t.uuid :certificate_template_id, index: true

      t.timestamps
    end
  end
end
