class CreateStudentCertificate < ActiveRecord::Migration[6.0]
  def change
    create_table :student_certificates, id: :uuid do |t|
      t.string :resource_url
      t.datetime :seen_at
      t.datetime :deleted_at
      t.integer :workload
      t.integer :validations, default: 0

      t.timestamps
    end
  end
end
