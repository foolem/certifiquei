class CreateStudent < ActiveRecord::Migration[6.0]
  def change
    create_table :students, id: :uuid do |t|
      t.uuid :user_id, index: true
      t.uuid :event_id, index: true
      t.uuid :student_certificate_id, index: true

      t.boolean :delivered, index: true, default: false
      t.datetime :deleted_at

      t.timestamps
    end
  end
end
