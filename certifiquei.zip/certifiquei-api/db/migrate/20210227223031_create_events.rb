class CreateEvents < ActiveRecord::Migration[6.0]
  def change
    create_table :events, id: :uuid do |t|
      t.string :title
      t.string :description
      t.integer :status, default: 0
      t.datetime :deleted_at
      t.datetime :starts_at
      t.datetime :ends_at
      t.uuid :user_id, index: true
      t.uuid :certificate_id, index: true
      t.timestamps
    end
  end
end
