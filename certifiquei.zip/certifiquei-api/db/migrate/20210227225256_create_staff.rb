class CreateStaff < ActiveRecord::Migration[6.0]
  def change
    create_table :staffs, id: :uuid do |t|
      t.uuid :user_id, index: true
      t.uuid :event_id, index: true
      t.datetime :deleted_at

      t.timestamps
    end
  end
end
