class CreateActivities < ActiveRecord::Migration[6.0]
  def change
    create_table :activities, id: :uuid do |t|
      t.string :title, index: true
      t.text :description
      t.string :workload
      t.uuid :event_id, index: true

      t.timestamps
    end
  end
end
