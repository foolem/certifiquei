class CreateSecurities < ActiveRecord::Migration[6.0]
  def change
    create_table :securities, id: :uuid do |t|
      t.integer :kind

      t.uuid :event_id, index: true
      t.timestamps
    end
  end
end
