# Rails keys:

master.key 607f0888d3d22643ca1dad58bd0170b2
development.key 98c721767091e60affb307b9326394ad
production.key 1334e7da34e9d29a7dad12fa0a592673
test.key c5e59d6b965cc754f553871e6feceb9a

Coloque a master.key em app/config
Coloque as outras keys em app/config/credentials

# Testes

Para rodar os testes, execute o comando "rspec" da pasta do projeto

# Execução

rails s
