# frozen_string_literal: true

module Organizing
  module Activities
    class Edit
      attr_reader :params, :activity

      def initialize(params, activity)
        @params = params
        @activity = activity
      end

      def call
        ActiveRecord::Base.transaction do
          activity.update!(params)
          activity.reload
        end
      end
    end
  end
end
