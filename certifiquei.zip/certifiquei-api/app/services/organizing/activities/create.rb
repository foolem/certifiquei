# frozen_string_literal: true

module Organizing
  module Activities
    class Create
      def initialize(params, event)
        @params = params
        @event = event
      end

      def call
        ActiveRecord::Base.transaction do
          activity.save!
          activity
        end
      end

      private

      attr_reader :params, :event

      def activity
        @activity ||= event.activities.new(params)
      end
    end
  end
end
