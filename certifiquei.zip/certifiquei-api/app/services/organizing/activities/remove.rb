# frozen_string_literal: true

module Organizing
  module Activities
    class Remove
      attr_reader :activity

      def initialize(activity)
        @activity = activity
      end

      def call
        ActiveRecord::Base.transaction do
          activity.destroy!
          activity
        end
      end
    end
  end
end
