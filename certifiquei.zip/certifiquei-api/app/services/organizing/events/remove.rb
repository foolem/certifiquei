# frozen_string_literal: true

module Organizing
  module Events
    class Remove
      attr_reader :event

      def initialize(event)
        @event = event
      end

      def call
        ActiveRecord::Base.transaction do
          event.destroy!
          event
        end
      end
    end
  end
end
