# frozen_string_literal: true

module Organizing
  module Events
    class Create
      def initialize(params, user)
        @params = params
        @user = user
      end

      def call
        ActiveRecord::Base.transaction do
          build_certificate
          event.save!
          event
        end
      end

      private

      attr_reader :params, :user

      def event
        @event ||= Organizing::Event.new(event_params)
      end

      def event_params
        params.except(:certificate_template_id).merge(status: :draft)
      end

      def build_certificate
        event.certificate = certificate if certificate_params?
      end

      def certificate_params?
        (params[:certificate_id] || params[:certificate_template_id]).present?
      end

      def certificate
        if params[:certificate_id]
          Certifying::Certificate.find params[:certificate_id]
        else
          Certifying::Certificate.create(
            title: certificate_template.title,
            metadata: certificate_template.metadata,
            user_id: user.id,
            certificate_template_id: certificate_template.id
          )
        end
      end

      def certificate_template
        Certifying::CertificateTemplate.find params[:certificate_template_id]
      end
    end
  end
end
