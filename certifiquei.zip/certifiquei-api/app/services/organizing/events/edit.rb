# frozen_string_literal: true

module Organizing
  module Events
    class Edit
      attr_reader :params, :event

      def initialize(params, event)
        @params = params
        @event = event
      end

      def call
        ActiveRecord::Base.transaction do
          event.update!(event_params)
          save_certificate
          event.reload
        end
      end

      private

      def event_params
        params.except(:certificate_template_id)
      end

      def save_certificate
        event.certificate = certificate if certificate_params?
        event.save!
      end

      def certificate_params?
        (params[:certificate_id] || params[:certificate_template_id]).present?
      end

      def certificate
        if params[:certificate_id]
          Certifying::Certificate.find params[:certificate_id]
        else
          Certifying::Certificate.create(
            title: certificate_template.title,
            metadata: certificate_template.metadata,
            user_id: event.user.id,
            certificate_template_id: certificate_template.id
          )
        end
      end

      def certificate_template
        Certifying::CertificateTemplate.find params[:certificate_template_id]
      end
    end
  end
end
