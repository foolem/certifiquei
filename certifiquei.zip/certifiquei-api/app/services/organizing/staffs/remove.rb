# frozen_string_literal: true

module Organizing
  module Staffs
    class Remove
      attr_reader :staff

      def initialize(staff)
        @staff = staff
      end

      def call
        ActiveRecord::Base.transaction do
          staff.destroy!
          staff
        end
      end
    end
  end
end
