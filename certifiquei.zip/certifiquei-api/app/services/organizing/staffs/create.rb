# frozen_string_literal: true

module Organizing
  module Staffs
    class Create
      def initialize(params, event)
        @params = params
        @event = event
      end

      def call
        ActiveRecord::Base.transaction do
          staff.save!
          send_confirmation if user_by_email.present?
          staff
        end
      end

      private

      attr_reader :params, :event

      def staff
        @staff ||= Organizing::Staff.new(user: user, event: event)
      end

      def user
        @user ||= user_by_email || Auth::Staffs::Create.new(params, event).call
      end

      def user_by_email
        Auth::User.find_by(email: params[:email])
      end

      def send_confirmation
        ::UserMailer.confirm_email(user).deliver_later
      end
    end
  end
end
