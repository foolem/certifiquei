# frozen_string_literal: true

module Organizing
  module Students
    class Edit
      def initialize(params, student)
        @params = params
        @student = student
      end

      def call
        ActiveRecord::Base.transaction do
          edit_user
          student
        end
      end

      private

      attr_reader :params, :student

      def edit_user
        @edit_user ||= Auth::Users::Edit.new(params, student.user).call
      end
    end
  end
end
