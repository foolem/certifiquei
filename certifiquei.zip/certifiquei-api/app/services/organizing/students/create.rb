# frozen_string_literal: true

module Organizing
  module Students
    class Create
      def initialize(params, event)
        @params = params
        @event = event
      end

      def call
        ActiveRecord::Base.transaction do
          student.save!
          send_confirmation if user_by_email.present?
          student
        end
      end

      private

      attr_reader :params, :event

      def student
        @student ||= Organizing::Student.new(user: user, event: event)
      end

      def user
        @user ||= user_by_email || Auth::Students::Create.new(params, event).call
      end

      def user_by_email
        Auth::User.find_by(email: params[:email])
      end

      def send_confirmation
        ::UserMailer.confirm_email(user).deliver_later
      end
    end
  end
end
