# frozen_string_literal: true

module Organizing
  module Students
    class Remove
      attr_reader :student

      def initialize(student)
        @student = student
      end

      def call
        ActiveRecord::Base.transaction do
          student.destroy!
          student
        end
      end
    end
  end
end
