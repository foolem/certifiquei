# frozen_string_literal: true

module Organizing
  module Presences
    class Create
      def initialize(params, activity)
        @params = params
        @activity = activity
        @event = activity.event
      end

      def call
        ActiveRecord::Base.transaction do
          presence.save!
          presence
        end
      end

      private

      attr_reader :params, :activity, :event

      def presence
        @presence ||= activity.presences.new(presence_params)
      end

      def student
        @student ||= event.students.find_by(user_id: params[:user_id])
      end

      def presence_params
        params.except(:user_id).merge(
          student_id: student.id
        )
      end
    end
  end
end
