# frozen_string_literal: true

module Organizing
  module Presences
    class Remove
      attr_reader :presence

      def initialize(presence)
        @presence = presence
      end

      def call
        ActiveRecord::Base.transaction do
          presence.destroy!
          presence
        end
      end
    end
  end
end
