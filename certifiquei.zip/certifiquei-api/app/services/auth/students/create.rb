# frozen_string_literal: true

module Auth
  module Students
    class Create
      attr_reader :params, :event

      def initialize(params, event)
        @params = params
        @event = event
      end

      def call
        ActiveRecord::Base.transaction do
          user.save!
          send_confirmation
          user
        end
      end

      private

      def user
        @user ||= User.new(params.merge(password: params[:password] || password))
      end

      def password
        @password ||= SecureRandom.hex[0..8]
      end

      def send_confirmation
        ::UserMailer.confirm_email_with_password(user, password).deliver_later
      end
    end
  end
end
