# frozen_string_literal: true

module Auth
  module Users
    class ResetPassword
      attr_reader :resource

      def initialize(resource)
        @resource = resource
      end

      def call
        reset_password
        resource
      end

      private

      def reset_password
        resource.update!(password_token: SecureRandom.hex)
        UserMailer.reset_password(resource).deliver_later
      end
    end
  end
end
