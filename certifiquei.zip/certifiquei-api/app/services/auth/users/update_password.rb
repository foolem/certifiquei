# frozen_string_literal: true

module Auth
  module Users
    class UpdatePassword
      attr_reader :user, :password

      def initialize(user, password)
        @user = user
        @password = password
      end

      def call
        update_password
        user.reload
      end

      private

      def update_password
        user.update!(password: password, password_token: nil)
      end
    end
  end
end
