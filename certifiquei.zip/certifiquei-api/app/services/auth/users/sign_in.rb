# frozen_string_literal: true

module Auth
  module Users
    class SignIn
      attr_reader :params

      def initialize(params)
        @params = params
      end

      def call
        user if authenticate(params[:password])
      end

      private

      def user
        @user ||= User.find_by!(email: params[:email])
      end

      def authenticate(password)
        return false unless user.authenticate(password)

        user.update_attribute(:jwt, token)
      end

      def token
        @token ||= jwt_encoder({
                                 exp: (Time.now + 1.days).to_i,
                                 sub: user.id
                               })
      end

      def jwt_encoder(payload)
        JWTSerializer.encode(payload)
      end
    end
  end
end
