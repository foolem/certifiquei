# frozen_string_literal: true

module Auth
  module Users
    class SignUp
      attr_reader :params

      def initialize(params)
        @params = params
      end

      def call
        ActiveRecord::Base.transaction do
          user.save!
          send_confirmation
        end

        create_student
        user
      end

      private

      def user
        @user ||= if params[:event_id].present?
                    User.find_or_initialize_by(email: user_params[:email])
                  else
                    User.new(user_params)
                  end
      end

      def create_student
        return unless params[:event_id].present?

        Organizing::Students::Create.new(user_params, event).call
      end

      def event
        Organizing::Event.find(params[:event_id])
      end

      def user_params
        params.except(:event_id)
      end

      def send_confirmation
        ::UserMailer.confirm_email(user).deliver_later
      end
    end
  end
end
