# frozen_string_literal: true

module Auth
  module Users
    class Edit
      attr_reader :params, :user

      def initialize(params, user)
        @params = params
        @user = user
      end

      def call
        ActiveRecord::Base.transaction do
          user.update!(params)
          user
        end
      end
    end
  end
end
