# frozen_string_literal: true

module Auth
  module Users
    class Remove
      attr_reader :user

      def initialize(user)
        @user = user
      end

      def call
        ActiveRecord::Base.transaction do
          user.destroy!
          user
        end
      end
    end
  end
end
