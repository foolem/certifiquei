# frozen_string_literal: true

module Delivering
  class DistributeCertificates
    attr_reader :event

    def initialize(event)
      @event = event
    end

    def call
      deliveries.each do |delivery|
        event.students.each do |student|
          build_and_deliver(delivery, student)
        end
      end
      event.update!(status: :delivered)
    end

    private

    def deliveries
      event.deliveries
    end

    def build_and_deliver(delivery, student)
      Delivering::BuildAndDeliverJob.perform_later(delivery.kind, student.id)
    end
  end
end
