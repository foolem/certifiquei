# frozen_string_literal: true

module Delivering
  class ResendCertificate
    attr_reader :student

    def initialize(student)
      @student = student
    end

    def call
      deliveries.each do |delivery|
        build_and_deliver(delivery, student)
      end
    end

    private

    def deliveries
      student.event.deliveries
    end

    def build_and_deliver(delivery, student)
      Delivering::BuildAndDeliverJob.perform_later(delivery.kind, student.id)
    end
  end
end
