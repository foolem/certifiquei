# frozen_string_literal: true

module Delivering
  module Strategy
    class Base
      attr_reader :student

      def initialize(student_id)
        @student = Organizing::Student.find(student_id)
      end

      protected

      def certificate
        student.student_certificate
      end
    end
  end
end
