# frozen_string_literal: true

module Delivering
  module Strategy
    class Email < Base
      def call
        ::CertificateMailer.deliver_certificate(student).deliver_later
      end
    end
  end
end
