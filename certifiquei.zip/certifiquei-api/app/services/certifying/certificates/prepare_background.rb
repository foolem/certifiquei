# frozen_string_literal: true

module Certifying
  module Certificates
    class PrepareBackground
      attr_reader :payload, :page

      def initialize(payload, page)
        @payload = payload
        @page = page
      end

      def call
        set_background
      end

      private

      def page_template
        payload[:pages][page][:pageTemplate]
      end

      def background_image
        payload[:pages][0][:pageTemplate]['background']
      end

      def fields
        page_template['fields']
      end

      def set_background
        fields.unshift(background)
      end

      # rubocop:disable Metrics/MethodLength
      def background
        {
          id: 0,
          name: 'background',
          value: "<div><img src=\"#{background_image}\"style=\"width: 277mm; height: 190mm;\"/></div>",
          styles: {
            padding: '10mm',
            position: 'absolute'
          },
          position: {
            x: 0,
            y: 0
          }
        }
      end
      # rubocop:enable Metrics/MethodLength
    end
  end
end
