# frozen_string_literal: true

module Certifying
  module Certificates
    class Duplicate
      attr_reader :certificate, :user

      def initialize(certificate, user)
        @certificate = certificate
        @user = user
      end

      def call
        new_certificate.save
        new_certificate
      end

      private

      def new_certificate
        @new_certificate ||= Certifying::Certificate.new(
          title: certificate.title,
          metadata: certificate.metadata,
          certificate_template_id: certificate.certificate_template_id,
          user_id: user.id
        )
      end
    end
  end
end
