# frozen_string_literal: true

module Certifying
  module Certificates
    class Validate
      attr_reader :params

      def initialize(params)
        @params = params
      end

      def call
        student_certificate.update(validations: student_certificate.validations + 1)
        student_certificate
      end

      private

      def student_certificate
        if certificate_security
          certificate_security.student_certificate
        else
          certificate
        end
      end

      def certificate_security
        @certificate_security ||= CertificateSecurity.find_by(resource: params[:resource])
      end

      def certificate
        @certificate ||= StudentCertificate.find_by!(id: params[:resource])
      end
    end
  end
end
