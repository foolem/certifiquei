# frozen_string_literal: true

module Certifying
  module Certificates
    class Remove
      attr_reader :certificate

      def initialize(certificate)
        @certificate = certificate
      end

      def call
        ActiveRecord::Base.transaction do
          certificate.destroy!
          certificate
        end
      end
    end
  end
end
