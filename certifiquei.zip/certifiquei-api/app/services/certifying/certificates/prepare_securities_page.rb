# frozen_string_literal: true

module Certifying
  module Certificates
    class PrepareSecuritiesPage
      attr_reader :payload, :certificate_id

      def initialize(payload, certificate_id)
        @payload = payload
        @certificate_id = certificate_id
      end

      def call
        setup_page
        set_title
        set_verification
        set_bottom_text

        set_qrcode
      end

      private

      def setup_page
        payload[:pages].push({
                               pagePlaceholdersAndValues: [],
                               pageTemplate: {
                                 'fields' => [],
                                 background: 'transparent'
                               }
                             })
      end

      def first_page
        payload[:pages][0]
      end

      def second_page
        payload[:pages][1]
      end

      def first_fields
        first_page[:pageTemplate]['fields']
      end

      def second_fields
        second_page[:pageTemplate]['fields']
      end

      def set_title
        second_fields.push(title)
      end

      def set_verification
        second_fields.push(verification)
      end

      def set_qrcode
        second_fields.push(qrcode)
      end

      def set_bottom_text
        first_fields.push(bottom_text)
        second_fields.push(bottom_text)
      end

      def title
        {
          value: "<h2 style='text-align: center'>Certificados de segurança</h2>",
          styles: { width: '800px', position: 'absolute' },
          position: { x: 30, y: 60 }
        }
      end

      def verification
        {
          value: "<p>Para verificar a validade deste certificado, acesse o link abaixo:</p><p>#{validate_url}</p><p>Ou, se preferir, aponte a câmera de seu celular para o QRcode.</p>",
          styles: { width: '800px', position: 'absolute' },
          position: { x: 30, y: 420 }
        }
      end

      def qrcode
        {
          value: "<img src='#{qrcode_url}' style='width: 75px; height: 75px' />",
          styles: { width: '100px', position: 'absolute' },
          position: { x: 710, y: 480 }
        }
      end

      def bottom_text
        {
          value: "<p style='font-size: 20px'>Certificado: #{certificate_id} pode ser verificado acessando: #{validate_url}</p>",
          styles: { width: '800px', position: 'absolute' },
          position: { x: 25, y: 565 }
        }
      end

      def qrcode_url
        "https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=#{validate_url}"
      end

      def validate_url
        "#{::Settings.frontend_url}/validate?resource=#{certificate_id}"
      end
    end
  end
end
