# frozen_string_literal: true

module Certifying
  module Certificates
    class Create
      def initialize(params)
        @params = params
      end

      def call
        ActiveRecord::Base.transaction do
          certificate.save!
          certificate
        end
      end

      private

      attr_reader :params

      def certificate
        @certificate ||= Certifying::Certificate.new(params)
      end
    end
  end
end
