# frozen_string_literal: true

module Certifying
  module Certificates
    class Edit
      attr_reader :params, :certificate

      def initialize(params, certificate)
        @params = params
        @certificate = certificate
      end

      def call
        ActiveRecord::Base.transaction do
          certificate.update!(params)
          certificate
        end
      end
    end
  end
end
