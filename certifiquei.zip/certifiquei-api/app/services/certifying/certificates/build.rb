# frozen_string_literal: true

# rubocop:disable Metrics/ClassLength
module Certifying
  module Certificates
    class Build
      attr_reader :student, :event, :certificate_fields, :payload

      PLACEHOLDER_MAPPING = {
        event: {
          '[NOME_DO_EVENTO]' => :title
        },
        workload: {
          '[TOTAL_DE_HORAS]' => :workload_count
        },
        student: {
          '[NOME_DO_ALUNO]' => :full_name,
          '[GRR_DO_ALUNO]' => :grr
        },
        custom: {
          '[DATA_DE_EMISSAO]' => Time.zone.now.strftime('%d/%m/%Y - %H:%M')
        }
      }.freeze

      def initialize(student)
        @student = student
        @event = student.event
        @certificate_fields = event.certificate.metadata['fields']
        @payload = prepare_payload
      end

      def call
        prepare_background(0)
        find_placeholders
        assign_student_certificate
        prepare_second_page
        create_securities
        response
      end

      private

      def find_placeholders
        find_event_placeholders
        find_workload_placeholders
        find_student_placeholders
        find_custom_placeholders
      end

      def find_event_placeholders
        placeholders(:event, event)
      end

      def find_workload_placeholders
        placeholders(:workload, workload_hours)
      end

      def find_student_placeholders
        placeholders(:student, student)
      end

      def find_custom_placeholders
        placeholders(:custom, nil)
      end

      # rubocop:disable Metrics/AbcSize
      # rubocop:disable Lint/UselessAssignment
      def workload_hours
        workload_hours = student.presences.map { |pre| pre.activity.workload.to_time.hour }.reduce(:+) || 0
        workload_minutes = student.presences.map { |pre| pre.activity.workload.to_time.min }.reduce(:+) || 0
        workload_hours += workload_minutes / 60
      end
      # rubocop:enable Lint/UselessAssignment
      # rubocop:enable Metrics/AbcSize

      # rubocop:disable Metrics/AbcSize
      # rubocop:disable Metrics/MethodLength
      # rubocop:disable Metrics/CyclomaticComplexity
      def placeholders(key, resource)
        PLACEHOLDER_MAPPING[key].each_key do |placeholder|
          has_placeholder = certificate_fields.find { |a| a['value']&.include? placeholder }
          next unless has_placeholder

          field = PLACEHOLDER_MAPPING[key][placeholder]
          value = case key
                  when :student
                    resource.user.send(field.to_sym)
                  when :event
                    resource.send(field.to_sym)
                  when :workload
                    resource
                  when :custom
                    field
                  end
          obj = { placeholder: placeholder, value: value }
          payload[:pages][0][:pagePlaceholdersAndValues].push obj
        end
      end
      # rubocop:enable Metrics/CyclomaticComplexity
      # rubocop:enable Metrics/AbcSize
      # rubocop:enable Metrics/MethodLength

      def student_certificate
        @student_certificate ||= Certifying::StudentCertificate.create

        student.update!(student_certificate: @student_certificate) if student.student_certificate.blank?
        @student_certificate
      end

      def prepare_payload
        {
          pages: [
            {
              pagePlaceholdersAndValues: [],
              pageTemplate: @event.certificate.metadata
            }
          ]
        }
      end

      def prepare_background(page)
        PrepareBackground.new(payload, page).call
      end

      def prepare_second_page
        PrepareSecuritiesPage.new(payload, student_certificate.id).call
        prepare_background(1)
      end

      def assign_student_certificate
        student.update(student_certificate_id: student_certificate.id)
      end

      def create_securities
        event.securities.each do |security|
          certificate_security = Securing::SecureCertificate.new(security, student_certificate, workload_hours).call
          assign_strategy(security.kind).new(payload, certificate_security).call
        end
      end

      def assign_strategy(kind)
        case kind.to_sym
        when :internal
          AssignSecurity::Internal
        when :blockchain
          AssignSecurity::Blockchain
        end
      end

      def request
        @request ||= HTTP.post(::Settings.certificate_url, json: payload)
      end

      def perform
        res = request.parse

        if res['pdfUrl'].blank?
          raise(
            StandardError,
            I18n.t('certifying.build_unsuccessful')
          )
        end

        student_certificate.update(resource_url: res['pdfUrl'])
      end

      def response
        perform
        { pdfUrl: student_certificate.resource_url }
      end
    end
  end
end
# rubocop:enable Metrics/ClassLength
