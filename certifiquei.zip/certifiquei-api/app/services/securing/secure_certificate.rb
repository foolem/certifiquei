# frozen_string_literal: true

module Securing
  class SecureCertificate
    attr_reader :security, :student_certificate, :workload_hours

    def initialize(security, student_certificate, workload_hours)
      @security = security
      @student_certificate = student_certificate
      @workload_hours = workload_hours
    end

    def call
      strategy.new(student_certificate, security, workload_hours).call
    end

    private

    def strategy
      case security.kind.to_sym
      when :internal
        Strategy::Internal
      when :blockchain
        Strategy::Blockchain
      end
    end
  end
end
