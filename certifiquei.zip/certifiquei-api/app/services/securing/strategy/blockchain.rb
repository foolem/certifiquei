# frozen_string_literal: true

module Securing
  module Strategy
    class Blockchain
      attr_reader :student_certificate, :security, :student,
                  :event, :workload_hours

      def initialize(student_certificate, security, workload_hours)
        @student_certificate = student_certificate
        @security = security
        @student = student_certificate.student
        @event = student.event
        @workload_hours = workload_hours
      end

      def call
        student_certificate.certificate_securities.create!(
          resource: transaction,
          security: security
        )
      end

      private

      def transaction
        request.parse['hash']
      end

      def payload
        {
          content: "#{student_start_info}#{student_end_info}",
          key: student_certificate.id
        }
      end

      def request
        HTTP.headers('x-token': jwt).post(eth_url, json: payload)
      end

      def jwt
        JWT.encode 'yolo', Rails.application.credentials.eth_jwt_secret
      end

      def eth_url
        "#{::Settings.eth_url}/set"
      end

      def student_start_info
        "#{student.full_name}|#{student.grr}|#{student.email}"
      end

      def student_end_info
        "|#{event.title}|#{event.start_date}-#{event.end_date}|#{workload_hours}h"
      end
    end
  end
end
