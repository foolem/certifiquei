# frozen_string_literal: true

module Securing
  module Strategy
    class Internal
      attr_reader :student_certificate, :security

      def initialize(student_certificate, security, _workload_hours)
        @student_certificate = student_certificate
        @security = security
      end

      def call
        ActiveRecord::Base.transaction do
          student_certificate.certificate_securities.create!(
            resource: resource,
            security: security
          )
        end
      end

      private

      def resource
        SecureRandom.hex[0..10]
      end
    end
  end
end
