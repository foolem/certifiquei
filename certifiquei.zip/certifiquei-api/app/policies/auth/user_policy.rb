# frozen_string_literal: true

module Auth
  class UserPolicy < ApplicationPolicy
    class Scope < Scope
      def resolve
        user_scope = scope

        user_scope.order(created_at: :desc)
      end
    end

    def index?
      true
    end
  end
end
