# frozen_string_literal: true

module Organizing
  class PresencePolicy < ApplicationPolicy
    class Scope < Scope
      def resolve
        if user.manager?
          scope.where(activity_id: user.activities.pluck(:id))
               .order(created_at: :desc)
        else
          scope.where(staff_id: user.staffs.pluck(:id))
               .order(created_at: :desc)
        end
      end
    end

    def create?
      if valid_create?
        true
      else
        raise StandardError, I18n.t('pundit.presence_policy.create?') unless valid_create?
      end
    end

    def destroy?
      if valid_destroy?
        true
      else
        raise StandardError, I18n.t('pundit.presence_policy.destroy?') unless valid_destroy?
      end
    end

    private

    def valid_create?
      record.event.active? && (user_manages_event? || user_staff?)
    end

    def valid_destroy?
      record.activity.event.active? && (user_manages_event? || user_staff?)
    end

    def user_manages_event?
      user.manager? && user.events.find_by(id: event_id).present?
    end

    def user_staff?
      user.regular? && user.staffs.find_by(event_id: event_id).present?
    end

    def event_id
      record.try(:event_id) || record.activity.event_id
    end
  end
end
