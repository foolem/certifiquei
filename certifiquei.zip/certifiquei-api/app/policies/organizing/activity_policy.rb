# frozen_string_literal: true

module Organizing
  class ActivityPolicy < ApplicationPolicy
    class Scope < Scope
      def resolve
        if user.manager?
          scope.where(event_id: user.events.pluck(:id))
               .order(created_at: :desc)
        else
          scope.where(event_id: user.staffs.pluck(:event_id))
               .order(created_at: :desc)
        end
      end
    end

    def create?
      true
    end

    def update?
      true
    end

    def destroy?
      true
    end
  end
end
