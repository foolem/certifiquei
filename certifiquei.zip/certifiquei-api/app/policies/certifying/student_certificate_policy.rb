# frozen_string_literal: true

module Certifying
  class StudentCertificatePolicy < ApplicationPolicy
    class Scope < Scope
      def resolve
        scope.order(created_at: :desc)
      end
    end
  end
end
