# frozen_string_literal: true

module Certifying
  class CertificateTemplatePolicy < ApplicationPolicy
    class Scope < Scope
      def resolve
        scope.order(created_at: :desc)
      end
    end

    def index?
      true
    end

    def create?
      true
    end

    def update?
      true
    end

    def destroy?
      true
    end
  end
end
