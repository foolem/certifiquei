# frozen_string_literal: true

module Certifying
  class CertificateSecurity < ApplicationRecord
    default_scope { order(created_at: :desc) }

    belongs_to :security, class_name: 'Securing::Security'
    belongs_to :student_certificate, class_name: 'Certifying::StudentCertificate'

    validates :resource, presence: true
  end
end
