# frozen_string_literal: true

module Certifying
  class Certificate < ApplicationRecord
    default_scope { order(created_at: :desc) }

    acts_as_paranoid

    belongs_to :certificate_template, class_name: 'Certifying::CertificateTemplate'
    belongs_to :user, class_name: 'Auth::User'
    has_many :events, class_name: 'Organizing::Event'
    has_many :student_certificates, class_name: 'Organizing::Student'

    validates :title, presence: true
    validates :metadata, presence: true
  end
end
