# frozen_string_literal: true

module Certifying
  class StudentCertificate < ApplicationRecord
    default_scope { order(created_at: :desc) }

    acts_as_paranoid

    has_many :certificate_securities, dependent: :destroy, class_name: 'Certifying::CertificateSecurity'
    has_one :student, class_name: 'Organizing::Student'

    before_destroy :delete_from_s3

    delegate :event, to: :student

    private

    def delete_from_s3
      Certifying::RemoveCertificateJob.perform_later(pdf_filename) if resource_url
    end

    def pdf_filename
      resource_url.split('amazonaws.com/').last
    end
  end
end
