# frozen_string_literal: true

module Certifying
  class CertificateTemplate < ApplicationRecord
    default_scope { order(created_at: :desc) }

    has_many :certificates, class_name: 'Certifying::Certificate'

    validates :title, presence: true
    validates :metadata, presence: true
  end
end
