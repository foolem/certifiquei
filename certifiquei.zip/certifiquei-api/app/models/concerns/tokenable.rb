# frozen_string_literal: true

module Tokenable
  extend ActiveSupport::Concern

  included do
    after_create :set_jwt
  end

  private

  def set_jwt
    update_attribute(:jwt,
                     JWTSerializer.encode({
                                            exp: (Time.now + 3.days).to_i,
                                            sub: id
                                          }))
  end
end
