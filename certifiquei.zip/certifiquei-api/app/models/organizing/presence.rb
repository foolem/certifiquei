# frozen_string_literal: true

module Organizing
  class Presence < ApplicationRecord
    belongs_to :student
    belongs_to :staff, optional: true
    belongs_to :activity

    validates :student, uniqueness: { scope: :activity_id }
  end
end
