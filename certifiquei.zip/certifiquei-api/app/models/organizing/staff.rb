# frozen_string_literal: true

module Organizing
  class Staff < ApplicationRecord
    acts_as_paranoid

    belongs_to :user, class_name: 'Auth::User'
    belongs_to :event, class_name: 'Organizing::Event'
    has_many :presences, class_name: 'Organizing::Presence'

    delegate :first_name, :last_name, :email, :grr, to: :user
  end
end
