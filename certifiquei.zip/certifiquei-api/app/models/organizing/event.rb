# frozen_string_literal: true

# == Schema Information
#
# Table name: events
#
#  id                              :uuid             not null, primary key
#  deleted_at                      :datetime
#  description                     :string
#  name                            :string
#  paid                            :boolean          default(FALSE)
#  status                          :integer
#  created_at                      :datetime         not null
#  updated_at                      :datetime         not null
#  address_id                      :uuid
#  certificate_id                  :uuid
#  deliver_job_id                  :string
#  user_id                         :uuid
#
# Indexes
#
#  index_events_on_address_id      (address_id)
#  index_events_on_certificate_id  (certificate_id)
#  index_events_on_deleted_at      (deleted_at)
#  index_events_on_name            (name)
#  index_events_on_status          (status)
#  index_events_on_user_id         (user_id)
#
module Organizing
  class Event < ApplicationRecord
    acts_as_paranoid

    ransacker :status, formatter: proc { |v| statuses[v] }

    belongs_to :user, class_name: 'Auth::User'
    belongs_to :certificate, class_name: 'Certifying::Certificate'
    has_many :securities, class_name: 'Securing::Security', dependent: :destroy
    has_many :students, class_name: 'Organizing::Student', dependent: :destroy
    has_many :activities, class_name: 'Organizing::Activity', dependent: :destroy
    has_many :deliveries, class_name: 'Delivering::Delivery', dependent: :destroy

    enum status: { draft: 0, active: 1, finished: 2, delivered: 3 }

    validates :title, presence: true

    accepts_nested_attributes_for :activities, reject_if: :all_blank, allow_destroy: true
    accepts_nested_attributes_for :deliveries, reject_if: :all_blank, allow_destroy: true
    accepts_nested_attributes_for :securities, reject_if: :all_blank, allow_destroy: true

    def start_date
      starts_at&.strftime('%d/%m/%Y')
    end

    def end_date
      ends_at&.strftime('%d/%m/%Y')
    end

    def all_delivered?
      students.where(delivered: false).count.zero?
    end
  end
end
