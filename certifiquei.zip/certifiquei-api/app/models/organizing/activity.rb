# frozen_string_literal: true

module Organizing
  class Activity < ApplicationRecord
    belongs_to :event
    has_many :presences

    validates :title, presence: true
    validates :workload, presence: true
  end
end
