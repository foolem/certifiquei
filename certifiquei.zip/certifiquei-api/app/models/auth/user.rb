# frozen_string_literal: true

module Auth
  class User < ApplicationRecord
    default_scope { order(created_at: :desc) }

    include Tokenable

    has_secure_password

    enum user_type: { regular: 0, manager: 1 }

    has_many :events, class_name: 'Organizing::Event'
    has_many :activities, class_name: 'Organizing::Activity', through: :events
    has_many :students, class_name: 'Organizing::Student'
    has_many :staffs, class_name: 'Organizing::Staff'
    has_many :student_events, class_name: 'Organizing::Event', through: :students, source: :event
    has_many :staff_events, class_name: 'Organizing::Staff', through: :staffs, source: :event
    has_many :student_certificates, class_name: 'Certifying::StudentCertificate', through: :students

    validates :email, presence: true, uniqueness: true, format: { with: URI::MailTo::EMAIL_REGEXP }
    validates :first_name, presence: true
    validates :last_name, presence: true
    validates :password_digest, presence: true

    def student?
      students.present?
    end

    def staff?
      staffs.present?
    end

    def full_name
      "#{first_name} #{last_name}"
    end
  end
end
