# frozen_string_literal: true

module Securing
  class Security < ApplicationRecord
    enum kind: { internal: 0, blockchain: 1 }

    belongs_to :event, class_name: 'Organizing::Event'
    has_many :certificate_securities, class_name: 'Certifying::CertificateSecurity'

    validates :kind, presence: true
  end
end
