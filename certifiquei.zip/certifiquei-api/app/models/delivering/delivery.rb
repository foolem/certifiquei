# frozen_string_literal: true

module Delivering
  class Delivery < ApplicationRecord
    enum kind: { email: 1 }

    belongs_to :event, class_name: 'Organizing::Event'

    validates :kind, presence: true
  end
end
