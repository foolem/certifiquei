# frozen_string_literal: true

module Certifying
  class RemoveCertificateJob < ApplicationJob
    queue_as :certifying

    def perform(pdf_filename)
      s3_certificates.object(pdf_filename).delete
    end
  end
end
