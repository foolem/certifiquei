# frozen_string_literal: true

module Certifying
  class BuildCertificateJob < ApplicationJob
    queue_as :certifying

    def perform(student_id)
      build_certificate(student_id) unless certificate?
    end

    private

    def certificate?
      student.student_certificate.present?
    end

    def build_certificate(student_id)
      Certifying::BuildCertificate.new(student_id).call
    end
  end
end
