# frozen_string_literal: true

module Certifying
  class BuildCertificatesJob < ApplicationJob
    queue_as :certifying

    def perform(event_id)
      event = Organizing::Event.find event_id
      event.students.each do |student|
        BuildCertificateJob.perform_later(student.id)
      end
    end
  end
end
