# frozen_string_literal: true

module Delivering
  class BuildAndDeliverJob < ApplicationJob
    queue_as :delivering

    def perform(delivery_kind, student_id)
      @student = Organizing::Student.find(student_id)

      build_certificate(@student) unless certificate?
      deliver_strategy(delivery_kind).new(student_id).call
    rescue StandardError
      send_failure_mail
    end

    private

    attr_reader :student

    def certificate?
      certificate.present? && certificate.resource_url.present?
    end

    def certificate
      @certificate ||= student.student_certificate
    end

    def build_certificate(student_id)
      Certifying::Certificates::Build.new(student_id).call
    end

    def deliver_strategy(kind)
      case kind.to_sym
      when :email
        Delivering::Strategy::Email
      end
    end

    def send_failure_mail
      ::EventMailer.delivery_failure(student).deliver_later
    end
  end
end
