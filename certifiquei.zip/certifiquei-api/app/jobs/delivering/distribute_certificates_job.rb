# frozen_string_literal: true

module Delivering
  class DistributeCertificatesJob < ApplicationJob
    queue_as :delivering

    def perform(event_id)
      event = Organizing::Event.find(event_id)
      DistributeCertificates.new(event).call
    end
  end
end
