# frozen_string_literal: true

module Delivering
  class ResendCertificatesJob < ApplicationJob
    queue_as :delivering

    def perform(event_id)
      event = Organizing::Event.find(event_id)
      event.students.where(delivered: false).each do |student|
        ResendCertificate.new(student.id).call
      end
    end
  end
end
