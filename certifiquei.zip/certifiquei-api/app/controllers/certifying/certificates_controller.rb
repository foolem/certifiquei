# frozen_string_literal: true

module Certifying
  class CertificatesController < ApplicationController
    before_action :authenticate_user!, except: [:validate]
    before_action :set_certificate, only: %i[update destroy show duplicate]

    def index
      authorize(:certificate, :index?, policy_class: CertificatePolicy)

      render json: CertificateBlueprint.render(certificates, root: :data, meta: {
                                                 pagination: {
                                                   total: certificates.total_count,
                                                   current: certificates.current_page,
                                                   page_count: certificates.total_pages
                                                 }
                                               })
    end

    def show
      render json: CertificateBlueprint.render(@certificate, root: :data)
    end

    def create
      authorize(:certificate, :create?, policy_class: CertificatePolicy)

      data = Certifying::Certificates::Create.new(certificate_params).call

      render json: CertificateBlueprint.render(data, root: :data),
             status: :created
    end

    def update
      authorize(:certificate, :update?, policy_class: CertificatePolicy)

      data = Certifying::Certificates::Edit.new(certificate_params, @certificate).call

      render json: CertificateBlueprint.render(data, root: :data)
    end

    def destroy
      authorize(:certificate, :destroy?, policy_class: CertificatePolicy)

      Certifying::Certificates::Remove.new(@certificate).call

      render json: CertificateBlueprint.render(@certificate, root: :data)
    end

    def duplicate
      resource = Certifying::Certificates::Duplicate.new(@certificate, current_user).call

      render json: Certifying::CertificateBlueprint.render(resource, root: :data)
    end

    def validate
      resource = Certifying::Certificates::Validate.new(validate_params).call

      render json: Certifying::StudentCertificateBlueprint.render(resource, root: :data)
    end

    private

    def set_certificate
      @certificate = policy_scope(Certificate).find(params[:certificate_id] || params[:id])
    end

    def certificate_params
      params.permit(:certificate_template_id, :title, metadata: {}).merge(
        user_id: current_user.id
      )
    end

    def validate_params
      params.permit(:kind, :resource)
    end

    def certificates
      @certificates ||= policy_scope(Certificate).ransack(params)
                                                 .result
                                                 .page(params[:page])
    end
  end
end
