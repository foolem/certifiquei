# frozen_string_literal: true

module Certifying
  class CertificateTemplatesController < ApplicationController
    before_action :authenticate_user!
    before_action :set_certificate_template, only: %i[show]

    def index
      authorize(:certificate_template, :index?, policy_class: CertificateTemplatePolicy)

      render json: CertificateTemplateBlueprint.render(certificate_templates, root: :data, meta: {
                                                         pagination: {
                                                           total: certificate_templates.total_count,
                                                           current: certificate_templates.current_page
                                                         }
                                                       })
    end

    def show
      render json: CertificateTemplateBlueprint.render(@certificate_template, root: :data)
    end

    private

    def set_certificate_template
      @certificate_template = policy_scope(CertificateTemplate).find(params[:certificate_template_id] || params[:id])
    end

    def certificate_templates
      @certificate_templates ||= policy_scope(CertificateTemplate).ransack(params)
                                                                  .result
                                                                  .page(params[:page])
    end
  end
end
