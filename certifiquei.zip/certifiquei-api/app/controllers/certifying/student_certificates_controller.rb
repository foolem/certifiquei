# frozen_string_literal: true

module Certifying
  class StudentCertificatesController < ApplicationController
    before_action :authenticate_user!, except: [:set_seen]
    before_action :set_student_certificate, only: [:set_seen]

    def index
      render json: StudentCertificateBlueprint.render(student_certificates, root: :data, meta: {
                                                        pagination: {
                                                          total: student_certificates.total_count,
                                                          current: student_certificates.current_page
                                                        }
                                                      })
    end

    def set_seen
      @student_certificate.update(seen_at: Time.now)
      redirect_to redirect_url
    end

    private

    def redirect_url
      if params[:print]
        @student_certificate.print_resource_url
      else
        @student_certificate.resource_url
      end
    end

    def set_student_certificate
      @student_certificate = Certifying::StudentCertificate.find(
        params[:id] || params[:student_certificate_id]
      )
    end

    def student_certificates
      @student_certificates ||= current_user.student_certificates.ransack(params)
                                            .result
                                            .page(params[:page])
    end
  end
end
