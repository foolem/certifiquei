# frozen_string_literal: true

class ApplicationController < ActionController::API
  include Pundit

  def authenticate_user!
    return if jwt_decoder && current_user.present?

    render json: { error: I18n.t('auth.unauthorized') }, status: :unauthorized
  rescue StandardError
    render json: { error: I18n.t('auth.unauthorized') }, status: :unauthorized
  end

  def current_user
    @current_user ||= Auth::User.find_by(id: jwt_decoder['sub']) if valid_jwt?
  end

  def jwt_token
    params[:jwt] || request.headers['Authorization']&.gsub(/^Bearer /, '')
  end

  def jwt_decoder
    JWTSerializer.decode(jwt_token)
  end

  def valid_jwt?
    jwt_token.present?
  end

  def pundit_user
    current_user if valid_jwt?
  rescue JWT::ExpiredSignature
    nil
  end

  rescue_from StandardError do |error|
    render json: { error: error.to_s }, status: :unprocessable_entity
  end

  rescue_from ActionController::BadRequest do
    render json: { error: 'Bad request' }, status: :bad_request
  end

  rescue_from ActiveRecord::RecordNotFound do
    render json: { error: I18n.t('activerecord.exceptions.not_found') }, status: :not_found
  end

  rescue_from ActiveRecord::RecordInvalid do |error|
    render json: { error: error.to_s }, status: :unprocessable_entity
  end

  rescue_from JWT::DecodeError do
    render json: { error: I18n.t('auth.unauthorized') }, status: :unauthorized
  end
end
