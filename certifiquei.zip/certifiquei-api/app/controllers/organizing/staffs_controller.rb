# frozen_string_literal: true

module Organizing
  class StaffsController < ApplicationController
    before_action :authenticate_user!
    before_action :set_event, only: [:create]
    before_action :set_staff, only: %i[destroy]

    def index
      render json: StaffBlueprint.render(staffs, root: :data, meta: {
                                           pagination: {
                                             total: staffs.total_count,
                                             current: staffs.current_page,
                                             page_count: staffs.total_pages
                                           }
                                         })
    end

    def all
      render json: StaffBlueprint.render(Staff.distinct(:user_id), root: :data)
    end

    def create
      authorize(:staff, :create?, policy_class: StaffPolicy)

      data = Organizing::Staffs::Create.new(staff_params, @event).call

      render json: StaffBlueprint.render(data, root: :data), status: :created
    end

    def destroy
      authorize(:staff, :destroy?, policy_class: StaffPolicy)

      Organizing::Staffs::Remove.new(@staff).call

      render json: StaffBlueprint.render(@staff, root: :data)
    end

    private

    def staffs
      @staffs ||= policy_scope(Staff).ransack(params)
                                     .result
                                     .page(params[:page])
    end

    def set_staff
      @staff = policy_scope(Staff).find(params[:staff_id] || params[:id])
    end

    def set_event
      @event = policy_scope(Event).find(params[:event_id] || params[:id])
    end

    def staff_params
      params.permit(:first_name, :last_name, :email, :grr)
    end
  end
end
