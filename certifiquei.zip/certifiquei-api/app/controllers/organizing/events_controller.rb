# frozen_string_literal: true

module Organizing
  class EventsController < ApplicationController
    before_action :authenticate_user!, except: [:show]
    before_action :set_event, only: %i[update destroy show distribute_certificates]

    def index
      render json: EventBlueprint.render(events, root: :data, meta: {
                                           pagination: {
                                             total: events.total_count,
                                             current: events.current_page,
                                             page_count: events.total_pages
                                           }
                                         })
    end

    def all
      render json: EventBlueprint.render(Event.all, root: :data)
    end

    def create
      authorize(:event, :create?, policy_class: EventPolicy)

      data = Organizing::Events::Create.new(new_event_params, current_user).call

      render json: EventBlueprint.render(data, root: :data, view: :show)
    end

    def update
      authorize(:event, :update?, policy_class: EventPolicy)

      data = Organizing::Events::Edit.new(event_params, @event).call

      render json: EventBlueprint.render(data, root: :data, view: :show)
    end

    def destroy
      authorize(:event, :destroy?, policy_class: EventPolicy)

      Organizing::Events::Remove.new(@event).call

      render json: EventBlueprint.render(@event, root: :data)
    end

    def distribute_certificates
      authorize(@event, :distribute_certificates?, policy_class: EventPolicy)

      Delivering::DistributeCertificatesJob.perform_later(@event.id)

      render json: EventBlueprint.render(@event, root: :data)
    end

    def show
      render json: EventBlueprint.render(@event, root: :data, view: :show)
    end

    private

    def set_event
      @event = policy_scope(Event).find(params[:event_id] || params[:id])
    end

    def events
      @events ||= policy_scope(Event).ransack(params)
                                     .result
                                     .page(params[:page])
    end

    def new_event_params
      event_params.merge(user_id: current_user.id)
    end

    def event_params
      params.permit(:title, :description, :status, :starts_at, :ends_at,
                    :certificate_id, :certificate_template_id,
                    deliveries_attributes: %i[_destroy id kind],
                    securities_attributes: %i[_destroy id kind],
                    activities_attributes: %i[_destroy id title description workload])
    end
  end
end
