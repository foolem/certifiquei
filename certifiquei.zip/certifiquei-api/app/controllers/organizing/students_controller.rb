# frozen_string_literal: true

module Organizing
  class StudentsController < ApplicationController
    before_action :authenticate_user!
    before_action :set_event, except: %i[all index show deliver_certificate]
    before_action :set_student, only: %i[update destroy show deliver_certificate]

    def index
      authorize(:student, :index?, policy_class: StudentPolicy)

      render json: StudentBlueprint.render(students, root: :data, meta: {
                                             pagination: {
                                               total: students.total_count,
                                               current: students.current_page,
                                               page_count: students.total_pages
                                             }
                                           })
    end

    def all
      render json: StudentBlueprint.render(Student.distinct(:user_id), root: :data)
    end

    def create
      authorize(:student, :create?, policy_class: StudentPolicy)

      data = Organizing::Students::Create.new(user_params, @event).call

      render json: StudentBlueprint.render(data, root: :data), status: :created
    end

    def update
      authorize(:student, :update?, policy_class: StudentPolicy)

      data = Organizing::Students::Edit.new(user_params, @student).call

      render json: StudentBlueprint.render(data, root: :data)
    end

    def destroy
      authorize(:student, :destroy?, policy_class: StudentPolicy)

      Organizing::Students::Remove.new(@student).call

      render json: StudentBlueprint.render(@student, root: :data)
    end

    def show
      authorize(:student, :show?, policy_class: StudentPolicy)

      render json: StudentBlueprint.render(@student, root: :data)
    end

    def deliver_certificate
      Delivering::BuildAndDeliverJob.perform_later(:email, @student.id)

      render json: { data: { success: true } }
    end

    private

    def set_event
      @event = policy_scope(Event).find(params[:event_id] || params[:id])
    end

    def set_student
      @student = policy_scope(Student).find(params[:student_id] || params[:id])
    end

    def students
      @students ||= policy_scope(Student).ransack(params)
                                         .result
                                         .page(params[:page])
    end

    def user_params
      params.permit(:first_name, :last_name, :email, :grr)
    end
  end
end
