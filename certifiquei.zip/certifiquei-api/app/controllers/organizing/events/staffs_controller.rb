# frozen_string_literal: true

module Organizing
  module Events
    class StaffsController < ApplicationController
      before_action :authenticate_user!
      before_action :set_event
      before_action :set_staff, only: %i[show]

      def index
        render json: StaffBlueprint.render(staffs, root: :data, meta: {
                                             pagination: {
                                               total: staffs.total_count,
                                               current: staffs.current_page,
                                               page_count: staffs.total_pages
                                             }
                                           })
      end

      def show
        render json: StaffBlueprint.render(@staff, root: :data)
      end

      private

      def set_event
        @event = policy_scope(Organizing::Event).find(params[:event_id] || params[:id])
      end

      def set_staff
        @staff = policy_scope(Organizing::Staff).find(params[:staff_id] || params[:id])
      end

      def staffs
        @staffs ||= policy_scope(Organizing::Staff).ransack(params)
                                                   .result
                                                   .page(params[:page])
      end

      def staff_params
        params.permit(:first_name, :last_name, :email, :grr)
      end
    end
  end
end
