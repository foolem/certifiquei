# frozen_string_literal: true

module Organizing
  class PresencesController < ApplicationController
    before_action :authenticate_user!
    before_action :set_activity
    before_action :set_presence, only: %i[destroy show]

    def index
      render json: PresenceBlueprint.render(presences, root: :data, meta: {
                                              pagination: {
                                                total: presences.total_count,
                                                current: presences.current_page,
                                                page_count: presences.total_pages
                                              }
                                            })
    end

    def create
      authorize(@activity, :create?, policy_class: PresencePolicy)

      data = Organizing::Presences::Create.new(presence_params, @activity).call

      render json: PresenceBlueprint.render(data, root: :data)
    end

    def destroy
      authorize(@presence, :destroy?, policy_class: PresencePolicy)

      Organizing::Presences::Remove.new(@presence).call

      render json: PresenceBlueprint.render(@presence, root: :data)
    end

    def show
      render json: PresenceBlueprint.render(@presence, root: :data)
    end

    private

    def set_presence
      @presence = @activity.presences.find(params[:presence_id] || params[:id])
    end

    def set_activity
      @activity = policy_scope(Activity).find(params[:activity_id])
    end

    def presences
      @presences ||= @activity.presences.ransack(params)
                              .result
                              .page(params[:page])
    end

    def presence_params
      params.permit(:activity_id, :user_id, :staff_id)
    end
  end
end
