# frozen_string_literal: true

module Organizing
  class ActivitiesController < ApplicationController
    before_action :authenticate_user!
    before_action :set_activity, only: %i[update destroy show]
    before_action :set_event, only: %i[create]

    def index
      render json: ActivityBlueprint.render(activities, root: :data, meta: {
                                              pagination: {
                                                total: activities.total_count,
                                                current: activities.current_page,
                                                page_count: activities.total_pages
                                              }
                                            })
    end

    def all
      render json: ActivityBlueprint.render(Activity.all, root: :data)
    end

    def create
      authorize(:activity, :create?, policy_class: ActivityPolicy)

      data = Organizing::Activities::Create.new(activity_params, @event).call

      render json: ActivityBlueprint.render(data, root: :data, view: :show)
    end

    def update
      authorize(:activity, :update?, policy_class: ActivityPolicy)

      data = Organizing::Activities::Edit.new(activity_params, @activity).call

      render json: ActivityBlueprint.render(data, root: :data, view: :show)
    end

    def destroy
      authorize(:activity, :destroy?, policy_class: ActivityPolicy)

      Organizing::Activities::Remove.new(@activity).call

      render json: ActivityBlueprint.render(@activity, root: :data)
    end

    def show
      render json: ActivityBlueprint.render(@activity, root: :data, view: :show)
    end

    private

    def set_activity
      @activity = policy_scope(Activity).find(params[:activity_id] || params[:id])
    end

    def set_event
      @event = policy_scope(Event).find(params[:event_id] || params[:id])
    end

    def activities
      @activities ||= policy_scope(Activity).ransack(params)
                                            .result
                                            .page(params[:page])
    end

    def activity_params
      params.permit(:title, :description, :workload, :event_id)
    end
  end
end
