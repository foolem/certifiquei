# frozen_string_literal: true

module Auth
  class SessionsController < ApplicationController
    def create
      if user
        render json: UserBlueprint.render(user, root: :data)
      else
        render json: { data: I18n.t('auth.invalid_credentials') }, status: :unauthorized
      end
    end

    def validate_token
      if user_by_token
        render json: UserBlueprint.render(
          user_by_token, root: :data, view: :show
        )
      else
        render json: { data: I18n.t('auth.invalid_credentials') }, status: :unauthorized
      end
    end

    private

    def user
      @user ||= Auth::Users::SignIn.new(params).call
    end

    def user_by_token
      @user_by_token ||= Auth::User.find_by(
        jwt: params[:token]&.gsub(/^Bearer /, '')
      )
    end
  end
end
