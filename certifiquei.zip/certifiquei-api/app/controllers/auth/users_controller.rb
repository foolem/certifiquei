# frozen_string_literal: true

module Auth
  class UsersController < ApplicationController
    before_action :authenticate_user!, only: %i[per_role update show destroy current]
    before_action :set_user, only: %i[update destroy show]
    before_action :set_user_by_email, only: %i[reset_password]
    before_action :set_user_by_password_token, only: %i[update_password]

    def create
      user = Auth::Users::SignUp.new(user_params).call

      render json: UserBlueprint.render(user, root: :data),
             status: :created
    end

    def show
      render json: UserBlueprint.render(@user, root: :data)
    end

    def update
      user = Auth::Users::Edit.new(user_params, @user).call

      render json: UserBlueprint.render(user, root: :data)
    end

    def destroy
      Auth::Users::Remove.new(@user).call

      render json: UserBlueprint.render(@user, root: :data)
    end

    def reset_password
      user = Auth::Users::ResetPassword.new(@user).call

      render json: UserBlueprint.render(user, root: :data)
    end

    def update_password
      user = Auth::Users::UpdatePassword.new(@user, params[:password]).call

      render json: UserBlueprint.render(user, root: :data)
    end

    private

    def set_user
      @user = Auth::User.find(params[:user_id] || params[:id])
    end

    def set_user_by_email
      @user = Auth::User.find_by!(email: params[:email])
    end

    def set_user_by_password_token
      @user = Auth::User.find_by!(password_token: params[:token])
    end

    def user_params
      params.permit(:first_name, :last_name, :email, :password,
                    :user_type, :course, :grr, :event_id)
    end
  end
end
