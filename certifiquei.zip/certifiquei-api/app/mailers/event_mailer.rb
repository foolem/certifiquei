# frozen_string_literal: true

class EventMailer < ApplicationMailer
  def delivery_failure(student)
    @user_name = student.event.user.first_name
    @student_name = student.first_name
    @event_name = student.event.title
    @event_url = "#{Settings.frontend_url}/events/d/#{student.event.id}"

    mail(to: student.event.user.email,
         subject: "Não foi possível enviar o certificado de #{@student_name}")
  end
end
