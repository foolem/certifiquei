# frozen_string_literal: true

class UserMailer < ApplicationMailer
  include ActionView::Helpers::NumberHelper

  def confirm_email(user)
    @name = user.first_name
    @qr_url = "https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=#{user.id}"
    @confirm_url = Settings.frontend_url.to_s

    mail(to: user.email,
         subject: 'Confirmação de cadastro no Certifiquei')
  end

  def confirm_email_with_password(user, password)
    @name = user.first_name
    @confirm_url = Settings.frontend_url.to_s
    @qr_url = "https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=#{user.id}"
    @password = password

    mail(to: user.email,
         subject: 'Confirmação de cadastro no Certifiquei')
  end

  def reset_password(user)
    @name = user.first_name
    @reset_url = "#{Settings.frontend_url}/update-password/#{user.password_token}"

    mail(to: user.email,
         subject: 'Mudança de senha no Certifiquei')
  end

  def invite_user(user, password)
    @name = user.first_name
    @password = password
    @signin_url = "#{Settings.frontend_url}/signin"

    mail(to: user.email,
         subject: 'Convite para participar do Certifiquei')
  end
end
