# frozen_string_literal: true

class CertificateMailer < ApplicationMailer
  def deliver_certificate(student)
    @student_name = student.first_name.split.first
    @event_name = student.event.title
    @certificate_url = "#{Settings.backend_url}/student-certificates/#{student.student_certificate.id}/set-seen"
    @view_link = "#{Settings.frontend_url}/signin"
    @validate_link = "#{Settings.frontend_url}/validate"

    mail(to: student.email,
         subject: "Aqui está seu certificado do evento #{@event_name}")
  end
end
