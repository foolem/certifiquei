# frozen_string_literal: true

module Organizing
  class StudentBlueprint < Blueprinter::Base
    identifier :id

    fields :delivered, :created_at, :first_name, :last_name, :email, :grr, :event_id, :user_id

    field :presences_count do |student|
      student.presences.count
    end

    field :event_name do |student|
      student.event&.title
    end

    field :user_name do |student|
      student.user&.first_name
    end

    view :show do
      association :student_certificate, blueprint: Certifying::StudentCertificateBlueprint
    end
  end
end
