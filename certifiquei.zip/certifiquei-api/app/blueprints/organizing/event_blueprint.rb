# frozen_string_literal: true

module Organizing
  class EventBlueprint < Blueprinter::Base
    identifier :id

    fields :title, :description, :status, :starts_at, :ends_at, :certificate_id

    field :students_count do |event|
      event.students.count
    end

    field :start_date do |event|
      event.start_date
    end

    field :end_date do |event|
      event.end_date
    end

    view :show do
      association :certificate, blueprint: Certifying::CertificateBlueprint
      association :activities, blueprint: Organizing::ActivityBlueprint
      association :securities, blueprint: Securing::SecurityBlueprint
    end
  end
end
