# frozen_string_literal: true

module Organizing
  class ActivityBlueprint < Blueprinter::Base
    identifier :id

    fields :title, :description, :workload, :event_id

    field :presences_count do |activity|
      activity.presences.count
    end

    field :event_name do |activity|
      activity.event.title
    end

    view :show do
      association :event, blueprint: Organizing::EventBlueprint
      association :presences, blueprint: Organizing::PresenceBlueprint
    end
  end
end
