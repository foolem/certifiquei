# frozen_string_literal: true

module Organizing
  class PresenceBlueprint < Blueprinter::Base
    identifier :id

    fields :activity_id, :student_id, :staff_id

    field :user_first_name do |presence|
      presence.student&.first_name
    end

    field :activity_name do |presence|
      presence.activity&.title
    end

    field :event_name do |presence|
      presence.activity.event&.title
    end
  end
end
