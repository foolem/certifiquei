# frozen_string_literal: true

module Organizing
  class StaffBlueprint < Blueprinter::Base
    identifier :id

    fields :created_at, :first_name, :last_name, :email, :grr, :event_id, :user_id

    field :presences_count do |staff|
      staff.presences.count
    end

    field :event_name do |staff|
      staff.event&.title
    end

    field :user_name do |staff|
      staff.user&.first_name
    end
  end
end
