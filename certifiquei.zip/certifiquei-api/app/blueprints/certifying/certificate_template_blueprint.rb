# frozen_string_literal: true

module Certifying
  class CertificateTemplateBlueprint < Blueprinter::Base
    identifier :id

    fields :title, :metadata
  end
end
