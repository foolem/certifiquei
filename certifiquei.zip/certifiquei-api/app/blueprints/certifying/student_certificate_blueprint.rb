# frozen_string_literal: true

module Certifying
  class StudentCertificateBlueprint < Blueprinter::Base
    identifier :id

    fields :resource_url, :seen_at, :validations, :workload

    field :event do |student_certificate|
      Organizing::EventBlueprint.render_as_hash(student_certificate.event, view: :show)
    end

    field :user do |student_certificate|
      Auth::UserBlueprint.render_as_hash(student_certificate.student.user)
    end
  end
end
