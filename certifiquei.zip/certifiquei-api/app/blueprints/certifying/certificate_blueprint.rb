# frozen_string_literal: true

module Certifying
  class CertificateBlueprint < Blueprinter::Base
    identifier :id

    fields :title, :metadata, :certificate_template_id, :user_id
  end
end
