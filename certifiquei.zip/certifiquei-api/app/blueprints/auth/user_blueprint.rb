# frozen_string_literal: true

module Auth
  class UserBlueprint < Blueprinter::Base
    identifier :id

    fields :email, :first_name, :last_name, :grr,
           :jwt, :user_type, :course, :created_at

    field :student do |user|
      user.student?
    end

    field :staff do |user|
      user.staff?
    end

    field :qrcode do |user|
      "https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=#{user.id}"
    end

    view :show do
      association :staffs, blueprint: Organizing::StaffBlueprint
      association :students, blueprint: Organizing::StudentBlueprint
    end
  end
end
