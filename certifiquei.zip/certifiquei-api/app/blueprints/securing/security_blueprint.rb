# frozen_string_literal: true

module Securing
  class SecurityBlueprint < Blueprinter::Base
    identifier :id

    fields :kind, :event_id
  end
end
