# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Organizing::Activity, type: :model do
  describe 'associations' do
    it { is_expected.to belong_to(:event) }
    it { is_expected.to have_many(:presences) }
  end
end
