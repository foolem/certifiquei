# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Certifying::Certificate, type: :model do
  describe 'associations' do
    it { is_expected.to have_many(:events) }
    it { is_expected.to belong_to(:certificate_template) }
    it { is_expected.to belong_to(:user) }
  end
end
