# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Auth::User, type: :model do
  describe 'associations' do
    it { is_expected.to have_many(:events) }
    it { is_expected.to have_many(:students) }
    it { is_expected.to have_many(:staffs) }
    it { is_expected.to have_many(:student_events) }
    it { is_expected.to have_many(:staff_events) }
  end

  describe 'validations' do
    it { is_expected.to validate_presence_of(:email) }
    it { is_expected.to validate_presence_of(:first_name) }
    it { is_expected.to validate_presence_of(:last_name) }
    it { is_expected.to validate_uniqueness_of(:email) }
  end
end
