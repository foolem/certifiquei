# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Sessions #create', type: :request do
  subject(:login) { post sessions_path, params: params }

  context 'with valid params' do
    let(:user) { create(:user, email: 'email@email.com', password: '123123123') }
    let(:params) { { email: user.email, password: '123123123' } }

    subject(:login) { post sessions_path, params: params }

    it 'returns a 200 code' do
      login

      expect(response).to have_http_status(:ok)
    end

    it 'returns user payload' do
      login

      expect(response_object.email).to eq(user.email)
    end

    it 'returns user jwt' do
      login

      expect(response_object.jwt).to eq(user.reload.jwt)
    end
  end

  context 'with invalid params' do
    let(:user) { create(:user, email: 'email@email.com', password: '123123123') }

    context 'when email not found' do
      let(:params) { { email: 'another@email.com', password: '123123123' } }

      it 'returns a 404 code' do
        login

        expect(response).to have_http_status(:not_found)
      end
    end

    context 'when password is wrong' do
      let(:params) { { email: user.email, password: '123' } }

      it 'returns a 401 code' do
        login

        expect(response).to have_http_status(:unauthorized)
      end
    end
  end
end
