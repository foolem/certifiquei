# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Sessions #validate_token', type: :request do
  subject(:validate_token) { post validate_token_sessions_path, params: params }

  context 'with valid params' do
    let(:user) { create(:user, email: 'email@email.com', password: '123123123') }
    let(:params) { { token: user.jwt } }

    subject(:validate_token) { post validate_token_sessions_path, params: params }

    it 'returns a 200 code' do
      validate_token

      expect(response).to have_http_status(:ok)
    end

    it 'returns user payload' do
      validate_token

      expect(response_object.email).to eq(user.email)
    end

    it 'returns user jwt' do
      validate_token

      expect(response_object.jwt).to eq(params[:token])
    end
  end

  context 'with invalid params' do
    let(:params) { { token: '123123123' } }

    it 'returns a 401 code' do
      validate_token

      expect(response).to have_http_status(:unauthorized)
    end
  end
end
