# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Users #update_password', type: :request do
  subject(:update_password) { put update_password_users_path, params: params, headers: headers }

  context 'with valid params' do
    let(:user) { create(:user) }
    let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
    let(:params) { { password: '123123123' } }

    it 'returns a 200 code' do
      update_password

      expect(response).to have_http_status(:ok)
    end

    it 'sets password_token' do
      digest_was = user.password_digest
      update_password

      expect(user.reload.password_digest).not_to eq(digest_was)
    end
  end

  context 'with invalid params' do
    let(:user) { create(:user) }
    let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
    let(:params) { { password: nil } }

    it 'returns a 422 code' do
      update_password

      expect(response).to have_http_status(:unprocessable_entity)
    end
  end
end
