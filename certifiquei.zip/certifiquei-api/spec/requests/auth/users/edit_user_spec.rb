# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Users #update', type: :request do
  subject(:edit_user) do
    put user_path(user),
        params: user_params,
        headers: headers
  end

  let!(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    let(:user_params) { attributes_for(:user, email: 'email@email.com') }

    it 'returns a 200 code' do
      edit_user

      expect(response).to have_http_status(:ok)
    end

    it 'returns user payload' do
      edit_user

      expect(response_object.email).to eq(user_params[:email])
    end

    it 'returns user jwt' do
      edit_user

      expect(response_object.jwt).to be_truthy
    end
  end

  context 'with invalid params' do

    context 'when email is nil' do
      let(:user_params) { attributes_for(:user, email: nil) }

      it 'returns a 422 code' do
        edit_user

        expect(response).to have_http_status(:unprocessable_entity)
      end
    end
  end
end
