# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Users #reset_password', type: :request do
  subject(:reset_password) { post reset_password_users_path, params: params, headers: headers }

  context 'with valid params' do
    let(:user) { create(:user, password_token: nil) }
    let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
    let(:params) { { email: user.email } }

    before do
      ActiveJob::Base.queue_adapter = :test
    end

    it 'creates 1 mailer job' do
      expect { reset_password }.to have_enqueued_job.on_queue('mailers').exactly(1)
    end

    it 'returns a 200 code' do
      reset_password

      expect(response).to have_http_status(:ok)
    end

    it 'sets password_token' do
      reset_password

      expect(user.reload.password_token).to be_truthy
    end
  end

  context 'with invalid params' do
    let(:user) { create(:user, password_token: nil) }
    let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
    let(:params) { { email: 'email@email.com' } }

    it 'returns a 404 code' do
      reset_password

      expect(response).to have_http_status(:not_found)
    end
  end
end
