# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Users #destroy', type: :request do
  subject(:remove_user) do
    delete user_path(user_id), headers: headers
  end

  let!(:user) { create(:user) }
  let(:user_id) { user.id }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    it 'returns a 200 code' do
      remove_user

      expect(response).to have_http_status(:ok)
    end

    it 'returns user payload' do
      remove_user

      expect(response_object.email).to eq(user.email)
    end

    it 'removes user' do
      expect { remove_user }.to change(Auth::User, :count).by(-1)
    end
  end

  context 'with invalid params' do
    before do
      user.destroy
    end

    it 'returns a 401 code' do
      remove_user

      expect(response).to have_http_status(:unauthorized)
    end
  end
end
