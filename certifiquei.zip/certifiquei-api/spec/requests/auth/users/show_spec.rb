# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Users #show', type: :request do
  subject(:show_user) do
    get user_path(user_id), headers: headers
  end

  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    let!(:user) { create(:user) }
    let!(:user_id) { user.id }

    it 'returns a 200 code' do
      show_user

      expect(response).to have_http_status(:ok)
    end

    it 'returns user payload' do
      show_user

      expect(response_object.id).to eq(user_id)
    end
  end

  context 'with invalid params' do
    let!(:user) { create(:user) }
    let!(:user_id) { '123123' }

    it 'returns a 404 code' do
      show_user

      expect(response).to have_http_status(:not_found)
    end
  end
end
