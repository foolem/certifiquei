# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Users #create', type: :request do
  subject(:sign_up) do
    post users_path, params: user_params
  end

  context 'with valid params',
          vcr: { cassette_name: 'auth/sign_up_success' } do
    let(:user_params) { attributes_for(:user, email: 'email@email.com') }

    it 'returns a 201 code' do
      sign_up

      expect(response).to have_http_status(:created)
    end

    it 'creates a User' do
      expect { sign_up }.to change(Auth::User, :count).by(1)
    end

    it 'returns user payload' do
      sign_up

      expect(response_object.email).to eq(user_params[:email])
    end

    it 'returns user jwt' do
      sign_up

      expect(response_object.jwt).to be_truthy
    end
  end

  context 'with invalid params' do

    context 'when email is nil' do
      let(:user_params) { attributes_for(:user, email: nil) }

      it 'returns a 422 code' do
        sign_up

        expect(response).to have_http_status(:unprocessable_entity)
      end
    end
  end
end
