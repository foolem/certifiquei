# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Duplicate certificate', type: :request do
  subject(:duplicate) { post certificate_duplicate_path(certificate), headers: headers }
  let(:user) { create(:user) }

  context 'with valid params' do
    let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
    let(:certificate) { create(:certificate, title: 'Cert', user: user) }

    it 'returns a 200 code' do
      duplicate

      expect(response).to have_http_status(:ok)
    end

    it 'returns same title' do
      duplicate

      expect(response_object.title).to eq(certificate.title)
    end

    it 'returns same user' do
      duplicate

      expect(response_object.user_id).to eq(certificate.user_id)
    end
  end

  context 'without authentication' do
    let(:certificate) { create(:certificate, title: 'Cert', user: user) }

    it 'returns a 401 code' do
      duplicate

      expect(response).to have_http_status(:unauthorized)
    end
  end
end
