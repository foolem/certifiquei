# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Certificate #create', type: :request do
  subject(:create_certificate) { post certificates_path, params: params, headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    let(:params) do
      attributes_for(:certificate).merge(
        user_id: user.id, certificate_template_id: create(:certificate_template).id
      )
    end

    it 'returns a 201 code' do
      create_certificate

      expect(response).to have_http_status(:created)
    end

    it 'creates a Category' do
      expect { create_certificate }.to change(Certifying::Certificate, :count).by(1)
    end

    it 'returns category payload' do
      create_certificate

      expect(response_object.title).to eq(params[:title])
    end
  end

  context 'with invalid params' do
    let(:params) { { title: nil, description: nil } }

    it 'returns a 422 code' do
      create_certificate

      expect(response).to have_http_status(:unprocessable_entity)
    end
  end
end
