# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Certificate #edit', type: :request do
  subject(:edit_certificate) do
    put certificate_path(certificate), params: params, headers: headers
  end

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:certificate) { create(:certificate, user: user) }

  context 'with valid params' do
    let(:params) { attributes_for(:certificate) }

    it 'returns a 200 code' do
      edit_certificate

      expect(response).to have_http_status(:ok)
    end

    it 'returns category payload' do
      edit_certificate

      expect(response_object.title).to eq(params[:title])
    end
  end

  context 'with invalid params' do
    let(:params) { { title: nil, metadata: nil } }

    it 'returns a 422 code' do
      edit_certificate

      expect(response).to have_http_status(:unprocessable_entity)
    end
  end
end
