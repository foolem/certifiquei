# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Certificate  #destroy', type: :request do
  subject(:destroy_certificate) { delete certificate_path(certificate), headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let!(:certificate) { create(:certificate, user: user) }

  context 'with valid params' do
    it 'returns a 200 code' do
      destroy_certificate

      expect(response).to have_http_status(:ok)
    end

    it 'removes a Category' do
      expect { destroy_certificate }.to change(Certifying::Certificate, :count).by(-1)
    end

    it 'returns category payload' do
      destroy_certificate

      expect(response_object.title).to eq(certificate.title)
    end
  end
end
