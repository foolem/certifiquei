# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Set seen', type: :request do
  subject(:set_seen) do
    get student_certificate_set_seen_path(student_certificate), headers: headers
  end

  context 'with valid params' do
    let(:student_certificate) { create(:student_certificate) }

    it 'returns a 302 code' do
      set_seen

      expect(response).to have_http_status(:redirect)
    end

    it 'updates student_certificate' do
      set_seen

      expect(student_certificate.reload.seen_at).to be_truthy
    end
  end

  context 'without valid params' do
    let(:student_certificate) { create(:student_certificate).destroy }

    it 'returns a 404 code' do
      set_seen

      expect(response).to have_http_status(:not_found)
    end
  end
end
