# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Certificate Template #show', type: :request do
  subject(:show_certificate_template) { get certificate_template_path(certificate_template), headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:certificate_template) { create(:certificate_template) }

  context 'with valid params' do
    it 'returns a 200 code' do
      show_certificate_template

      expect(response).to have_http_status(:ok)
    end

    it 'returns category payload' do
      show_certificate_template

      expect(response_object.title).to eq(certificate_template.title)
    end
  end
end
