# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Students #destroy', type: :request do
  subject(:destroy_student) { delete event_student_path(event, student), headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:event) { create(:event, user: user) }
  let!(:student) { create(:student, event: event) }

  context 'with valid params' do
    it 'returns a 200 code' do
      destroy_student

      expect(response).to have_http_status(:ok)
    end

    it 'removes a Student' do
      expect { destroy_student }.to change(Organizing::Student, :count).by(-1)
    end

    it 'returns student payload' do
      destroy_student

      expect(response_object.id).to eq(student.id)
    end
  end
end
