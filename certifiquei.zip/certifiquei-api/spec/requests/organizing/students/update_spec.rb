# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Student #update', type: :request do
  subject(:edit_student) { put event_student_path(event, student), params: params, headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:event) { create(:event, user: user) }
  let(:student) { create(:student, event: event) }

  context 'with valid params' do
    let(:params) do
      attributes_for(:user)
    end

    it 'returns a 200 code' do
      edit_student

      expect(response).to have_http_status(:ok)
    end

    it 'returns student payload' do
      edit_student

      expect(response_object.user_id).to eq(student.user_id)
    end
  end

  context 'with invalid params' do
    let(:params) do
      attributes_for(:user, email: nil)
    end

    it 'returns a 422 code' do
      edit_student

      expect(response).to have_http_status(:unprocessable_entity)
    end
  end
end
