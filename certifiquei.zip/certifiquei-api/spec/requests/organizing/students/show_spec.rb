# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Students #show', type: :request do
  subject(:show_student) { get event_student_path(event, student), headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:event) { create(:event, user: user) }
  let(:student) { create(:student, event: event) }

  context 'with valid params' do
    it 'returns a 200 code' do
      show_student

      expect(response).to have_http_status(:ok)
    end

    it 'returns student payload' do
      show_student

      expect(response_object.id).to eq(student.id)
    end
  end
end
