# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Student #index', type: :request do
  subject(:index) { get event_students_path(event), headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:event) { create(:event, user: user) }

  context 'with valid params' do
    let!(:students) { create_list(:student, 3, event: event) }

    it 'returns a 200 code' do
      index

      expect(response).to have_http_status(:ok)
    end

    it 'returns students' do
      index

      expect(response_array.count).to eq(3)
    end
  end
end
