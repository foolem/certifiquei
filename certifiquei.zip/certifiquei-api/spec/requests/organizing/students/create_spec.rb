# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Students #create', type: :request do
  subject(:create_student) do
    post event_students_path(event), params: params, headers: headers
  end

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:event) { create(:event, user: user) }

  context 'with valid params',
          vcr: { cassette_name: 'educating/students/create_success' } do
    let(:params) do
      attributes_for(:user)
    end

    it 'returns a 201 code' do
      create_student

      expect(response).to have_http_status(:created)
    end

    it 'creates a Student' do
      expect { create_student }.to change(Organizing::Student, :count).by(1)
    end

    it 'returns student payload' do
      create_student

      expect(response_object.user_id).to be_truthy
    end
  end

  context 'with invalid params' do
    let(:params) do
      attributes_for(:user, email: nil)
    end

    it 'returns a 422 code' do
      create_student

      expect(response).to have_http_status(:unprocessable_entity)
    end
  end
end
