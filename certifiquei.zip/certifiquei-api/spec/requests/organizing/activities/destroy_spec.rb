# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Activities #destroy', type: :request do
  subject(:destroy_activity) { delete activity_path(activity), headers: headers }

  let(:user) { activity.event.user }
  let!(:staff) { create(:staff, event: activity.event, user: user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    context 'when basic activity' do
      let!(:activity) do
        create(:activity)
      end

      it 'returns a 200 code' do
        destroy_activity

        expect(response).to have_http_status(:ok)
      end

      it 'returns activity' do
        destroy_activity

        expect(response_object.title).to eq(activity.title)
      end

      it 'removes activity' do
        expect { destroy_activity }.to change(Organizing::Activity, :count).by(-1)
      end
    end
  end
end
