# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Activities #index', type: :request do
  subject(:index) { get activities_path, headers: headers }

  let(:user) { event.user }
  let!(:staff) { create(:staff, event: event, user: user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    let(:event) { create(:event) }
    let!(:activities) { create_list(:activity, 3, event: event) }

    it 'returns a 200 code' do
      index

      expect(response).to have_http_status(:ok)
    end

    it 'returns activities' do
      index

      expect(response_array.count).to eq(3)
    end
  end
end
