# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Activities #create', type: :request do
  subject(:create_activity) { post activities_path, params: params, headers: headers }

  let(:user) { create(:user) }
  let!(:staff) { create(:staff, event: event, user: user) }
  let(:event) { create(:event, user: user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    let(:params) do
      attributes_for(:activity, title: 'My Activity').merge(event_id: event.id)
    end

    it 'creates an Activity' do
      expect { create_activity }.to change(Organizing::Activity, :count).by(1)
    end

    it 'returns activity' do
      create_activity

      expect(response_object.title).to eq('My Activity')
    end
  end
end
