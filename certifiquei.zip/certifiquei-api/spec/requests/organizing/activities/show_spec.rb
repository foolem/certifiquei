# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Events #show', type: :request do
  subject(:show) { get activity_path(activity), headers: headers }

  let(:user) { event.user }
  let!(:staff) { create(:staff, event: event, user: user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:event) { create(:event) }
  let!(:activity) { create(:activity, event: event) }

  context 'with valid params' do
    it 'returns a 200 code' do
      show

      expect(response).to have_http_status(:ok)
    end

    it 'returns activity' do
      show

      expect(response_object.title).to eq(activity.title)
    end
  end
end
