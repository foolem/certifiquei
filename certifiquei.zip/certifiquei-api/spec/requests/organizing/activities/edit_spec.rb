# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Events #edit', type: :request do
  subject(:edit_activity) { put activity_path(activity), params: params, headers: headers }

  let(:user) { activity.event.user }
  let!(:staff) { create(:staff, event: activity.event, user: user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    context 'when basic activity' do
      let(:activity) do
        create(:activity)
      end

      let(:params) { attributes_for(:activity) }

      it 'returns activity' do
        edit_activity

        expect(response_object.title).to eq(params[:title])
      end
    end
  end
end
