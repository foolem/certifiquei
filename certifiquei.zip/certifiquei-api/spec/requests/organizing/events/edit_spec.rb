# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Events #edit', type: :request do
  subject(:edit_event) { put event_path(event), params: params, headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    context 'when basic event' do
      let(:event) do
        create(:event, user_id: user.id, certificate_id: create(:certificate).id)
      end

      let(:params) { attributes_for(:event) }

      it 'returns event' do
        edit_event

        expect(response_object.title).to eq(params[:title])
      end
    end
  end
end
