# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Events #index', type: :request do
  subject(:index) { get events_path, headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    let!(:events) { create_list(:event, 3, user: user) }

    it 'returns a 200 code' do
      index

      expect(response).to have_http_status(:ok)
    end

    it 'returns events' do
      index

      expect(response_array.count).to eq(3)
    end
  end

  context 'with other tenant' do
    it 'returns an empty array' do
      index

      expect(response_array.count).to eq(0)
    end
  end
end
