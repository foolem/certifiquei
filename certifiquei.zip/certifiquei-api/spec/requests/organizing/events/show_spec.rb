# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Events #show', type: :request do
  subject(:show) { get event_path(event), headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let!(:event) { create(:event, user: user) }

  context 'with valid params' do
    it 'returns a 200 code' do
      show

      expect(response).to have_http_status(:ok)
    end

    it 'returns event' do
      show

      expect(response_object.title).to eq(event.title)
    end
  end
end
