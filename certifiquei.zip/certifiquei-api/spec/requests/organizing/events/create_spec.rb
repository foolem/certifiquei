# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Events #create', type: :request do
  subject(:create_event) { post events_path, params: params, headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    let(:params) do
      attributes_for(:event, title: 'My Event', user_id: user.id).merge({
                                                       deliveries_attributes: [attributes_for(:delivery)],
                                                       securities_attributes: [attributes_for(:security)],
                                                       activities_attributes: [attributes_for(:activity)],
                                                       certificate_id: create(:certificate, user_id: user.id).id
                                                     })
    end

    it 'creates an Event' do
      expect { create_event }.to change(Organizing::Event, :count).by(1)
    end

    it 'creates 1 Activity' do
      expect { create_event }.to change(Organizing::Activity, :count).by(1)
    end

    it 'creates a Delivery' do
      expect { create_event }.to change(Delivering::Delivery, :count).by(1)
    end

    it 'creates a Security' do
      expect { create_event }.to change(Securing::Security, :count).by(1)
    end

    it 'returns event' do
      create_event

      expect(response_object.title).to eq('My Event')
    end

    it 'returns event with draft status' do
      create_event

      expect(response_object.status).to eq('draft')
    end

    it 'returns event with 1 activities' do
      create_event

      expect(response_object.activities.count).to eq(1)
    end

    it 'returns event with same certificate_id' do
      create_event

      expect(response_object.certificate_id).to eq(params[:certificate_id])
    end
  end
end
