# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Events #destroy', type: :request do
  subject(:destroy_event) { delete event_path(event), headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    context 'when basic event' do
      let!(:event) do
        create(:event, user_id: user.id, certificate_id: create(:certificate).id)
      end

      it 'returns a 200 code' do
        destroy_event
        
        expect(response).to have_http_status(:ok)
      end

      it 'returns event' do
        destroy_event

        expect(response_object.title).to eq(event.title)
      end

      it 'removes event' do
        expect { destroy_event }.to change(Organizing::Event, :count).by(-1)
      end
    end
  end
end
