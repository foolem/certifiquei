# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Staffs #show', type: :request do
  subject(:show_staff) { get event_staff_path(event, staff), headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:event) { create(:event, user: user) }
  let(:staff) { create(:staff, event: event) }

  context 'with valid params' do
    it 'returns a 200 code' do
      show_staff

      expect(response).to have_http_status(:ok)
    end

    it 'returns staff payload' do
      show_staff

      expect(response_object.id).to eq(staff.id)
    end
  end
end
