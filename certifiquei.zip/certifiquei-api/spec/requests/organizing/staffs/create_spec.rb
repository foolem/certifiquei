# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Staffs #create', type: :request do
  subject(:create_staff) do
    post staffs_path, params: params, headers: headers
  end

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:event) { create(:event, user: user) }

  context 'with valid params',
          vcr: { cassette_name: 'educating/staffs/create_success' } do
    let(:params) do
      attributes_for(:user).merge(event_id: event.id)
    end

    it 'returns a 201 code' do
      create_staff

      expect(response).to have_http_status(:created)
    end

    it 'creates a Staff' do
      expect { create_staff }.to change(Organizing::Staff, :count).by(1)
    end

    it 'returns staff payload' do
      create_staff

      expect(response_object.user_id).to be_truthy
    end
  end

  context 'with invalid params' do
    let(:params) do
      attributes_for(:user, email: nil).merge(event_id: event.id)
    end

    it 'returns a 422 code' do
      create_staff

      expect(response).to have_http_status(:unprocessable_entity)
    end
  end
end
