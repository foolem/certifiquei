# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Staffs #destroy', type: :request do
  subject(:destroy_staff) { delete staff_path(staff), headers: headers }

  let(:user) { create(:user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:event) { create(:event, user: user) }
  let!(:staff) { create(:staff, event: event) }

  context 'with valid params' do
    it 'returns a 200 code' do
      destroy_staff

      expect(response).to have_http_status(:ok)
    end

    it 'removes a Staff' do
      expect { destroy_staff }.to change(Organizing::Staff, :count).by(-1)
    end

    it 'returns staff payload' do
      destroy_staff

      expect(response_object.id).to eq(staff.id)
    end
  end
end
