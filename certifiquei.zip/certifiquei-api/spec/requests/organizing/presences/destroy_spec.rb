# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Presences #destroy', type: :request do
  subject(:destroy_presence) do
    delete activity_presence_path(
      presence.activity, presence
    ), headers: headers
  end

  let(:user) { create(:user, user_type: :regular) }
  let!(:staff) { create(:staff, event: presence.activity.event, user: user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    context 'when basic presence' do
      let!(:presence) do
        create(:presence)
      end

      it 'returns a 200 code' do
        destroy_presence

        expect(response).to have_http_status(:ok)
      end

      it 'returns presence' do
        destroy_presence

        expect(response_object.student_id).to eq(presence.student.id)
      end

      it 'removes presence' do
        expect { destroy_presence }.to change(Organizing::Presence, :count).by(-1)
      end
    end
  end
end
