# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Presence #create', type: :request do
  subject(:create_presence) do
    post activity_presences_path(activity), params: params, headers: headers
  end

  let(:user) { create(:user, user_type: :regular) }
  let!(:staff) { create(:staff, event: activity.event, user: user) }
  let(:student) { create(:student, event: activity.event) }
  let(:activity) { create(:activity) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    let(:params) do
      { activity_id: activity.id, staff_id: staff.id, user_id: student.user.id }
    end

    it 'creates an Presence' do
      expect { create_presence }.to change(Organizing::Presence, :count).by(1)
    end

    it 'returns presence' do
      create_presence

      expect(response_object.student_id).to eq(student.id)
    end
  end
end
