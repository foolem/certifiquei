# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Presence #show', type: :request do
  subject(:show) do
    get event_activity_presence_path(activity.event, activity, presence), headers: headers
  end

  let(:user) { create(:user, user_type: :regular) }
  let!(:staff) { create(:staff, event: activity.event, user: user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }
  let(:activity) { create(:activity) }
  let!(:presence) { create(:presence, activity: activity) }

  context 'with valid params' do
    it 'returns a 200 code' do
      show

      expect(response).to have_http_status(:ok)
    end

    it 'returns presence' do
      show

      expect(response_object.student_id).to eq(presence.student.id)
    end
  end
end
