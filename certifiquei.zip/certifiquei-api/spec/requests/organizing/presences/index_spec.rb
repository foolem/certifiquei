# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Presence #index', type: :request do
  subject(:index) do
    get event_activity_presences_path(activity.event, activity), headers: headers
  end

  let(:user) { create(:user, user_type: :regular) }
  let!(:staff) { create(:staff, event: activity.event, user: user) }
  let(:headers) { { Authorization: "Bearer #{user.jwt}" } }

  context 'with valid params' do
    let(:activity) { create(:activity) }
    let!(:presences) { create_list(:presence, 3, activity: activity, staff: staff) }

    it 'returns a 200 code' do
      index

      expect(response).to have_http_status(:ok)
    end

    it 'returns presences' do
      index

      expect(response_array.count).to eq(3)
    end
  end
end
