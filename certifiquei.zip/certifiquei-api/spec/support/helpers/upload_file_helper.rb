# frozen_string_literal: true

module UploadFileHelper
  module_function

  def upload_file(storage:, filepath:, id:)
    image = File.open(filepath)
    Shrine.storages[storage].upload(image, id)
  end

  def upload_fake_s3_file(id = 'aws_s3_example_id')
    upload_file(
      storage: :cache,
      filepath: 'spec/fixtures/images/aws_s3_example_id',
      id: id
    )
  end

  def default_file_params(opts = {})
    id = opts[:id] || 'aws_s3_example_id'

    {
      id: id,
      storage: :cache,
      metadata: {
        size: 211_998,
        filename: 'Sample Image Name',
        mime_type: 'image/png'
      }
    }
  end
end
