# frozen_string_literal: true

module Helpers
  module JsonResponse
    def json_response
      JSON.parse(response.body)
    end

    def response_object
      OpenStruct.new(json_response['data'])
    end

    def response_array
      json_response['data']
    end

    def response_pagination
      json_response['meta']['pagination']
    end
  end
end
