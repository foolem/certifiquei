# frozen_string_literal: true

FactoryBot.define do
  factory :user, class: 'Auth::User' do
    first_name { Faker::Name.first_name }
    last_name { Faker::Name.last_name }
    email { Faker::Internet.email }
    password { '123123123' }
    grr { 'GRR00000000' }
    user_type { :manager }

    trait :student do
      after :create do |user|
        create(:student, user_id: user.id)
      end
    end

    trait :staff do
      after :create do |user|
        create(:staff, user_id: user.id)
      end
    end
  end
end
