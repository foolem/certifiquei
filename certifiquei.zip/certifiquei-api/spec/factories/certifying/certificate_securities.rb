# frozen_string_literal: true

FactoryBot.define do
  factory :certificate_security, class: 'Certifying::CertificateSecurity' do
    resource { 'MyString' }
    security
    student_certificate
  end
end
