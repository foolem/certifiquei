# frozen_string_literal: true

FactoryBot.define do
  factory :student_certificate, class: 'Certifying::StudentCertificate' do
    resource_url { 'MyString' }
  end
end
