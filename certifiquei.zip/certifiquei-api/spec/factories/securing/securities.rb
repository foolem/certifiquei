# frozen_string_literal: true

FactoryBot.define do
  factory :security, class: 'Securing::Security' do
    kind { %i[internal blockchain].sample }

    event
  end
end
