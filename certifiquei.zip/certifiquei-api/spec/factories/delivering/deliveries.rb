# frozen_string_literal: true

FactoryBot.define do
  factory :delivery, class: 'Delivering::Delivery' do
    content { 'MyText' }
    kind { :email }
    event
  end
end
