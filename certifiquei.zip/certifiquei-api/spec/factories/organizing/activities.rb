# frozen_string_literal: true

FactoryBot.define do
  factory :activity, class: 'Organizing::Activity' do
    title { Faker::Name.first_name }
    description { Faker::Name.last_name }
    workload { '1:30' }
    event
  end
end
