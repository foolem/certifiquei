# frozen_string_literal: true

FactoryBot.define do
  factory :event, class: 'Organizing::Event' do
    title { Faker::Name.first_name }
    description { Faker::Name.last_name }
    status { :active }
    certificate
    user

    trait :with_students do
      after :create do |event|
        create(:student, event: event)
      end
    end

    trait :with_internal_security do
      after(:create) do |event|
        create(:security, event: event, kind: :internal)
      end
    end

    trait :with_blockchain_security do
      after(:create) do |event|
        create(:security, event: event, kind: :blockchain)
      end
    end

    trait :with_delivery do
      after(:create) do |event|
        create(:delivery, event: event, kind: :email)
      end
    end
  end
end
