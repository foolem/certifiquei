# frozen_string_literal: true

FactoryBot.define do
  factory :staff, class: 'Organizing::Staff' do
    user
    event
  end
end
