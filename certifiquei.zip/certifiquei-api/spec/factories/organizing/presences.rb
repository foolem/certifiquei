# frozen_string_literal: true

FactoryBot.define do
  factory :presence, class: 'Organizing::Presence' do
    student
    staff
    activity
  end
end
