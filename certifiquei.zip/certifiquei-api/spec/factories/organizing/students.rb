# frozen_string_literal: true

FactoryBot.define do
  factory :student, class: 'Organizing::Student' do
    user
    event
  end
end
