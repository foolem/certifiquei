# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Certifying::Certificates::Create do
  subject(:create_certificate) do
    described_class.new(params).call
  end

  let(:user) { create(:user) }

  context 'with valid params' do
    let(:params) do
      attributes_for(:certificate).merge(
        user_id: user.id, certificate_template_id: create(:certificate_template).id
      )
    end

    it 'returns category' do
      expect(create_certificate.title).to eq(params[:title])
    end
  end

  context 'with invalid params' do
    let(:params) { { title: nil, metadata: nil } }

    it 'raises RecordInvalid' do
      expect { create_certificate }.to raise_error(ActiveRecord::RecordInvalid)
    end
  end
end
