# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Certifying::Certificates::Build do
  subject(:generate) { described_class.new(student).call }

  context 'with valid params' do
    context 'with internal security',
            vcr: { cassette_name: 'certifying/generate_internal_success' } do
      let(:event) { create(:event, :with_students) }
      let(:student) { event.students.last }

      it 'returns response' do
        expect(generate[:pdfUrl]).to be_truthy
      end

      it 'creates StudentCertificate' do
        expect { generate }.to change(Certifying::StudentCertificate, :count).by(1)
      end

      it 'creates StudentCertificate with valid url' do
        generate

        expect(student.reload.student_certificate.resource_url).to be_truthy
      end
    end

    context 'with blockchain security',
            vcr: { cassette_name: 'certifying/generate_blockchain_success' } do
      let(:event) { create(:event, :with_students, :with_blockchain_security) }
      let(:student) { event.students.last }

      it 'returns response' do
        expect(generate[:pdfUrl]).to be_truthy
      end

      it 'creates StudentCertificate' do
        expect { generate }.to change(Certifying::StudentCertificate, :count).by(1)
      end

      it 'creates StudentCertificate with valid url' do
        generate

        expect(student.reload.student_certificate.resource_url).to be_truthy
      end
    end
  end
end
