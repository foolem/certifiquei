# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Certifying::Certificates::Edit do
  subject(:edit_certificate) do
    described_class.new(params, certificate).call
  end

  let(:certificate) { create(:certificate) }

  context 'with valid params' do
    let(:params) { attributes_for(:certificate) }

    it 'returns category' do
      expect(edit_certificate.title).to eq(params[:title])
    end
  end

  context 'with invalid params' do
    let(:params) { { title: nil, metadata: nil } }

    it 'raises RecordInvalid' do
      expect { edit_certificate }.to raise_error(ActiveRecord::RecordInvalid)
    end
  end
end
