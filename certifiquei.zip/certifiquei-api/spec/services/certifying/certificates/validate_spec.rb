# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Certifying::Certificates::Validate do
  subject(:validate) { described_class.new(params).call }

  let(:event) { create(:event, :with_students, :with_internal_security) }
  let(:student) { event.students.last }
  let(:student_certificate) { create(:student_certificate) }
  let(:certificate_security) do
    create(:certificate_security,
           student_certificate: student_certificate,
           security: event.securities.last,
           resource: 'secret_weapon')
  end

  context 'with valid params' do
    let(:params) { { kind: :internal, resource: 'secret_weapon' } }

    before do
      student.update(student_certificate: student_certificate)
      certificate_security
    end

    it 'returns StudentCertificate' do
      expect(validate.id).to eq(student_certificate.id)
    end
  end

  context 'with invalid params' do
    let(:params) { { kind: :internal, resource: 'not_secret_weapon' } }

    it 'raises ActiveRecord::RecordNotFound' do
      expect { validate }.to raise_error(ActiveRecord::RecordNotFound)
    end
  end
end
