# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Organizing::Events::Create do
  subject(:create_event) do
    described_class.new(params, user).call
  end

  let(:user) { create(:user) }

  context 'with valid params' do
    let(:params) do
      attributes_for(:event, title: 'My Event', user_id: user.id).merge({
                                                                          deliveries_attributes: [attributes_for(:delivery)],
                                                                          securities_attributes: [attributes_for(:security)],
                                                                          activities_attributes: [attributes_for(:activity)],
                                                                          certificate_id: create(:certificate,
                                                                                                 user_id: user.id).id
                                                                        })
    end

    it 'creates an Event' do
      expect { create_event }.to change(Organizing::Event, :count).by(1)
    end

    it 'creates 1 Activity' do
      expect { create_event }.to change(Organizing::Activity, :count).by(1)
    end

    it 'creates a Delivery' do
      expect { create_event }.to change(Delivering::Delivery, :count).by(1)
    end

    it 'creates a Security' do
      expect { create_event }.to change(Securing::Security, :count).by(1)
    end

    it 'returns event' do
      expect(create_event.title).to eq('My Event')
    end

    it 'returns event with draft status' do
      expect(create_event.status).to eq('draft')
    end

    it 'returns event with 1 activities' do
      expect(create_event.activities.count).to eq(1)
    end

    it 'returns event with same certificate_id' do
      expect(create_event.certificate_id).to eq(params[:certificate_id])
    end

    context 'with template, not certificate' do
      let(:params) do
        attributes_for(:event, title: 'My Event', user_id: user.id).merge({
                                                                            deliveries_attributes: [attributes_for(:delivery)],
                                                                            securities_attributes: [attributes_for(:security)],
                                                                            certificate_template_id: create(:certificate_template).id
                                                                          })
      end

      it 'returns event with same certificate_template_id' do
        expect(create_event.certificate.certificate_template_id).to(
          eq(params[:certificate_template_id])
        )
      end
    end
  end

  context 'with invalid params' do
    let(:params) do
      attributes_for(:event, title: 'My Event', user_id: user.id).merge({
                                                                        })
    end

    it 'raises InvalidParams error' do
      expect { create_event }.to raise_error(ActiveRecord::RecordInvalid)
    end
  end
end
