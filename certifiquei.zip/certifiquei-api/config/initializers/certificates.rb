def s3_certificates
  @s3_certificates ||= Aws::S3::Resource.new(region: ::Settings.certificates_region)
                                        .bucket(::Settings.certificates_bucket)
end
