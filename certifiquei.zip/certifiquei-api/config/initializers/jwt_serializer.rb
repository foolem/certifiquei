module JWTSerializer
  module_function

  def encode(payload)
    JWT.encode payload, Rails.application.credentials.jwt_secret
  end

  def decode(token)
    JWT.decode(token, Rails.application.credentials.jwt_secret).first
  end
end
