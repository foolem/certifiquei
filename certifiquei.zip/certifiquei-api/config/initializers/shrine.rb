require 'shrine/storage/s3'
require "shrine/storage/memory"

s3_options = {
  access_key_id:     Rails.application.credentials.aws[:access_key_id],
  secret_access_key: Rails.application.credentials.aws[:secret_access_key],
  region:            Rails.application.credentials.aws[:region],
  bucket:            Rails.application.credentials.aws[:assets_bucket]
}

upload_options = { upload_options: { acl: 'public-read', cache_control: 'public, max-age=3600' } }
s3_options.merge!(upload_options)

if Rails.configuration.shrine_mode == :s3
  Shrine.storages = {
    cache: Shrine::Storage::S3.new(prefix: 'cache', **s3_options), # temporary
    store: Shrine::Storage::S3.new(prefix: 'store', **s3_options)  # permanent
  }
else
  Shrine.storages = {
    cache: Shrine::Storage::Memory.new,
    store: Shrine::Storage::Memory.new,
  }
end

Shrine.plugin :presign_endpoint
Shrine.plugin :backgrounding
