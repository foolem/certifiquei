Rails.application.routes.draw do
  scope module: :auth do
    resources :sessions, only: [:create] do
      collection do
        post :validate_token, path: 'validate-token'
      end
    end

    resources :users do
      collection do
        get :current
        post :confirm_email, path: 'confirm-email'
        post :reset_password, path: 'reset-password'
        put :update_password, path: 'update-password'
      end
    end
  end

  scope module: :certifying do
    resources :certificate_templates, path: 'certificate-templates', only: [:index, :show]
    resources :student_certificates, only: [:index], path: 'student-certificates' do
      get :set_seen, path: 'set-seen'
    end
    resources :certificates do
      post :duplicate
      collection do
        post :validate
      end
    end
  end

  scope module: :organizing do
    resources :events do
      get :distribute_certificates, path: 'distribute-certificates'
      collection do
        get :all
      end
      resources :activities do
        resources :presences
      end
      resources :staffs, except: [:update, :create], controller: :staffs, module: :events
      resources :students
    end
    resources :students do
      collection do
        get :all
      end
    end
    resources :staffs, only: [:index, :create, :destroy] do
      collection do
        get :all
      end
    end
    resources :activities do
      collection do
        get :all
      end
      resources :presences
    end
  end
end
